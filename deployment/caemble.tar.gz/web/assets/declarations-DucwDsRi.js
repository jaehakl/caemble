import{d as a}from"./types-CF3-EY_6.js";const r=Object.freeze([Object.freeze({group:"Constructors",names:Object.freeze(["complex","matrix","index","number"])}),Object.freeze({group:"Constants",names:Object.freeze(["e","pi","i","tau"])}),Object.freeze({group:"Arithmetic",names:Object.freeze(["abs","add","cbrt","ceil","cube","divide","dotDivide","dotMultiply","dotPow","exp","expm","expm1","fix","floor","hypot","log","log10","log1p","log2","mod","multiply","nthRoot","pow","round","sign","sqrt","sqrtm","square","subtract","unaryMinus","unaryPlus"])}),Object.freeze({group:"Complex",names:Object.freeze(["arg","conj","im","re"])}),Object.freeze({group:"Matrix",names:Object.freeze(["column","concat","cross","ctranspose","det","diag","dot","flatten","identity","kron","map","matrixFromColumns","matrixFromRows","ones","range","reshape","resize","row","size","squeeze","subset","trace","transpose","zeros"])}),Object.freeze({group:"Linear algebra",names:Object.freeze(["eigs","inv","lup","lusolve","lsolve","lsolveAll","pinv","qr","schur","slu","usolve","usolveAll"])}),Object.freeze({group:"Numeric ODE",names:Object.freeze(["solveODE"])}),Object.freeze({group:"Signal",names:Object.freeze(["fft","freqz","ifft","zpk2tf"])}),Object.freeze({group:"Special and deterministic probability",names:Object.freeze(["bellNumbers","bernoulli","catalan","combinations","combinationsWithRep","erf","factorial","gamma","lgamma","multinomial","nthRoots","permutations","polynomialRoot","stirlingS2","zeta"])}),Object.freeze({group:"Statistics",names:Object.freeze(["corr","count","cumsum","mad","max","mean","median","min","mode","prod","quantileSeq","std","sum","variance"])}),Object.freeze({group:"Trigonometry",names:Object.freeze(["acos","acosh","acot","acoth","acsc","acsch","asec","asech","asin","asinh","atan","atan2","atanh","cos","cosh","cot","coth","csc","csch","sec","sech","sin","sinh","tan","tanh"])}),Object.freeze({group:"Numeric checks",names:Object.freeze(["compare","deepEqual","equal","isFinite","isInteger","isNaN","isNegative","isNumeric","isPositive","isPrime","isZero","larger","largerEq","smaller","smallerEq","typeOf","unequal"])})]),t=Object.freeze(r.flatMap(({names:e})=>e)),o=Object.freeze({complex:"export function complex(re?: number, im?: number): MathJsComplex",e:"export const e: number",i:"export const i: MathJsComplex",index:"export function index(...ranges: any[]): any",map:"export function map<T>(data: T, callback: (value: any, index: readonly number[], data: T) => any): any",matrix:"export function matrix<T = unknown>(data?: T): MathJsMatrix<T>",mean:"export function mean(data: any, dimension?: number): any",number:"export function number(value?: any): number",pi:"export const pi: number",range:"export function range(start: number, end: number, step?: number, includeEnd?: boolean): MathJsMatrix<readonly number[]>",reshape:"export function reshape(data: any, sizes: readonly number[]): any",size:"export function size(data: any): readonly number[]",squeeze:"export function squeeze(data: any): any",subset:"export function subset(data: any, index: any, replacement?: any, defaultValue?: any): any",tau:"export const tau: number",transpose:"export function transpose(data: any): any",zeros:"export function zeros(rows: number, columns: number): MathJsMatrix<readonly (readonly number[])[]>"}),s=t.map(e=>o[e]??`export function ${e}(...args: any[]): any`).join(`
  `),c=`
type BoxGridProjectionAxis = 'x' | 'y' | 'z' | 'time' | 'frequency'
type BoxGridProjectionData = number | readonly BoxGridProjectionData[]
interface BoxGridProjectionOptions {
  readonly axes: readonly BoxGridProjectionAxis[]
  readonly representation?: 'amplitude' | 'phase'
  readonly component?: number | 'magnitude' | 'magnitudeSquared' | { readonly tensor: readonly ['x' | 'y' | 'z' | 'all', 'x' | 'y' | 'z' | 'all'] }
  readonly reduce?: Partial<Record<BoxGridProjectionAxis, { method: 'sum' | 'mean' | 'min' | 'max' | 'median' | 'std' | 'index'; index?: number }>>
  readonly frame?: { phase?: number; timeSeconds?: number; axis?: 'time' | 'frequency'; index?: number }
}
declare const boxGrid: Readonly<{
  project(leaf: CalculationInputLeaf, options: BoxGridProjectionOptions): { readonly dtype: 'float64'; readonly data: BoxGridProjectionData; readonly axes: readonly CalculationAxis[] }
}>

interface MathJsComplex {
  readonly isComplex: true
  readonly re: number
  readonly im: number
}

interface MathJsMatrix<T = unknown> {
  readonly isMatrix: true
  size(): readonly number[]
  toArray(): T
  valueOf(): T
}

type CalculationDtype =
  | 'float32' | 'float64'
  | 'int8' | 'int16' | 'int32'
  | 'uint8' | 'uint16' | 'uint32'

interface CalculationAxis {
  readonly name: string
  readonly ticks: readonly number[]
  readonly unit?: string
}

interface CalculationInputAxis {
  readonly name: string
  readonly ticks: readonly (number | string)[]
  readonly unit?: string
}

interface CalculationInputLeaf {
  readonly metadata?: Readonly<Record<string, ResultMetadataValue>>
  readonly metadataSchema?: Readonly<Record<string, { readonly dtype: string; readonly shape?: readonly (number | null)[]; readonly unit?: string; readonly quantityKind?: string; readonly values?: readonly string[] }>>
  readonly dtype: ${a.map(e=>`'${e}'`).join(" | ")}
  readonly shape: readonly number[]
  readonly data: readonly number[]
  readonly axes: readonly CalculationInputAxis[]
  readonly quantityKind?: string
  readonly tensorOrder: number
  readonly unit?: string
  readonly boxGrid: {
    readonly version: 1
    readonly sampling: 'point' | 'cell-average' | 'surface-integral' | 'aggregate'
    readonly components: readonly string[]
    readonly channels: readonly ['value'] | readonly ['amplitude', 'phase']
    readonly channelUnits: readonly string[]
    readonly frequencyKind?: 'modal' | 'sampled' | 'source-sampled'
    readonly configuration?: 'reference' | 'current'
    readonly weighting?: 'material-volume'
    readonly origin: readonly [number, number, number]
    readonly size: readonly [number, number, number]
    readonly rotation: readonly [readonly [number, number, number], readonly [number, number, number], readonly [number, number, number]]
    readonly lengthUnit: string
    readonly gridShape: readonly [number, number, number]
    readonly source: 'experiment' | 'task'
    readonly rootId: string
  }
}

type CalculationInput = Readonly<Record<string, CalculationInputLeaf>>
type ResultMetadataValue = string | boolean | number | readonly ResultMetadataValue[]

interface CalculationOutput {
  readonly dtype: CalculationDtype
  readonly data: number | readonly number[] | readonly (readonly number[])[] | readonly (readonly (readonly number[])[])[] | MathJsMatrix
  readonly axes?: readonly CalculationAxis[]
}

declare module 'mathjs' {
  ${s}
}
`,i=`import { range } from 'mathjs'

export default function calculate(record) {
  const source = record['signal']

  // Axes: x, y, z, time, frequency, amplitudePhase, component.
  // Display the XY plane at the first z/time/frequency/channel/component.
  const shape = source?.shape ?? [1, 1, 1, 1, 1, 1, 1]
  const rows = shape[0]
  const columns = shape[1]
  const stride = shape.slice(2).reduce((size, length) => size * length, 1)
  const rawData = source && Array.isArray(source.data) ? source.data : [0]
  const data = Array.from({ length: rows }, (_, x) =>
    Array.from({ length: columns }, (_, y) => Number(rawData[(x * columns + y) * stride] ?? 0)))
  const rowAxis = source?.axes[0]
  const columnAxis = source?.axes[1]
  const axes = [
    rowAxis ?? { name: 'row', ticks: range(0, rows).toArray() },
    columnAxis ?? { name: 'column', ticks: range(0, columns).toArray() },
  ]

  console.log('Returning 2D summary', { dtype: 'float64', rows, columns })
  return { dtype: 'float64', data, axes }
}
`;function l(e){const n=e??"signal";return i.replace("record['signal']",`record[${JSON.stringify(n)}]`)}const d=l();export{c as C,d as a,r as b,l as c,t as d};
