function n(e){if(!e)return"-";const t=new Date(e);return Number.isNaN(t.getTime())?"-":t.toLocaleString("ko-KR")}function r(e,t){return e instanceof Error&&e.message?e.message:t}export{n as f,r};
