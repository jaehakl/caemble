const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/CadCatalogPage-CeVuXqnJ.js","assets/createLucideIcon-BSQv30bz.js","assets/createLucideIcon-D8YKMEYw.css","assets/DataTable-7kroAbq_.js","assets/PageHeader-BGDOKsIq.js","assets/card-BrEPKbVS.js","assets/main-vdoOMv4w.js","assets/modulepreload-polyfill-B5Qt9EMX.js","assets/objectStorage-n4UVRHBM.js","assets/table-DWJs_ybf.js","assets/badge-YV4xnb42.js","assets/input-D6RjF9tz.js","assets/select-DeSSIJu0.js","assets/index-C8cTqsK3.js","assets/index-6KE7PgjX.js","assets/chevron-up-C6MbkyGU.js","assets/check-CMEF8DCo.js","assets/declarations-CEjvAGZc.js","assets/queryOptions-D3X9FGRu.js","assets/types-CF3-EY_6.js","assets/clipboard-Dq9M7_Gq.js","assets/authoringContract-BbeQITBf.js","assets/MaterialCatalogPage-EKUGRM7E.js","assets/useInfiniteQuery-BJglhpH0.js","assets/CatalogAsyncState-CRgaFU3q.js","assets/loader-circle-d5u38AiY.js","assets/refresh-cw-DQ9zTWLX.js","assets/copy-CaUzyckS.js","assets/search-CTPFFKAr.js","assets/index-DBD2Sr8N.js","assets/arrow-left-vYI1b3FG.js","assets/QuantityKindCatalogPage-032ZKQqM.js","assets/SolverCatalogPage-CK3uj1mx.js","assets/tabs-C91LrSZB.js","assets/index-CvU2E-AE.js"])))=>i.map(i=>d[i]);
import{c as $,r as m,j as a,t as O,u as F,g as E}from"./createLucideIcon-BSQv30bz.js";import{B as C,K as U,a as K,b as H}from"./main-vdoOMv4w.js";import{I as W}from"./input-D6RjF9tz.js";import{C as Q}from"./check-CMEF8DCo.js";import{C as J}from"./copy-CaUzyckS.js";import{j as X}from"./queryOptions-D3X9FGRu.js";import{C as Y,a as Z,c as ee}from"./declarations-CEjvAGZc.js";import{S as ae}from"./search-CTPFFKAr.js";import{M as re,r as te}from"./index-DBD2Sr8N.js";import{A as V}from"./arrow-left-vYI1b3FG.js";const ne=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],B=$("arrow-right",ne);const oe=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],ie=$("menu",oe);function _({text:r,label:t="코드 복사"}){const[o,u]=m.useState(!1);return a.jsxs(C,{size:"sm",variant:"outline","aria-label":t,onClick:async()=>{try{await navigator.clipboard.writeText(r),u(!0)}catch{O.error("복사하지 못했습니다. 내용을 선택해 복사해 주세요.")}},onBlur:()=>u(!1),children:[o?a.jsx(Q,{className:"size-3.5"}):a.jsx(J,{className:"size-3.5"}),o?"복사됨":t]})}const se=`# Develop and test an Experiment source bundle

Work in the Caemble monorepo and read AGENTS.md first. The external agent owns its model credentials; Caemble receives source bundles and authenticated API requests. Never put .env, access tokens, private keys, or unrelated workspace files in a bundle. Consult the installed CLI help for its exact flags.

1. Establish context. Record the repository revision, API origin, authenticated user, Catalog revision, Experiment ID/coordinate/version and source hash. Download the complete source bundle with its base identity before editing an existing Experiment. A source file copied from another revision is not an adequate baseline.
2. Choose a real starting point. Query the live Catalog through its Python library/catalogctl and inspect the relevant Solver descriptor and complete Example Experiment. Catalog examples are the executable reference; do not invent Solver names, versions, method IDs, material roles, output names or QuantityKind identifiers. The UI starter is a draft: its placeholder Task and no-op simulate body do not demonstrate a successful simulation.
3. Read only the needed language reference. experiment.tsx uses experiment(...); named Geometry components belong in geometry.tsx or imported local modules; material.tsx supplies Material instances; each tasks/*.tsx default-exports defineTask(...); simulate.py owns orchestration. Read the exact declarations and element reference for the props you use. TypeScript acceptance alone does not imply Caemble source-policy acceptance.
4. Keep semantics aligned. Geometry custom props require direct destructuring and defaults. Use stable geometry IDs for durable selectors. Check each element's surface slots. Match Task config and requested artifacts to the exact active Solver descriptor. Define Material models and all coefficients in material.tsx; modelGroups select one supported instance per required group on every target Material. Disambiguate with config.materialModels[role][materialName][groupKey]. Material names never load external coefficients; changing vars rebuilds model parameters. Each numerical Output targets exactly one Box in Experiment or Task geometry and requires gridShape. Rotation is supported; Task and Experiment remain separate scenes, while Solver-specific rules own physical interactions. Declare RecordedData only as { task, output } and pass the matching live Box Grid output to sim.record. Native coupling artifacts belong to Task config.exports; mesh and ray visualizations are included automatically and cannot be recorded or passed to Calculation.
5. Validate in stages. Check paths/import graph and source policy, then use the shared TypeScript compiler and local build/evaluation. Validate simulate.py with the existing CAE Python environment and program validator; Node TypeScript validation does not parse or validate Python. The Python allowlist validates the program and names, not a successful physical solution. Run relevant CAE tests locally.
6. Inspect the build. Inspect fixed variables, explicit Material model snapshots, Task identities, geometry and diagnostics. Render the structure PNG when geometry or selection changed. A preview mesh is evidence about appearance, not proof that the Solver's input, numerical method or recording contracts are correct.
7. Save with the original base identity. Refresh metadata before uploading. When source is locked or the server reports a revision conflict, fetch the current source and reconcile deliberately or create the intended new version. Do not silently overwrite or relabel another revision. Upload source and local build artifacts through their distinct contracts.
8. Test a small simulation first. Build every item locally before submitting a batch. Pin source hash and Catalog revision for the whole batch. Wait for the job's terminal state and RecordedData persistence, inspect errors and required records, then render or compute quantitative checks. Report build success, job success and recorded-result checks separately. Increase batch size only after that evidence is satisfactory.

For a failure, retain stage, message, supplied file/range, source hash and job/measurement IDs. Follow diagnostic.experiment. Do not manufacture a line number for a policy failure that reports only a message. Rebuild after source or Catalog changes. A retry should refer to the same known input, or explicitly be a new experiment condition.

Catalog data stays solely in app/catalog/caemble_catalog/catalog.sqlite3. Read it through the existing Catalog Python library; do not create a JSON/TS/Markdown copy or a separate Node SQLite adapter. User documentation is maintained as shared Markdown and displayed in Documentation and CLI; implementation and operations notes use the development and operations documents.

Executable command sequence (PowerShell 7, from the repository root; Node >=24.14 and the checkout's CAE Python environment installed). Run each command only after the preceding command succeeds. Choose an actual Catalog Example key from the listing; quoted REPLACE values below are user selections, not Catalog identifiers. Output directories must be empty. Configure CAEMBLE_API_URL and a caemble-scope CAEMBLE_API_TOKEN in .env for server operations.

\`\`\`powershell
npm --prefix app/ui run build:cli
$caembleCli = (Resolve-Path app/ui/dist-cli/caemble.cjs).Path
node $caembleCli doctor
node $caembleCli catalog show examples
$exampleKey = 'REPLACE_WITH_LISTED_EXAMPLE_KEY'
node $caembleCli experiment init .work/experiment --example $exampleKey
node $caembleCli agent context experiment --source .work/experiment
node $caembleCli reference show experiment.contract
node $caembleCli reference show experiment.simulate
# Edit the complete source bundle, then check and retain the resulting artifact.
node $caembleCli experiment check .work/experiment --vars-mode nominal --out .work/checked
node $caembleCli png geometry .work/checked --out .work/geometry.png
node $caembleCli experiment test .work/checked --out .work/local-results --timeout 120
node $caembleCli data inspect --result .work/local-results/1
\`\`\`

Both check and build run source/type checks, local input construction and the existing Python simulate.py validator. Neither starts a Solver. check accepts --out and produces the same artifact format as build, so the checked artifact above is already reusable. experiment test consumes that artifact and runs the local Solver; it creates no server batch and uploads no source. Inspect the local manifest, records and numerical expectations before continuing. Ctrl+C during test requests local cancellation and cleanup.

For an existing server Experiment, use experiment pull <id> --out <empty-directory> instead of init, then edit the pulled directory. Preserve its caemble.json baseBundleHash. For a new Experiment, choose the intended namespace/repository/key in that metadata before push. The following is an explicit server write sequence:

\`\`\`powershell
node $caembleCli doctor --api
$saved = node $caembleCli experiment push .work/experiment --artifact .work/checked --json | ConvertFrom-Json
$batch = node $caembleCli batch submit .work/checked --experiment $saved.id --json | ConvertFrom-Json
node $caembleCli batch watch $batch.id
node $caembleCli batch show $batch.id
\`\`\`

push stores source using its base identity and checks its matching artifact. batch submit uploads large already built item bytes directly to S3 and commits their references in the remote batch; it performs no local Solver execution or rebuilding. The local test and server submission above reuse .work/checked exactly. watch emits observation events: Ctrl+C or an observation timeout leaves the remote batch running. Use batch cancel <batch-id> only when cancellation is intended. Inspect the job Measurement IDs returned by batch show with measurement inspect <measurement-id>; fetch persisted records before claiming numerical success.

To build a larger batch after the small test succeeds, use experiment build .work/experiment --count 10 --vars-mode random --out .work/batch-build, then batch submit .work/batch-build --experiment <saved-experiment-id>. All ten inputs are built and validated locally before any batch submission. Keep .work/batch-build for retry or inspection. Rebuild after changing source, variables, explicit Material model snapshots or Catalog; do not reuse an artifact with a different source or Catalog identity. For a locked source, select the intended --new-version patch|minor|major on push, then use the returned Experiment ID.

## 예제 Calculation 등록과 동반 저장

Catalog Draft의 \`catalogctl --database <draft.sqlite3> experiment upsert ... --bundle-file <bundle.json> --calculations-file <calculations.json>\`으로 예제 Version에 Calculation을 등록합니다. Calculation 파일은 \`name\`, 선택적 \`description\`, \`source_code\`를 가진 객체의 JSON 배열입니다. 예제 안에서 이름은 중복될 수 없습니다. 파일을 생략하면 기존 목록을 유지하고, 빈 배열을 지정하면 목록을 비웁니다. 이 파일은 등록 입력이며 최종 카탈로그 데이터는 SQLite에만 보관합니다. 기존 Draft는 \`catalogctl --database <draft.sqlite3> rebase\` 후 사용하고 검증한 Draft를 publish합니다.

예제 상세 조회에는 \`calculations\`가 포함됩니다. \`experiment init --example ...\`은 이를 로컬 \`caemble.json\`에 함께 보관하고 최초 \`experiment push\`에서 Experiment와 한 번에 저장합니다. \`--new-version\`으로 저장하면 서버의 선택한 원본 Version에 저장된 Calculation을 복사합니다. 이름·설명·코드만 복사되므로 대상 Measurement로 Calculation preflight를 다시 수행해야 합니다. 기존 예제에 Calculation 등록은 필수가 아닙니다.

Experiment source와 Record 계약의 덮어쓰기 잠금은 Measurement 존재 여부만으로 결정합니다. Calculation만 있는 Experiment는 덮어쓸 수 있으며, source 또는 Record 계약 변경 시 Calculation 검증 상태가 초기화됩니다.

Outputs always have seven axes in this order: x, y, z, time, frequency, amplitudePhase, component. Unused axes have length 1. Real values use the value channel; complex values use amplitude and phase in radians as two real channels. Spatial point samples lie at Box cell centers, including the center when an axis has length 1. Sampling uses the solved field rather than selecting enclosed nodes; locations outside the solved domain are zero. The static result contract excludes candidate geometry; each saved tensor carries the actual Box transform, size, gridShape and identity. Keep these fields when exporting a complete result.

For deformation playback, inspect the automatically included structural mesh and available nodal displacement history. No mesh or ray output/record declaration is needed. The latest successful invocation per Task supplies its visualization snapshot; accepted physical time history stays inside that snapshot. See [Viewer deformation and playback](../manual/program/program-domain-recording.md) for compatible overlays and verification.

## Material interactions

Export a \`MaterialInteraction\` from \`material.tsx\` with Material endpoints in \`between\` and model instances in \`models\`. There is one declaration per unordered pair, including same-material pairs; distinct models share that object. No Experiment interaction list is needed. Only pairs used by the evaluated Experiment/Task Geometry are captured, while every exported declaration is validated. A \`({ vars }) => ({ between, models })\` definition is evaluated once per Candidate; provide the Vars type with the class type argument when needed.

Use Model Catalog subjects to distinguish single-material and pair models. Task \`config.interactionModels[role][interactionName][group]\` selects an instance when several supported models compete in the same group. Optional-group defaults belong to the Solver contract. Frozen inputs include \`interactions\` and per-Task \`interactionSelections\`; replay verifies the captured selection. See [Material interactions](../manual/program/program-materials.md) and the canonical sliding-contact Experiment in the Catalog for a runnable example.

## 큰 변형 solid의 최종 평형

압축성 초탄성 FEM은 Geometry와 Material, Surface의 고정·지정 변위 조건으로
정의합니다. 현재 지원 조합과 실행 가능한 압축·인장 예제는 Catalog에서
\`hyperelastic\`을 검색해 확인합니다. 같은 Neo-Hookean Material은 MPM에서도
사용할 수 있지만, FEM의 정적 평형과 MPM의 임의 시각 동적 상태는 서로 다릅니다.

Candidate 하나는 vars로 지정한 최종 하중·변위 하나의 평형을 계산합니다.
Solver 내부의 하중 증분은 수렴 절차이며 시간 이력으로 기록하지 않습니다.
서로 다른 하중 조건은 기존 vars와 Batch 흐름으로 계산합니다.

지정 변위는 선택한 world x/y/z 성분만 구속합니다. 예를 들어 x만 지정하면
나머지 방향은 자유롭습니다. 0 고정과 서로 다른 지정 변위를 같은 자유도에
겹치거나, 종속 연결 Surface에 지정하면 오류가 발생합니다. \`fea.pressure\`는
기준 면적·법선으로 정의한 하중입니다. \`fea.follower-pressure\`는 현재 면적과
법선을 따라가는 압력이며 양수가 압축입니다. 두 조건 모두 최종 압력을 vars로
정의할 수 있습니다.

기준 배치 출력은 원래 재료 위치에서, 현재 배치 출력은 변형 후 공간 위치에서
관측합니다. 기본 응력은 Cauchy 응력이며, MPM의 재료 체적 가중 평균과 FEM의
요소 내 sampling은 구분됩니다. Viewer의 배치·가중 평균 표시를 확인합니다.
변위·응력·체적비·전체 변형에너지와 FEM 반력은 기존 RecordedData와 Calculation,
Prediction에서 사용합니다. Native 변형구배·제1 Piola 응력은 연성용 값입니다.

거의 비압축성 재료에는 \`solidFormulation: 'mixed-mini'\`를 명시합니다. 기본값인
\`displacement\`는 기존 변위 기반 tet4이며 Poisson 비에 따라 자동 전환하지 않습니다.
MINI는 하나의 Material을 공유하는 3D solid와 \`0 < nu < 0.5\`, 정적 큰 변형에서
지원합니다. 사용자가 내부 절점이나 압력을 지정하지 않습니다. 실행 가능한
압축·원통 내압 예제는 Catalog에서 \`mixed-mini\`를 검색합니다.

평균압은 Cauchy 응력의 \`-trace(stress)/3\`으로 계산하며 압축이 양수입니다.
내부 보조장 q와 경계의 외부 압력은 이 평균압과 다른 값입니다.
\`strain-energy\`는 FEM·MPM 공통의 \`integral W(F) dV0\` 의미를 유지합니다.
\`equilibrium-energy\`는 MINI의 보조장을 제거한 이산 에너지로, 반력과 외부 일의
검증에 사용합니다. 유한한 메시에서 두 에너지가 달라도 한쪽을 보정하지 않습니다.
이 에너지들은 Box 전체 공간을 필터로 사용하지 않는 전체 모델 집계값입니다.

MINI의 기준·현재 관측에는 요소 내부 bubble 변형을 포함합니다. Native 셀 값은
기준 체적 가중 평균이며 표시용 압력 smoothing을 하지 않습니다. 공간 정련으로
변위·반력·압력·에너지 수렴을 확인하세요. 완전 비압축성 \`nu=0.5\`, 다중 Material
MINI, 초탄성 동적·고유치 해석과 접촉·연결은 지원 범위에 포함되지 않습니다.
`,le=`# Develop and validate a Calculation\r
\r
1. Resolve the target before writing code. Read the ExperimentRecord catalog, Calculation source/base hash if editing, the selected recorded Measurement and the Outputs actually available for it. Calculation accepts only real seven-dimensional Box Grid Outputs. Meshes, ray paths, visualization members and native coupling exports cannot be dependencies. A record schema does not establish that its data exists in every Measurement.\r
2. Read calculation.contract and calculation.declarations. The language is JavaScript with optional JSDoc, exactly one synchronous default-exported function declaration and one identifier parameter. Use only named imports from the shipped Math.js manifest. Do not write TypeScript annotations, an arrow default export, an async function, dynamic imports or general Node/browser code. Some Math.js declaration signatures intentionally use any; runtime shape and numerical behavior still require execution.\r
3. Declare dependencies in the source. Read record.signal or record['group.signal']; use fixed object destructuring or traceable const aliases. Do not enumerate or spread the whole input, pass it to a helper, or choose a record name dynamically. Dynamic numeric indexes inside a leaf array are a different operation; runtime requires non-negative safe integers. Dependency analysis must use the actual available ExperimentRecord names.\r
4. Export a complete input snapshot for reproducibility. Preserve float32/float64 dtype, the complete seven-axis shape and row-major flat data, axes/ticks, quantityKind, units and boxGrid profile plus actual candidate geometry. The seventh axis already contains all components; do not append tensorOrder dimensions. Keep Experiment/Measurement/RecordedData IDs, source hash, Catalog revision and content hashes in a separate provenance envelope. A sample or truncated preview is not an executable complete snapshot. An already-normalized snapshot can execute offline without a Catalog adapter.\r
5. Start from a validated complete example. The synthetic examples here each provide full calculation.js, Box Grid input and expected output. Replace their fixed 'signal' dependency with an actual name and choose numerical assumptions explicitly. Inspect sampling, components and channelUnits before reducing axes; phase and amplitude do not have the same unit.\r
6. Run all layers. Source policy and dependency analysis catch different errors. Type-check against the exact shipped declarations. Execute the common compiled runtime in the CLI's disposable child with bounded time and logs. Check dtype, finite output, inferred rank/shape, numeric axes and units, and assert expected numerical values for at least one relevant fixture. Re-run with the actual server input snapshot before persistence.\r
7. Inspect the result. Scalar output has no axes; rank one renders a line; rank two renders a heatmap; rank three renders a point cloud. Verify orientation, ordering and dimensions using the normalized output, then inspect its PNG. Output must be finite real rank 0/1/2/3 data; ragged arrays, complex final values and an explicit shape field are rejected. Input rank can be higher and needs deliberate reduction.\r
8. Save the right contract. A source-changing save requires successful preflight with the selected server data. Preserve the source hash, exact dependency list and dtype/shape/axes layout from that run. Offline synthetic success is test evidence, not permission to invent a server preflight. For a base-source conflict, fetch and reconcile the current record or save the intended new Calculation. Persist results only for the corresponding Calculation source and Measurement.\r
\r
Report fixture identity/hash, source hash, dependency names, compile/run status, output layout, numerical assertions and bounded logs. Follow diagnostic.calculation for policy, compilation, input, runtime, timeout and output failures. Do not call a timeout or an invalid output a successful calculation. Execution belongs in a disposable process; the shared function alone does not supply a process timeout.\r
\r
Executable synthetic test (PowerShell 7, from the repository root; use an empty .work/calculation directory). reference show returns a structured example field with the exact source, complete input and expected normalized output used by the automated tests. Write UTF-8 without a BOM:\r
\r
\`\`\`powershell\r
npm --prefix app/ui run build:cli\r
$caembleCli = (Resolve-Path app/ui/dist-cli/caemble.cjs).Path\r
node $caembleCli calculation init .work/calculation\r
$example = node $caembleCli reference show calculation.example.mean --json | ConvertFrom-Json\r
Set-Content -LiteralPath .work/calculation/calculation.js -Value $example.example.source -Encoding utf8NoBOM -NoNewline\r
$example.example.input | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath .work/calculation/input.json -Encoding utf8NoBOM\r
node $caembleCli calculation check .work/calculation/calculation.js\r
$fixtureRun = node $caembleCli calculation run .work/calculation/calculation.js --fixture .work/calculation/input.json --out .work/fixture-result.json --json | ConvertFrom-Json\r
if ($fixtureRun.output.data -ne $example.example.expected.data) { throw 'Synthetic mean fixture failed.' }\r
\`\`\`\r
\r
The mean fixture expects the scalar 5. The line and heatmap references have their own full source/input/expected values. check applies source policy and JavaScript/JSDoc type checks without execution. run also resolves fixed dependencies against the selected input, executes with a timeout and validates output. Neither command saves a Calculation or CalculationData.\r
\r
For a real local simulation result, inspect its actual record contract first. Update the source to use those exact record names and physically meaningful operations; the synthetic 'signal' name is not a promised Catalog output:\r
\r
\`\`\`powershell\r
node $caembleCli data inspect --result .work/local-results/1\r
node $caembleCli agent context calculation --source .work/calculation --result .work/local-results/1\r
# Edit calculation.js for these records and assert the expected numerical result.\r
node $caembleCli calculation run .work/calculation/calculation.js --result .work/local-results/1 --out .work/local-calculation.json\r
node $caembleCli png calculation .work/local-calculation.json --out .work/local-calculation.png\r
node $caembleCli data export --result .work/local-results/1 --out .work/result-export\r
\`\`\`\r
\r
The local data export directory contains the Box Grid Record values, automatic visualizations, binary attachments and exact built input with its source bundle and hashes. Calculation reads only the numerical Records. The complete directory remains readable after moving it: use --result with that directory for inspect, slice, Calculation or PNG. Export does not rebuild or run a Solver.\r
\r
For a server Measurement, select IDs from experiment list and completed batch/Measurement metadata; do not substitute arbitrary IDs. Configure the API .env and run doctor --api. When editing an existing Calculation, first calculation pull <id> --out <empty-directory> and retain its revision in caemble.json.\r
\r
\`\`\`powershell\r
$experimentId = 'REPLACE_WITH_SERVER_EXPERIMENT_ID'\r
$measurementId = 'REPLACE_WITH_RECORDED_MEASUREMENT_ID'\r
node $caembleCli agent context calculation --source .work/calculation --experiment $experimentId --measurement $measurementId\r
node $caembleCli calculation run .work/calculation/calculation.js --measurement $measurementId --out .work/server-calculation.json\r
node $caembleCli calculation run .work/server-calculation.json.source.js --fixture .work/server-calculation.json.input.json --out .work/replay.json\r
node $caembleCli calculation push .work/calculation --experiment $experimentId --measurement $measurementId\r
\`\`\`\r
\r
Each run with --out writes the result envelope plus adjacent .input.json and .source.js files. Keep all three: source_hash identifies the exact saved source bytes, input_hash identifies the serialized complete normalized input, and provenance records the selected fixture, local result or remote Measurement. Compare source_hash, input_hash and output between the server capture and offline replay before treating them as the same computation. The replay uses the captured source file even if the editable draft has changed. A fixture alone has no remote provenance; retain the original result envelope with it.\r
\r
push is a server write and performs a fresh preflight using the required server --measurement; offline success cannot replace this step. The Measurement must belong to the target Experiment and have recorded data. A stale revision returns a conflict: pull/reconcile before saving again. To persist calculated results for saved Calculation/Measurement pairs, inspect calculation-data missing --experiment <id> first, then explicitly calculation-data run --experiment <id> --calculation <id> --measurement <id>. This last command writes CalculationData.\r
\r
## Complex RecordedData\r
\r
Complex physical quantities are stored as real amplitude/phase channels on axis 5,\r
with channelUnits describing the quantity unit and radians respectively. The axes\r
are x, y, z, time, frequency, amplitudePhase, component; do not squeeze singleton\r
axes or expect \`{ re, im }\` values. Reconstruct Cartesian values when needed with\r
\`re = amplitude * cos(phase)\` and \`im = amplitude * sin(phase)\`. A zero amplitude\r
has stored phase zero and carries no directional phase information. For spectral\r
fields select samples using frequency-axis ticks, not a wavelength in a result name.\r
Forward Prediction predicts each complete Box Grid before running Calculations;\r
different candidate Boxes correspond at normalized local positions, and the current\r
candidate's actual Box geometry is restored in the predicted input. Mesh and ray\r
visualizations never enter training or Calculation inputs.\r
`,ce=`# Develop a Solver in the existing CAE architecture\r
\r
Read docs/development/solver-development.md and app/slaves/cae/AGENTS.md completely before changing a Solver. Those live files are authoritative; this guide is a navigation and verification checklist, not a replacement ABI or a second Catalog.\r
\r
1. Inspect an existing implementation, its numerical methods, tests and live Solver descriptor. Query Catalog data using the existing Python Catalog library or catalogctl. Capture the intended physical equations, units, domains, boundary conditions, expected observables and numerical tolerances before editing.\r
2. Use a separate Draft SQLite and explicitly pass its path to every catalogctl mutation. Create or clone the Solver's SemVer through catalogctl; published name/version contracts are immutable. Do not use raw SQL, a Node SQLite adapter, a Solver manifest.json, a central registry branch or duplicated Catalog data. The CAE and AI launcher manifests remain launcher executable contracts.\r
3. Declare each Material role's supported model groups in the Solver descriptor. Groups are combined with AND and each group selects exactly one compatible model instance. Model definitions own parameter structure, units and conventions; Solver code owns the numerical implementation. Do not look up coefficients by Material name or duplicate a model schema in the Solver descriptor.\r
4. Implement ABI 3 under app/slaves/cae/app/solvers/<package>/entry.py, with solver-specific domain/formulation/output code nearby. Compose existing methods with explicit values. Preserve kernel.api <- methods <- solvers. The resident coordinator must not eagerly import Solver code; Catalog locators are loaded in the spawned child.\r
5. Return SolverResult with state_patch, requested typed artifacts, automatic visualizations and declared observations. Numerical outputs are real seven-axis Box Grid tensors with x, y, z, time, frequency, amplitudePhase, component axes. Resolve one Experiment/Task Box with required gridShape, use the declared point interpolation or cell-volume quadrature and write zero outside the solved domain. Preserve the Box transform and channel/component metadata. Keep native coupling values in exports and unstructured display values in visualizations; neither is Calculation input or sim.record data. Treat invocation input state as immutable and do not expose Runtime ResourceRef. Different grids with equal shape are not automatically the same physical domain; use the existing supported coupling methods.\r
6. Let simulate.py retain orchestration through sim.run, sim.record and sim.release. The coordinator owns automatic visualization lifetimes and keeps the latest successful invocation per Task. Respect task ownership, cancellation, progress, child lifecycle and both numerical-record and visualization ACK/resource release. Use the real CAE Python validator and tests locally. Do not generate a second Python grammar or add an API-only syntax-check path.\r
7. Add or update a complete executable Example Experiment in the Catalog Draft: literal active Solver name/version and method IDs, geometry/material bindings, outputs, recording schema, units and axes. Use the same integrated Node build path as the CLI/UI through the CAE build adapter, with the Draft explicitly selected where required. Do not keep the old standalone prepare implementation as a parallel compiler.\r
8. Validate the Draft descriptors and build its complete Examples without running a Solver. Local execution uses the canonical Catalog: explicitly publish the intended Draft to canonical SQLite through catalogctl, then rebuild against canonical and use fresh Python processes for execution. The CLI never publishes or redirects Catalog identities automatically. Reconcile all examples against the new active Solver version before removing the old Catalog version.\r
9. Run focused numerical tests, CPU integration and Catalog example build/run checks against that canonical revision. Include boundary/error conditions relevant to the change; do not widen tolerances to obtain a pass. If resource/lifecycle boundaries changed, test cancellation/crash rollback, foreign/released handles, artifact contracts and mmap/child cleanup. Inspect geometry and quantitative output with the CLI's render and Calculation tools. Report CUDA skip separately from a successful GPU test, and coordinate API/UI/CAE deployment with the same tested Catalog release. Old user Experiments are not silently redirected to another Solver version.\r
\r
Finish with the implementation and Catalog changes, Example identity, actual commands/checks run, numerical evidence, source/Catalog hashes and any untested device-specific behavior. Keep user-facing reference in Documentation and architecture/operations in development documentation.

## Particle values and physical arrays

Use \`QuantityArrayValue\` for each physical Particle attribute. It carries the same QuantityKind, UCUM unit, basis/components and array validation as \`FieldValue\`; the Field constructor stays flat. Read the QuantityKind and artifact definitions from the Catalog rather than guessing them from attribute names. Scalars need no component basis. A scalar QuantityKind can also carry an explicit axis of named scalar components, as the existing structural stress Field does. Its labels must be unique and match the final array dimension; this storage axis does not change the physical Tensor order. Explicit compact symmetric Tensor components and Field sample axes retain their declared meaning.

Create particles from canonical Geometry and frozen Material inputs. \`ParticleSetValue\` carries world positions, unique int32 or int64 \`particle_ids\`, \`material_indices\` and a self-contained frozen Material table. Preserve IDs, their declared integer dtype, Material references and physical quantities together when reordering arrays. Keep solver-specific continuation state distinct from portable physical exports. A particle attribute's \`attribute_field(name)\` view shares its array and omits unrelated attributes from the exported domain.

Keep numerical time stepping and computational grids independent from Box Grid observation settings. Save reproducible physical state at each invocation window; leave neighbor-search structures and rebuildable grid workspaces in the child. Export the Particle attributes declared by the native contract, return particle displays through existing automatic visualization Bundles, and record only the declared numerical Box Grid outputs. Check uninterrupted versus split execution, passive observation changes, material/ID correspondence, shared mmap storage and failed-trial rollback.

Use the existing Material and MaterialInteraction selection paths. \`material_model_by_name\` and \`interaction_model_by_name\` support Particle Material references without dummy Geometry. Optional Interaction groups can declare a validated Catalog \`defaultModel\`; explicit invalid or ambiguous selections must still fail. A common body target includes particles and fixed walls. Optional groups preserve Material-pair overrides without requiring explicit models for unused wall–wall contacts.

Command sequence (PowerShell 7, repository root). Read both required files completely; agent context returns their exact checkout text/hash within its explicit budget. The focused tests and physical tolerances still come from the changed implementation.
\r
\`\`\`powershell\r
Get-Content -LiteralPath docs/development/solver-development.md -Encoding UTF8\r
Get-Content -LiteralPath app/slaves/cae/AGENTS.md -Encoding UTF8\r
npm --prefix app/ui run build:cli\r
$caembleCli = (Resolve-Path app/ui/dist-cli/caemble.cjs).Path\r
node $caembleCli doctor\r
node $caembleCli agent context solver\r
Push-Location app/catalog\r
$catalog = 'caemble_catalog/catalog.sqlite3'\r
$draft = '.catalog-work/solver-development.sqlite3'\r
poetry run catalogctl --database $draft draft create --source $catalog\r
poetry run catalogctl --database $draft query solver\r
Pop-Location\r
\`\`\`\r
\r
Apply the documented solver create/clone, typed config/output/input and Example mutations to that Draft, always with --database. Read the live Catalog CLI help for the specific descriptor command; the guide deliberately does not invent a Solver identity or duplicate Catalog rows. Edit implementation and tests in the checkout. Then choose the newly authored Example:\r
\r
\`\`\`powershell\r
$draftCatalog = (Resolve-Path app/catalog/.catalog-work/solver-development.sqlite3).Path\r
node $caembleCli catalog show examples --catalog $draftCatalog\r
$exampleKey = 'REPLACE_WITH_DRAFT_EXAMPLE_KEY'\r
node $caembleCli experiment build --example $exampleKey --catalog $draftCatalog --vars-mode nominal --out .work/draft-build\r
\`\`\`\r
\r
The Draft build checks declarations, policy, input construction and simulate.py validation only; it is not a numerical test. Inspect its diagnostics and frozen inputs. Publishing below is an explicit change to the canonical Catalog, performed only for the intended validated Draft:\r
\r
\`\`\`powershell\r
Push-Location app/catalog\r
poetry run catalogctl --database $draft publish --destination $catalog\r
Pop-Location\r
node $caembleCli doctor\r
node $caembleCli experiment build --example $exampleKey --vars-mode nominal --out .work/solver-build\r
node $caembleCli experiment test .work/solver-build --out .work/solver-results --timeout 120\r
node $caembleCli data inspect --result .work/solver-results/1\r
Push-Location app/slaves/cae\r
poetry run python -m pytest tests -m "not cuda"\r
poetry run python -m pytest tests/test_fdtd_cuda.py -m cuda\r
Pop-Location\r
\`\`\`\r
\r
Do not execute .work/draft-build against a different canonical revision. After publish, the canonical rebuild above makes the active identity explicit. CPU integration fixtures invoke the same CLI experiment build to create inputs; the Python test harness then runs Solver children and asserts numerical/resource behavior. A pytest fixture must not call experiment test or recursively start pytest. The standalone experiment test above is a separate user command and submits no remote jobs. Keep its manifest and record data with source/Catalog hashes, and use the Calculation guide to create quantitative assertions and reproducible plots.\r
`;function j(r){return r.replace(/\r\n/g,`
`).replace(/^# [^\n]+\n+/,"").trimEnd()}function i(r){return j(r).replace("{{calculation.source}}",()=>Y.trimEnd()).replace("{{calculation.mathjs}}",Z.map(({group:t,names:o})=>`- **${t}**: ${o.map(u=>`\`${u}\``).join(", ")}`).join(`
`))}const de=[{id:"experiment",title:"Develop and test an Experiment source bundle",summary:"Read the live contract, edit the complete bundle, build locally, then run and inspect recorded results.",sourcePaths:["docs/authoring/experiment.md","AGENTS.md","app/ui/src/lib/cad/api/caemble-core.d.ts","app/ui/src/lib/cad/api/cad-jsx.d.ts","app/ui/src/lib/cad/elements/manifest.json","app/ui/src/lib/cad/source/sourceAnalysis.ts","app/ui/src/lib/cad/source/sourcePolicy.ts","app/ui/src/lib/cad/source/moduleResolution.ts","app/slaves/cae/app/kernel/coordinator/program.py","app/ui/scripts/test-catalog-examples.ts"],referenceIds:["experiment.contract","experiment.modules","experiment.materials","experiment.geometry","experiment.simulate","diagnostic.experiment"],content:j(se)},{id:"calculation",title:"Develop and validate a Calculation",summary:"Use precise JavaScript and fixed record dependencies, execute against a reproducible input snapshot, then save the validated contract.",sourcePaths:["docs/authoring/calculation.md","app/ui/src/lib/calculation/declarations.ts","app/ui/src/lib/calculation/policyContract.ts","app/ui/src/lib/calculation/sourcePolicy.ts","app/ui/src/lib/calculation/dependencies.ts","app/ui/src/lib/calculation/validation.ts","app/ui/src/lib/calculation/mathjsManifest.ts","app/ui/src/authoring/examples.ts","app/ui/src/platform/node/calculation.ts"],referenceIds:["calculation.contract","calculation.declarations","calculation.dependencies","calculation.snapshot","calculation.example.mean","calculation.example.line","calculation.example.heatmap","diagnostic.calculation"],content:j(le)},{id:"solver",title:"Develop a Solver in the existing CAE architecture",summary:"Use the live Catalog Draft workflow and ABI 3 implementation, then validate a complete Experiment through the common builder.",sourcePaths:["docs/authoring/solver.md","docs/development/solver-development.md","app/slaves/cae/AGENTS.md","app/slaves/cae/app/kernel/api","app/slaves/cae/app/methods","app/slaves/cae/app/solvers","app/catalog/caemble_catalog","app/slaves/cae/tests"],referenceIds:["solver.workflow","experiment.contract","experiment.simulate","diagnostic.experiment"],content:j(ce)}],me=`# CAE Workbench 빠른 시작\r
\r
Caemble의 Experiment는 공통 형상과 변수, Material, solver Task, 실행 프로그램과 RecordedData 계약을 하나의 source bundle로 관리합니다.\r
\r
## 시작 페이지와 Showcase\r
\r
\`/\`에 접속하면 로그인 상태에서는 \`/workbench\`, 비로그인 상태에서는 \`/showcase\`로 이동합니다. 두 주소는 로그인 여부와 관계없이 직접 열 수 있습니다. 특정 저장 버전은 \`/workbench?experiment=ID\`로 바로 엽니다. 기존 \`/?experiment=ID\`와 \`/?help=...\` 링크도 Workbench로 연결됩니다.\r
\r
Showcase는 접근 가능한 저장 Experiment와 공개 Demo를 4:3 이미지 카드로 표시합니다. 첫 진입 시 대표 Demo를 선택하며, 카드 선택 시 오른쪽 Viewer에서 형상과 가장 최근 기록 완료 Measurement를 확인할 수 있습니다. Showcase 탐색은 Workbench의 로컬 작업을 변경하지 않습니다. Catalog 예제는 Workbench 리본의 **Examples**에서 엽니다.\r
\r
같은 namespace·Repository·key의 버전은 최신 버전 카드 하나로 묶입니다. 카드 하단 우측의 버전 배지를 누르면 이전 버전을 선택할 수 있습니다. 이름·설명·key 검색, Repository 다중 필터, 생성일·이름·Measurement 수 정렬을 지원하며 기본은 생성일 최신순입니다. 생성일과 Measurement 수는 대표 버전 기준이며 이전 버전의 수를 합산하지 않습니다.\r
\r
카드 상단의 편집 버튼은 해당 버전을 선택한 Workbench로 이동합니다. 삭제 권한이 있는 카드의 삭제 버튼은 해당 버전만 삭제하며 연결 데이터도 확인합니다. 썸네일이 없거나 불러올 수 없으면 기본 대표이미지를 표시합니다. Workbench에서 저장하면 현재 Viewer 화면으로 썸네일을 만들 수 있습니다.\r
\r
## Workbench 진입\r
\r
복원할 로컬 작업이나 URL로 지정한 Experiment가 없으면 **Experiment** 화면에서 첫 namespace의 첫 Experiment를 자동으로 엽니다. 저장된 Experiment가 없으면 첫 예제를 엽니다. 기존 로컬 작업과 저장된 선택은 재방문 시 복원됩니다.\r
\r
저장된 Experiment를 열면 결과가 기록된 Measurement 중 가장 최근 항목을 자동으로 불러옵니다. 해당 Measurement의 Vars·Material과 RecordedData가 적용되고 ray 경로 등 지원되는 결과가 Viewer에 표시됩니다. 기록된 결과가 없으면 Experiment만 표시하며 Solver를 자동 실행하지 않습니다.\r
\r
## Experiment 레이아웃과 불러오기\r
\r
Experiment 탭은 왼쪽 Viewer, 오른쪽 코드 편집기로 나뉘며 기본 너비는 50:50입니다. 가운데 구분선을 드래그하거나 포커스 후 방향키로 크기를 조절합니다. Viewer 확대와 하단 Console은 계속 사용할 수 있습니다. 다른 탭 레이아웃은 유지됩니다.\r
\r
리본의 **New**는 새 작업을 시작합니다. **Examples**는 이름·설명·좌표·버전을 한 행씩 표시하는 검색 가능한 Catalog 목록입니다. 항목 선택 후 **적용**하면 소스와 Calculation 정의를 함께 가져옵니다.\r
\r
**Load**에서는 Showcase 카드와 독립된 Viewer로 저장 버전과 최신 기록 완료 Measurement를 미리 봅니다. 버전 배지로 이전 버전도 선택할 수 있습니다. **불러오기**를 눌러야 Workbench에 적용하며 취소하면 현재 작업을 유지합니다. 미저장 편집이 있으면 교체를 확인하고, 실행 중에는 작업 교체가 제한됩니다.\r
\r
## Measurement 탭\r
\r
Measurement는 실행 입력을 만들고 구조·예측·실측을 확인하는 별도 탭입니다. 탭 순서는 Experiment → Measurement → Calculation → Prediction → Analysis입니다. 기존 Calculation 편집은 Calculation 탭에서 계속 사용합니다.\r
\r
좌우 기본 비율은 50:50입니다. 왼쪽 위에는 Vars PCA, 아래에는 Vars 편집기가 표시됩니다. 오른쪽 영역의 맨 위에는 두 Viewer가 공유하는 데이터 선택·설정 툴바가 있고, 그 아래 왼쪽에는 구조와 Forward 미리보기, 오른쪽에는 실제 결과가 50:50으로 표시됩니다. 각 구분선은 드래그와 방향키로 조절합니다.\r
\r
### Vars 편집\r
\r
편집기 왼쪽의 동일 크기 버튼은 이름과 scalar 값, 또는 tensor의 shape·평균을 보여줍니다. 항목을 선택하면 오른쪽에 편집기가 열립니다.\r
\r
- Scalar: 숫자 직접 입력과 수직 슬라이더를 사용합니다. 위쪽은 max, 아래쪽은 min입니다.\r
- 1D tensor: 원소별 숫자 입력·수직 슬라이더가 가로로 나열됩니다.\r
- 2D tensor: shape에 맞는 숫자 입력 Grid를 사용합니다.\r
- 3D 이상: 앞쪽 축의 인덱스를 선택하여 마지막 두 축의 단면을 편집합니다.\r
\r
숫자는 Enter 또는 포커스 이동으로 확정하고 Escape로 되돌립니다. 미확정·잘못된 입력이 있으면 저장·Run이 비활성화됩니다. schema 범위를 벗어난 입력은 Vars에 반영하지 않습니다.\r
\r
원소 인덱스를 클릭하여 선택하고 Ctrl/Cmd로 추가 선택, Shift로 범위 선택을 합니다. Grid에서는 인덱스를 드래그하거나 Shift+방향키로 사각 영역을 선택할 수 있습니다. **전체 tensor** 또는 **선택**에 대해 채우기·더하기·곱하기를 적용합니다. 하나라도 범위를 벗어나면 전체 작업을 반영하지 않습니다.\r
\r
**Shuffle · 전체**는 선택한 tensor의 모든 원소를 min/max 범위에서 다시 무작위 생성합니다. 고차원 tensor의 보이지 않는 단면도 포함하며 다른 Var는 변경하지 않습니다. 편집과 Shuffle은 Solver를 실행하지 않습니다.\r
\r
### PCA와 후보 생성\r
\r
PCA는 Measurement와 후보의 Vars를 schema 범위로 정규화하여 분석하며 경계 가상점을 추가하지 않습니다. 점을 클릭하면 해당 Vars를 선택합니다. 빈 공간을 클릭하면 PCA 거리 기준 최대 7개 이웃의 Vars를 거리 역수로 평균하고, PC1·PC2를 클릭 좌표로 이동시켜 후보를 만듭니다. 범위를 벗어나면 보정된 위치를 표시합니다.\r
\r
편집 중에는 PCA 축과 이웃을 고정하므로 같은 위치를 반복 클릭해도 Vars가 누적 변경되지 않습니다. **PCA 갱신**은 편집값을 분석에 반영합니다. 분산이 없는 경우 먼저 후보를 생성합니다.\r
\r
**Random**은 범위 내 균등 난수로 N개 후보를 만듭니다. **빈 구간 LHS**는 각 성분에서 기존 Measurement와 후보가 차지한 구간을 제외합니다. 빈 구간이 N개 미만이면 분할을 늘려 고르게 생성합니다. 기본 N은 10입니다. 생성 후 후보를 선택하여 구조를 확인하고 **선택 Run** 또는 **전체 후보 Run**을 누릅니다. **후보 추가**는 현재 편집값을 후보 목록에 넣습니다.\r
\r
후보는 탭 이동 동안 유지됩니다. 새로고침 후에도 남기려면 **Prepared 저장**을 사용합니다. Run은 검토한 Vars를 그대로 제출하며 Prepared Measurement는 기존 ID로 실행합니다. Recorded Measurement는 재실행하지 않습니다. 실패·취소 상태는 후보에서 확인합니다.\r
\r
### Forward와 실제 결과 비교\r
\r
**Forward 모델 생성**과 **모델 업데이트**는 수동 작업입니다. 생성한 모델이 있으면 Vars 변경 후 예측만 자동으로 갱신합니다. 새 데이터가 생겨도 자동 학습하지 않으며 업데이트 필요 상태를 표시합니다. 모델은 탭 이동 동안 유지하고 새로고침·Experiment/source/schema/사용자 변경 또는 Worker 소실 시 다시 생성해야 합니다.\r
\r
Forward는 기존 숫자형 Box Grid RecordedData를 지원합니다. 다른 형식은 실제 결과를 조회할 수 있으며 예측 미지원 사유를 표시합니다. CalculationData 편집과 파생 결과 분석은 기존 탭을 사용합니다.\r
\r
Recorded Measurement를 선택하면 실제 결과 Viewer의 비교 기준이 됩니다. Vars를 수정해도 해당 실측과 실행 당시 구조·재료는 유지하며 현재 Vars와 다름을 표시합니다. 데이터 항목·시각화 방식·성분·축·집계·단면·Overlay·재생 설정은 공통 툴바에서 함께 조절하고, 카메라는 독립적으로 조작합니다. 자동 색상 범위는 각 Viewer의 데이터에서 계산하며 직접 고정한 범위는 양쪽에 동일하게 적용합니다.\r
\r
Vars 조절로 Forward 결과가 갱신되거나, 실측을 교체하거나, 모델을 업데이트해도 설정과 카메라는 초기화되지 않습니다. 로딩·오류·데이터 누락 중에도 설정을 보존하고, 재생은 갱신 중 위치를 유지했다가 이어갑니다. 항목별 설정은 다른 항목을 보고 돌아오거나 탭을 이동해도 유지됩니다. 새 데이터의 shape에 적용할 수 없는 성분·단면·프레임은 자동 보정하지 않고 해당 Viewer에 이유를 표시하므로 공통 툴바에서 수정하세요. 새 작업공간·Experiment를 열거나 페이지를 새로고침하면 새 세션 기본값을 사용합니다.\r
\r
각 Viewer는 최초 구조나 결과가 준비되고 화면에 표시되면 콘텐츠 전체가 보이도록 카메라를 자동으로 맞춥니다. 이후 데이터 갱신에는 카메라를 유지합니다. **전체 맞춤**을 누르면 현재 콘텐츠의 중심과 크기에 다시 맞춥니다.\r
\r
## Save와 Save As\r
\r
- **Save**: Draft이면 Save As를 엽니다. 저장된 Experiment는 서버의 최신 사용량을 확인하여 Measurement가 없으면 덮어쓰고, 하나라도 있으면 해당 Experiment를 대상으로 Save As를 엽니다. 읽기 전용 항목은 Save As로 복사합니다.\r
- **Save As**: 기본은 새 Experiment입니다. 기존 작업의 key에는 \`-copy\`를 제안합니다. 같은 저장 위치의 key가 이미 있으면 다른 key를 입력하거나 왼쪽 카드를 선택하세요.\r
- 왼쪽의 쓰기 가능한 카드를 선택하면 저장 대상의 namespace·Repository·key가 고정됩니다. 현재 소스·이름·설명·Viewer는 그대로 유지됩니다. 대상 계열의 최신 버전에서 Patch(기본), Minor 또는 Major를 증가시킵니다. 기존 대상의 Calculation 정의를 계승하며 새 Experiment는 현재 작업의 Calculation 복사 정책을 따릅니다.\r
- 저장 후에도 모달은 열려 있고 저장된 카드가 선택됩니다. Workbench 선택과 URL도 갱신됩니다. **닫기**로 종료합니다. 동시 변경으로 저장이 거부되면 갱신된 목록과 사용량을 확인한 후 다시 저장하세요.\r
\r
Save As를 열 때 Viewer의 Geometry·결과 표현·범례를 고정 이미지로 캡처합니다. 툴바와 메뉴는 제외합니다. 큰 Preview 위의 4:3 사각형을 드래그해 이동하고 우측 하단 핸들로 크기를 조절하세요. 처음에는 중앙 최대 영역이 선택됩니다. 키보드로는 사각형에 포커스한 뒤 방향키로 이동하고, 핸들에 포커스한 뒤 오른쪽·아래 방향키로 확대하거나 왼쪽·위 방향키로 축소합니다. Shift를 함께 누르면 조절 폭이 커집니다. 직접 Save도 중앙 최대 영역을 사용합니다. 저장 형식은 최대 640×480 WebP, 512KiB입니다. 빈 화면이나 캡처 실패 시 이유를 표시하며, 덮어쓰기는 기존 이미지를 유지하고 신규 저장은 기본 이미지를 사용합니다.\r
\r
완료된 유효한 Preflight가 있으면 **Preflight 결과 함께 저장**이 기본으로 켜집니다. 리본과 Save As에서 같은 옵션을 사용합니다. 저장 소스·결과 계약이 실행 당시와 일치해야 하며 본인 소유의 성공 결과만 24시간 안에 저장할 수 있습니다. 만료되거나 불일치하면 다시 실행하거나 포함 옵션을 해제하세요.\r
\r
함께 저장한 Preflight는 Solver 재실행 없이 기록 완료 Measurement가 됩니다. 실행 당시 Vars·Material·Geometry·RecordedData·시각화·실행 추적과 저장 객체를 독립적으로 보존하므로 임시 결과의 만료 정리와 다른 저장본 삭제에 영향을 받지 않습니다. 서버 저장이 성공하면 새 Measurement를 선택하고 임시 Preflight 표시를 영구 결과로 전환합니다.\r
\r
## 먼저 준비할 것\r
\r
형상과 문서는 로그인 없이 살펴볼 수 있습니다. 서버에 Measurement를 저장하고 Solver를 실행하려면 로그인과 사용 가능한 내 CAE Launcher가 필요합니다. 실행 전에 **Setting → Launchers**에서 연결 상태를 확인하세요.\r
\r
## 첫 실행의 목표\r
\r
| 단계      | 할 일                                           | 확인할 결과                                                  |\r
| --------- | ----------------------------------------------- | ------------------------------------------------------------ |\r
| 작성      | Experiment에서 예제를 열고 Source를 확인합니다. | source 상태가 \`Ready\`이고 Viewer에 형상이 보입니다.          |\r
| 조건 확인 | Vars와 Material Parameter를 확인합니다.         | 원하는 Candidate의 형상과 값이 일치합니다.                   |\r
| 저장·실행 | Measurement를 준비하고 실행합니다.              | CAE Jobs에 작업이 등록되고 Console에 진행 상태가 표시됩니다. |\r
| 결과 확인 | 완료된 Measurement를 선택합니다.                | RecordedData가 표시되고 Calculation에서 계산할 수 있습니다.  |\r
\r
## 순서대로 진행하기\r
\r
1. 로그인하고 CAE Launcher가 연결되어 있는지 확인합니다.\r
2. 상단 **Experiment** 메뉴를 선택하고 **Load**로 저장 버전을 불러오거나 **Examples**에서 예제를 적용한 뒤, 오른쪽 Source 탭에서 source bundle을 작성합니다.\r
3. source 상태가 \`Ready\`가 될 때까지 compile/evaluate 오류를 해결합니다.\r
4. **Generate Candidate**로 \`varsSchema\` 범위의 새 변수 조건과 그 조건에서 만든 Model Parameter를 미리 봅니다.\r
5. 원하는 조건이면 **Save Current Measurement**로 변수와 Material snapshot을 고정합니다. 이 단계는 solver를 실행하지 않습니다.\r
6. 상단 **Calculation** 메뉴의 왼쪽 점 배열에서 prepared Measurement를 선택합니다. Ctrl/Cmd+클릭으로 여러 항목을 선택하고 Shift+클릭으로 현재 페이지의 범위를 선택할 수 있습니다.\r
7. **Generate & Run**은 브라우저에서 새 Candidate와 실행 입력을 build한 뒤 서버에 batch로 제출합니다. **Save & Run**은 화면에서 확인한 Vars와 Material snapshot을 그대로 고정하여 build합니다.\r
8. 횟수를 입력하고 **Sample & Run**을 누르면 Vars 범위에서 Monte Carlo(random) 방식으로 후보를 뽑고, 브라우저에서 모든 실행 입력을 먼저 build한 뒤 한 번의 batch로 제출합니다. Prediction의 Sample & Run은 기존 LHS 후보 선택 방식을 사용합니다. 기본값은 10이며, N은 성공 횟수가 아니라 전체 시도 횟수입니다. 서버가 사용 가능한 내 Launcher에 작업을 하나씩 배분합니다.\r
9. build와 업로드가 끝나 서버 접수가 완료되면 브라우저를 닫아도 CAE 계산은 계속됩니다. 로컬 build나 업로드 중에는 브라우저를 유지하세요. 작업별 진행률과 완료·실패 알림은 **Console**에 표시됩니다. **Setting → CAE Jobs**에서 배치 목록과 오류를 확인하고 실패한 작업을 명시적으로 재시도할 수 있으며, **Batch 취소**는 아직 끝나지 않은 작업을 취소합니다.\r
10. 기존 Prepared Measurement는 **Run**으로 실행합니다. 실행이 실패한 작업은 **CAE 작업**에서 재시도하세요. 서버나 worker 연결 중단을 포함한 실패는 자동으로 다시 실행하지 않습니다.\r
11. CAE worker가 큰 결과 본문을 S3에 직접 업로드하고 서버에 RecordedData 참조가 원자적으로 저장되면 Measurement는 Recorded 상태가 됩니다. 선택 중인 Measurement의 결과는 서버 완료 이벤트를 받은 뒤 즉시 다시 불러옵니다.\r
\r
큰 BuiltMeasurement와 결과 본문은 Client ↔ S3 ↔ Slave 경로로 전달됩니다. 브라우저는 결과를 S3에서 직접 읽고, 서버는 권한·참조·작업 상태를 관리합니다.\r
\r
## 실행 전후에 기억할 점\r
\r
Measurement는 immutable Experiment revision을 가리킵니다. 생성 요청의 source hash가 현재 revision과 다르면 저장이 거부되므로, source가 바뀌면 새 revision에서 새 Measurement를 준비하세요.\r
\r
Task 파일이 하나도 없는 Experiment도 Geometry preview와 Experiment 저장은 사용할 수 있습니다. 이 경우 Measurement 생성·선택·분석과 Simulation 실행은 Task를 추가할 때까지 비활성화됩니다.\r
\r
## 다음 단계\r
\r
- source가 준비되지 않으면 [Ready 문제 해결](../troubleshooting/troubleshooting-ready.md)을 확인하세요.\r
- 실행 후에는 [Calculation으로 결과 계산](workbench-calculation.md)을 이어서 진행하세요.\r
- 정확한 문법이나 완성 예제는 Help의 **Geometry**, **Solver**, **Examples**에서 찾을 수 있습니다.\r
`,ue=`# 편집, Candidate 생성과 실행 결과의 관계\r
\r
Source를 수정하면 \`Dirty → Checking → Compiling → Evaluating → Ready\` 순서로 검증됩니다. \`Error\`가 보이면 가장 먼저 diagnostics의 파일명과 line을 확인합니다.\r
\r
- **Source 수정**은 새 revision을 compile합니다.\r
- **Generate Candidate**는 source를 바꾸지 않고 완전한 새 vars를 생성해 preview합니다.\r
- Measurement의 **Vars** 패널에서는 현재 Candidate의 \`varsSchema\` key를 선택해 scalar·1-D 막대 또는 2-D/N-D heatmap으로 값을 직접 편집할 수 있습니다. 편집값은 Viewer에 다시 평가되며 schema의 min/max를 벗어날 수 없습니다.\r
- Candidate는 저장 전까지 임시 상태이며 provenance나 seed 계약이 아닙니다.\r
- **Save Current Measurement**는 현재 vars와 Material snapshot을 고정하지만 solver를 실행하지 않습니다.\r
- **Save & Run**은 화면의 현재 수동 Candidate를 새 Prepared Measurement로 저장한 뒤 그대로 실행합니다. **Generate & Run**과 달리 새 무작위 Candidate를 만들지 않습니다.\r
- 선택한 prepared Measurement만 실행할 수 있고, Recorded 상태가 된 Measurement는 다시 실행할 수 없습니다.\r
\r
새 조건으로 다시 계산하려면 기존 Measurement를 덮어쓰지 말고 새 Candidate를 생성한 뒤 새 Measurement로 저장하세요.\r
`,pe="# Calculation으로 RecordedData 후처리\r\n\r\n상단 **Calculation** 메뉴는 왼쪽부터 3D Viewer, Calculation Source Editor, Return 차트와 로그를 표시합니다. 기본 열 비율은 30/40/30이며 우측은 Return 차트와 현재 실행의 `console.log`를 65/35로 나눕니다. 열 경계와 차트/로그 경계는 드래그하거나 키보드 방향키로 조절하며 마지막 Workbench draft에 저장됩니다. Viewer를 확장하면 작업 영역 전체에 Viewer를 표시합니다.\r\n\r\n리본의 **Measurement**와 **Calculations** 버튼으로 목록 팝업을 열어 확인·선택합니다. 현재 선택은 리본에 표시되며, **새 Calculation**은 새 draft를 만듭니다. Calculation 삭제는 목록 팝업에서 수행합니다. 저장하지 않은 코드가 있으면 Calculation 변경 전에 확인합니다. Candidate Vars 편집과 시뮬레이션 실행은 **Measurement** 탭에서 수행합니다. Calculation 리본에는 Candidate 생성·저장, 시뮬레이션 Run, Analysis 버튼이 없습니다.\r\n\r\n**ExperimentRecord** 팝업에는 Experiment가 선언한 모든 Record가 표시됩니다. **Used**는 현재 source가 참조하는 Record, **RecordedData Ready/Missing/Invalid**는 선택 Measurement의 실제 값 상태입니다. 이름으로 검색하거나 각 행의 **Insert**로 현재 Source Editor selection에 `record[\"group.signal\"]` 형식의 고정-key 참조를 삽입합니다. 삽입하면 팝업이 닫힙니다. 행 자체를 누르는 것은 source를 변경하지 않습니다.\r\n\r\n우측 하단 `console.log`는 명령 입력창 없는 읽기 전용 목록입니다. 호출 순서와 여러 줄 값을 모아 표시하고, 코드나 선택이 바뀌면 이전 실행의 로그를 지우고 현재 실행 결과로 갱신합니다. **미리보기 갱신**으로 수동 재계산할 수도 있습니다. 실행 오류 이전의 로그는 남으며 출력 제한에 도달하면 안내를 표시합니다. 공통 Console 도크에도 실행 활동이 기록됩니다.\r\n\r\nCalculation 리본의 **저장**를 누르면 이름과 설명을 입력하는 저장 모달이 열리고 현재 source와 함께 명시적으로 저장합니다. 새 Calculation, source가 바뀐 Calculation, 기존의 미계약 Calculation은 선택한 Recorded Measurement에서 최신 preview가 성공해야 저장할 수 있습니다. 저장 시 source hash, 정적으로 확인한 ExperimentRecord dependency, preflight Measurement와 Output의 dtype·정확한 shape·axes가 하나의 고정 계약으로 기록됩니다. 이름이나 설명만 바뀌고 source hash가 같으면 기존 계약을 재사용합니다. 저장하지 않은 source도 선택 Measurement에 대해 500ms 뒤 자동 실행하지만 Output은 DB에 저장하지 않습니다.\r\nCalculation 리본의 **후처리 데이터** 그룹에서는 **Selected Calc**로 선택 Calculation과 모든 미저장 Recorded Measurement를, **Selected Measurement**로 현재 Measurement와 모든 저장 Calculation을, **All Missing**으로 전체 미저장 조합을 순차 계산해 저장합니다. 진행 중에는 완료 수와 현재 대상을 표시하며 **Cancel Data**로 남은 작업을 취소할 수 있습니다. 이미 저장된 성공 결과는 취소나 일부 실패가 발생해도 유지됩니다.\r\nCalculation 탭의 Measurement 팝업에 표시되는 점은 **회색=Run 전**, **노란색=Recorded이지만 Calculation 미완료**, **초록색=모든 저장 Calculation 완료**를 뜻합니다. 점의 tooltip과 접근성 label에는 `완료 수/전체 수`가 표시됩니다. 저장된 Calculation이 하나도 없으면 Recorded Measurement는 `0/0 완료`이므로 초록색입니다. Calculation 목록을 확인하는 중이거나 조회에 실패하면 Recorded 점은 중립색으로 표시됩니다.\r\n**Save & Run**, **Generate & Run**, **Repeat Run**, 기존 Measurement의 **Run**은 열린 브라우저에서 해당 실행을 관찰하는 동안 RecordedData 저장 후 기존 CalculationData 후처리를 순차 실행합니다. CAE batch 완료는 RecordedData 저장을 기준으로 표시하며 CalculationData 오류는 별도로 Console에 남습니다. 브라우저를 닫으면 후처리는 중단되고 재접속만으로 자동 재개되지 않습니다. 필요한 데이터는 **All Missing** 또는 선택 Calculation의 Missing 실행으로 계산하세요. Prediction의 Sample & Run 반복도 브라우저에 남으며 재접속 시 자동 재개되지 않습니다.\r\n저장된 Calculation source를 변경하면 이전 source로 만든 CalculationData는 자동 삭제되어 다시 미저장 상태가 됩니다. 이름이나 설명만 바꾼 경우에는 유지됩니다. 미저장 또는 수정 중인 draft는 일괄 계산 대상이 아닙니다.\r\n현재 Output이 scalar이면 다른 Measurement에 저장된 같은 CalculationData를 Histogram으로 표시하고 현재 선택 Measurement의 최신 preview 위치를 주황색 marker로 겹쳐 표시합니다. 새 Calculation이나 수정 중인 draft, 비교 데이터가 없는 경우에는 현재 반환값만 차트로 표시합니다. 별도의 숫자 요약 패널은 없습니다.\r\n\r\n\r\n\r\nSource는 순수 JavaScript의 동기 `default export` 함수 하나여야 합니다. TypeScript 문법과 JSX는 허용하지 않으며, package import는 `mathjs`의 named import만 허용합니다. Editor는 허용된 Math.js 함수 signature를 안내하고 입력과 Output 계약은 실행 과정에서 검증합니다. 디버깅에는 frozen console의 `log`만 사용할 수 있으며 `console.log(...)`, `console['log'](...)`, `const log = console.log` 같은 alias를 지원합니다. 다른 console API는 허용하지 않습니다.\r\nSource policy 오류가 발생하면 Editor가 문제가 된 코드를 밑줄로 표시하고 Return 차트에 줄·열, 거부 이유와 코드 조각을 표시하고 우측 하단 로그에도 오류를 표시합니다. 자동 preview는 오류 위치로 커서나 스크롤을 이동시키지 않습니다.\r\n\r\n```js\r\n{{calculation.source}}\r\n```\r\n\r\nExperiment를 저장하면 컴파일된 Box Grid RecordedData 선언이 이름별 **ExperimentRecord** 계약으로 함께 저장됩니다. QuantityKind, tensorOrder, dtype, 7차원 data schema와 정적 `boxGrid` profile은 이 계약에서 제공됩니다. Measurement의 RecordedData는 ExperimentRecord ID, 실제 tensor 값과 실행 당시 Box geometry를 저장합니다. 자동 mesh·ray 시각화와 native coupling export는 ExperimentRecord나 Calculation dependency가 아닙니다.\r\n\r\nCalculation 입력은 ExperimentRecord 이름을 key로 쓰는 읽기 전용 map입니다. `record.signal`, `record['group.signal']`, 정적 object destructuring과 추적 가능한 `const` alias만 dependency로 허용합니다. `record[key]`, `Object.keys/values/entries(record)`, spread, Record 전체 전달·반환, 재할당과 존재하지 않는 key는 정확한 source 위치가 있는 저장 오류입니다. 각 leaf에는 float32/float64 `dtype`, 정확히 7차원인 `shape`, row-major flat `data`, `[x, y, z, time, frequency, amplitudePhase, component]` 전체 `axes`, `boxGrid`, `quantityKind`, `tensorOrder`, 값 `unit`이 있습니다. Component는 마지막 축에 포함되며 별도 차원을 덧붙이지 않습니다. 복소수는 진폭·위상 두 채널로 읽고 위상 단위는 rad입니다.\r\nCalculation에 전달되는 axis는 실제 shape와 정확히 맞지만 ticks는 숫자 또는 문자열일 수 있습니다. 기본 템플릿은 원본 axis를 그대로 반환하므로 문자열 ticks는 Output 계약 오류가 됩니다. 필요한 경우 ticks를 숫자로 변환하거나 Output에서 `axes`를 생략해 ordinal axis를 사용하세요.\r\n\r\n### Tensor 연산\r\n\r\nRecordedData의 flat row-major data는 Math.js `reshape`로 원래 tensor shape를 복원할 수 있습니다. 고차원 결과는 마지막 축부터 `mean`을 적용하면 원하는 축만 남길 수 있습니다.\r\n\r\n```js\r\nimport { index, map, mean, range, reshape, subset, transpose } from 'mathjs'\r\n\r\nconst source = record.signal\r\nconst flat = Array.isArray(source.data) ? source.data : [source.data]\r\nlet tensor = reshape(flat, source.shape.length > 0 ? source.shape : [1])\r\n\r\n// 첫 두 축만 유지하고 나머지 축을 평균합니다.\r\nfor (let axis = source.shape.length - 1; axis >= 2; axis -= 1) {\r\n  tensor = mean(tensor, axis)\r\n}\r\n\r\n// 영역 선택, element-wise 변환, 축 교환\r\nconst window = subset(tensor, index(range(0, 10), range(0, 20)))\r\nconst doubled = map(window, (value) => value * 2)\r\nconst swapped = transpose(doubled)\r\n\r\n// 동적으로 계산한 숫자 index도 일반 bracket 문법으로 읽고 쓸 수 있습니다.\r\nconst base = 2\r\nconst sample = flat[base]\r\n```\r\n\r\n`reshape`는 shape 변경, `mean`/`sum`은 축약, `subset`과 `index`는 slicing, `map`은 element-wise 변환, `transpose`와 `squeeze`는 축 정리에 사용합니다. 빈 축의 2차원 shape를 유지해야 할 때는 `zeros(rows, columns)`를 반환할 수 있습니다.\r\n\r\n작성하는 Output은 `dtype`, finite real `data`, 선택적인 `axes`만 가집니다. `shape`를 작성하면 오류이며 scalar는 `[]`, flat array는 `[length]`, 직사각 2D array는 `[rows, columns]`, 3D array는 `[rows, columns, depth]`, Math.js Matrix는 `size()`에서 자동 추론합니다. axes를 생략하면 `index` 또는 `row`/`column`/`depth` ordinal ticks를 생성하고, 제공하면 모든 축과 ticks 길이가 추론 shape에 정확히 맞아야 합니다. 성공한 preflight의 dtype·shape·축 이름·단위는 저장 뒤 강제 계약이 됩니다. 축 좌표(ticks)의 값은 Measurement마다 달라도 저장할 수 있으며, 각 결과의 실제 좌표를 보존해 표시합니다. ticks는 유한한 숫자이고 개수가 해당 shape와 일치해야 합니다. Prediction의 예측 결과 계약 검사도 같은 규칙으로 Measurement별 좌표 차이를 허용하지만, Predicted·Target·Re-predicted·Actual의 비교는 shape가 같으면 같은 배열 인덱스끼리 수행합니다. 축 좌표·이름·단위·숫자 dtype 차이는 비교를 막지 않으며, 겹쳐 표시할 때는 Predicted 또는 Target의 축을 사용합니다. 보간이나 단위 변환은 하지 않습니다. Output에는 QuantityKind와 값 unit이 없습니다. rank 0은 scalar, rank 1은 line, rank 2는 heatmap, rank 3는 Point cloud heatmap으로 표시합니다.\r\n2차원 heatmap은 tensor의 columns:rows shape 비율을 유지해 각 cell을 정사각형으로 표시하며, Output Chart의 가용 영역과 splitter 조절에 맞춰 확대됩니다. 숫자 축 라벨은 최대 유효숫자 5개로 반올림하지만 hover 좌표와 Return 데이터는 원본 정밀도를 유지합니다.\r\n\r\n### 허용 Math.js API\r\n\r\n{{calculation.mathjs}}\r\n\r\n`mathjs` 이외 package, default/namespace/deep/dynamic import, `require`, expression parser와 symbolic API, mutable configuration, BigNumber/Fraction/Unit, random 함수는 허용하지 않습니다. stdlib는 v1에 포함되지 않습니다.\r\n`values[index]` 같은 동적 bracket index는 실행 시 `number`, 0 이상, safe integer인지 검사한 뒤 허용합니다. 문자열·BigInt·NaN·Infinity·음수·소수 index는 source 위치가 포함된 policy 오류가 됩니다. 고정된 `record['path.to.leaf']`는 계속 허용하지만 `record[path]` 같은 동적 문자열 property와 computed object property/method 선언은 차단합니다. `constructor`, `prototype`, `__proto__`, 동적 Math member, random 함수, native `Object`/`Array` alias와 global·network·storage·timer·Worker 접근도 허용하지 않습니다.\r\n\r\n### 오류와 한도\r\n\r\n- 전체 입력은 64 MiB 이하여야 합니다.\r\n- Output은 최대 5,000,000개의 수치 원소를 가질 수 있습니다.\r\n- 한 실행은 최대 30초이며 source, Measurement, Calculation 또는 Experiment가 바뀌면 이전 실행을 취소합니다.\r\n- 명시적인 `shape`, 불완전한 axes, ticks 길이 불일치, 유효하지 않은 UCUM axis unit은 Output 계약 오류입니다.\r\n- `console.log`는 호출당 4 KiB, 실행당 100건·64 KiB로 제한되며 초과분은 한 번의 truncation 경고로 대체됩니다.\r\n- `timeout`은 계산량을 줄이고, `input-too-large`는 필요한 RecordedData만 만드는 Experiment 계약으로 나누고, `output-too-large`는 downsample 또는 aggregate한 rank 0/1/2/3 결과를 반환해 해결합니다.\r\n\r\n## Viewer 변환 코드 복사\r\n\r\nBox Grid Viewer의 **변환 코드 복사**는 현재 채널·성분·축·집계 설정을 `boxGrid.project` 한 줄로 복사합니다. 별도 import 없이 Calculation 함수 안에서 `return`을 붙여 실행합니다. 입력 매개변수 이름은 현재 편집 중인 함수에 맞추고 Record 이름은 정적 참조로 보존합니다.\r\n\r\n```js\r\nexport default function calculate(record) {\r\n  return boxGrid.project(record['signal'], { axes: ['time'], component: 0 });\r\n}\r\n```\r\n\r\n`axes`는 유지할 축과 반환 순서입니다. 이름은 `x`, `y`, `z`, `time`, `frequency`이며 빈 배열이면 scalar입니다. `representation`은 `amplitude`(기본) 또는 `phase`, `component`는 0 기반 성분 index 또는 `magnitude`입니다. Phase에는 성분 하나를 지정합니다. 실수 scalar의 기본값은 성분 0이며 부호를 유지합니다.\r\n\r\n`reduce`는 축별 `{ method, index? }`입니다. `sum`, `mean`(기본), `min`, `max`, `median`, `std`, `index`를 지원합니다. 표본별 성분/크기를 계산한 뒤 x→y→z→time→frequency 순서로 남은 축을 집계합니다. sum은 표본 합, std는 모집단 표준편차이며 Phase에도 숫자 rad 값의 동일한 집계를 적용합니다. index는 0부터 시작합니다.\r\n\r\n```js\r\nexport default function calculate(record) {\r\n  return boxGrid.project(record['signal'], { axes: ['x', 'y', 'z'], component: 'magnitude', reduce: { time: { method: 'index', index: 0 }, frequency: { method: 'mean' } } });\r\n}\r\n```\r\n\r\nAnimation 복사는 현재 `frame.timeSeconds`(s) 또는 `frame: { axis: 'time', index: 0 }`를 고정합니다. 공통 시간 진동은 주파수를 Hz로 변환하여 `A_f,c*cos(φ_f,c+2πf t)`로 계산하며 0 Hz는 일정합니다. Frequency sum/mean은 성분별 순간값을 먼저 합성하고, 벡터 크기를 구한 뒤 나머지 축을 집계합니다. mean은 주파수 표본 수로 나눕니다. 다른 집계와 정적 표시는 기존 축소 순서를 유지합니다. 기존 `frame.phase`(rad)도 지원하지만 `timeSeconds`와 함께 지정할 수 없습니다. 화살표 보기는 X·Y·Z·벡터 크기 변환식 네 줄을 복사합니다. 원하는 식 하나를 return하거나 중간 변수에 할당하세요.\r\n\r\nHistogram 복사는 채널·성분 축을 제거한 `[x,y,z,time,frequency]` **5차원 중간값**입니다. 순회 축은 길이 1로 보존합니다. 5차원은 그대로 return할 수 없으며 추가 계산으로 0~3차원까지 줄여야 합니다. 모든 변환의 결과는 float64이며 `{ dtype, data, axes }` 형태를 유지합니다. 실행 가능한 예제는 CLI `reference show calculation.example.projection`에서도 확인할 수 있습니다.\r\n",he=`# Prediction으로 Vars와 CalculationData 상호 예측\r
\r
Workbench를 처음 열면 **Prediction**에서 시작합니다. 왼쪽 위 Experiment 선택기는 로그인 사용자의 **내 Experiment**를 먼저, 큐레이션된 **Demo**를 다음에 표시하며 비로그인 사용자는 대표 Demo가 자동으로 열립니다.\r
\r
이후 새로고침에서는 브라우저 탭에 저장된 마지막 탭과 Experiment·Measurement·Calculation 선택을 다시 검증한 뒤, 여전히 현재 Experiment에 속하고 접근 가능한 선택만 복원합니다. 공유 URL은 \`?experiment=ID\`만 지원합니다. 탭과 Measurement·Calculation 선택은 URL에 저장하지 않으며, 기존 \`section\`, \`measurement\`, \`calculation\`, \`structure\`, \`sample\`, \`setup\` 파라미터는 적용하지 않고 자동으로 제거합니다.\r
\r
상단 **Prediction** 메뉴는 현재 Experiment의 저장된 Recorded Measurement를 학습 데이터로 사용합니다. 왼쪽 **Vars**와 오른쪽 **Calculation Data** 사이의 중앙 3D Viewer 및 하단 Console은 다른 Workbench와 같은 상태로 유지됩니다. Demo의 Vars와 Target 조작은 로컬 Candidate에만 적용됩니다. Demo 원본과 저장 데이터는 guest와 일반 사용자에게 읽기 전용이며, admin에게만 관리 작업이 열립니다.\r
\r
공개 Demo에서는 로그인하지 않아도 Forward Prediction, Inverse Design, Calculation 데이터 탐색, Analysis 그래프·표·CSV와 Experiment source를 볼 수 있습니다. Calculation 탭에서는 Demo의 Measurement 점과 RecordedData를 선택하고, 기존 Calculation source를 수정하거나 새 로컬 Draft를 만들어 Output을 즉시 미리볼 수 있습니다. Guest와 일반 사용자의 편집은 현재 Workbench에만 남고 원본 Calculation과 저장 데이터는 바뀌지 않으며, 탭을 떠날 때 폐기 확인 후 새로고침하면 원본으로 돌아갑니다. Demo 원본의 **Save & Run**, Simulation, 누락 데이터 계산, Measurement·Calculation 저장과 삭제는 admin에게만 허용됩니다. 일반 Experiment에서 이 작업들은 로그인과 기존 소유권 또는 admin 역할이 필요합니다. **Edit a copy**는 Experiment source bundle만 새 로컬 Draft로 복제하며 원격 ID, Measurement, Calculation과 공개 Demo 데이터 연결은 복제하지 않습니다.\r
\r
### 마지막 편집이 예측 방향을 정합니다\r
\r
- 왼쪽 Vars를 편집하면 **Forward**가 됩니다. \`vars → RecordedData\`를 kNN으로 예측한 뒤, 선택한 각 Calculation의 저장된 source를 브라우저에서 직접 실행해 오른쪽 CalculationData를 갱신합니다.\r
- 오른쪽의 Forward 결과를 처음 편집하면 전체 결과가 Target draft가 되고 **Inverse**가 됩니다. 선택한 CalculationData target 전체에서 vars를 kNN으로 예측하고, 완전한 vars 묶음을 한 번에 Candidate와 Viewer에 적용합니다. 입력한 target은 유지되며 Forward surrogate도 다시 계산합니다. 저장 Measurement를 Target으로 불러오는 selector는 없으며, Inverse는 현재 Forward 결과를 편집해서 시작합니다.\r
- 연속 편집은 잠시 모아 처리하며 이전 요청의 늦은 결과는 버립니다. Inverse가 적용한 vars 때문에 Forward가 다시 시작되지는 않습니다. 리본의 Direction과 상태를 확인하고, 오래 걸리는 작업은 **Cancel**로 중단할 수 있습니다.\r
- Prediction의 Vars도 Calculation과 같은 인라인 단일-open 카드입니다. Candidate 값이나 Inverse 결과가 갱신되어도 열린 카드는 유지되며 별도 팝업을 열지 않습니다.\r
- 오른쪽 편집기는 기준 데이터와 비교 시리즈를 한 화면에 표시합니다. Forward는 파란 **Predicted**와 초록 **Save + Run Actual**을, Inverse는 주황 **Target**, 보라 **Re-predicted**, 초록 **Save + Run Actual**을 사용합니다. 비교 시리즈는 읽기 전용이므로 hover나 legend 확인이 Prediction 방향을 바꾸지 않습니다.\r
- scalar는 공통 수치축 marker, 1-D는 공통 축의 line overlay로 비교합니다. 2-D는 동일 axes와 color scale을 공유하는 heatmap을 한 행에 병렬 배치하며, 같은 cell을 hover하면 모든 heatmap에서 좌표와 값을 함께 강조합니다. 좁은 패널에서는 가로 스크롤로 각 heatmap의 판독 크기를 유지합니다.\r
- 각 CalculationData 카드의 **Display range**는 새 Forward primary 결과가 들어올 때 실제 min/max에 5% 여백을 더해 한 번 맞춘 뒤 고정됩니다. Target 편집, Inverse, Re-predicted 또는 Actual 도착만으로는 다시 확대·축소하지 않습니다. **Fit**은 현재 primary와 ready 상태인 호환 비교 시리즈 전체로 범위를 다시 맞춥니다. 범위 밖 cell은 끝 색으로 표시하고 \`clipped\` 수를 알리지만 데이터 값이나 dtype 허용 범위를 변경하지 않습니다.\r
- Target heatmap의 선택 사각형은 Target commit, Inverse 시작·완료, Re-predicted·Actual 갱신과 Fit 뒤에도 유지됩니다. 새 Forward primary로 교체되거나 dtype, shape, axes가 바뀔 때만 선택을 초기화합니다.\r
\r
### Settings와 cohort\r
\r
리본의 **Prediction Settings**에서 한 개 이상의 저장된 Calculation, 각 Calculation의 거리 weight, k의 Auto/Manual 방식과 Neighbor weighting을 선택한 뒤 **적용**합니다. 성공한 preflight 계약이 없는 기존 Calculation은 선택할 수 없고 다시 저장해야 합니다. 설정 초안은 적용 전까지 현재 모델을 바꾸지 않습니다. Calculation을 선택하는 즉시 저장된 Output layout으로 오른쪽 카드와 shape·axes가 만들어지며 값이 도착하기 전에는 비편집 **Updating…** 상태입니다. **새로고침**은 최신 Measurement와 CalculationData를 다시 읽고, **누락 데이터 계산**은 선택한 Calculation의 미저장 조합을 계산한 뒤 데이터를 다시 불러옵니다.\r
공개 Demo의 새로고침과 Model Details는 누구나 사용할 수 있지만 누락 데이터 계산은 데이터 변경이므로 admin 역할이 필요합니다.\r
\r
Forward는 선택한 Calculation dependency의 합집합에 해당하는 Box Grid RecordedData만 조회합니다. 공유 ExperimentRecord는 한 번만 다운로드·모델링하고 관련 없는 Record는 flatten이나 메모리 계산에 포함하지 않습니다. 각 ExperimentRecord는 7차원 tensor 전체를 하나의 출력으로 예측합니다. 같은 shape, dtype, 물리 단위, 채널·성분 순서, 정적 Box Grid profile과 time·frequency ticks를 가진 표본끼리 cohort를 구성하고 가장 큰 cohort를 사용합니다. 동률이면 가장 낮은 Measurement ID를 포함한 cohort를 선택합니다. Box의 위치·크기·회전과 물리 x·y·z ticks는 정규화한 Box 상대 위치로 대응하므로 달라도 사용할 수 있습니다. 한 Record의 비호환 표본은 다른 Record 모델을 줄이지 않습니다.\r
\r
Forward는 현재 Candidate를 다시 평가한 Box geometry와 셀 중심 x·y·z ticks를 예측 tensor에 붙인 뒤 Calculation을 실행합니다. 기준 Measurement의 Box 위치를 복사하지 않습니다. 필요한 Record 모델이 없는 Calculation만 오류가 되고 다른 Calculation 결과는 유지됩니다. Settings와 Model Details에서는 Calculation별 dependency와 Record별 포함·제외 Measurement를 확인할 수 있습니다. Modal frequency는 예외적으로 표본마다 달라질 수 있으며 같은 Task의 모든 modal field와 실제 고유주파수 ticks를 하나의 결정적인 최근접 Measurement에서 함께 가져옵니다. 고유벡터를 평균하지 않습니다. Inverse는 저장된 Calculation Output 계약을 기준으로 complete-case 교집합을 만듭니다.\r
\r
Runtime Console의 source를 **Prediction**으로 선택하면 Record별 shape 제외와 모델 실패를 확인할 수 있습니다. model fingerprint에는 ExperimentRecord contract hash, Calculation dependency·source hash·Output layout이 포함되므로 어느 계약이 바뀌어도 이전 모델, surrogate와 validation은 즉시 stale이 됩니다.\r
Measurement, RecordedData 또는 CalculationData가 바뀌면 Prediction은 변경된 fingerprint를 감지해 context와 Worker model cache를 자동으로 다시 만들고 현재 Forward 또는 Inverse 방향을 다시 계산합니다. 자동 갱신이 실패한 경우에만 stale 안내와 **새로고침**이 남습니다.\r
\r
Auto k는 포함된 행 수 \`n\`에 대해 \`round(sqrt(n))\`을 사용하되 1–15와 실제 cohort 크기 안으로 제한합니다. Manual k는 1–\`n\` 범위의 정수만 허용합니다. **Distance**는 가까운 이웃에 더 큰 weight를 주고, **Uniform**은 실제 선택된 이웃을 동일하게 평균합니다. Forward 거리는 varsSchema 범위로, Inverse 거리는 cohort의 표준편차로 정규화됩니다.\r
\r
회귀 모델은 브라우저 Prediction Worker의 Float64 배열에 만들어지며 PCA나 summary 값으로 대체하지 않습니다. 복소수 Box Grid의 진폭·위상은 내부에서 실수부·허수부로 바꿔 이웃을 가중 평균한 뒤 다시 진폭·위상으로 복원합니다. 진폭 0의 위상은 0입니다. 따라서 위상이 경계를 넘는 표본도 위상 각도를 직접 평균하지 않습니다. 모델 하나의 numeric cell은 **1천만 개**, persistent array는 **192 MiB**, 전체 working set은 **256 MiB**가 상한입니다. 하나라도 초과하면 모델을 만들지 않고 메모리 오류를 표시합니다. 이 경우 선택 Calculation 수를 줄이거나 tensor 크기를 줄인 뒤 새로고침하세요. 실제 사용량은 **Model Details**에서 확인할 수 있습니다.\r
\r
### Farthest Sample & Run\r
\r
각 Vars 카드의 **Sampling Min/Max**는 schema 범위 안에서 탐색 범위를 추가로 좁힙니다. Tensor Vars는 모든 cell에 같은 Min/Max를 사용하고 이 범위는 Experiment 또는 varsSchema가 바뀌면 초기화되며 저장되지 않습니다. 리본의 N은 시도 횟수이며 양의 JavaScript safe integer여야 합니다.\r
\r
**Sample & Run**은 선택 범위 안의 중복 없는 Recorded Measurement를 center로 사용합니다. 첫 center가 없으면 범위 정중앙에서 시작하고, 이후에는 정규화된 Vars별 평균제곱거리를 균형 있게 사용한 결정적 farthest-point/k-center 근사로 다음 후보를 고릅니다. N회 후보를 순차 준비하며, 준비에 성공한 후보를 이번 실행의 임시 center로 추가합니다. 각 후보의 Vars로 \`material.tsx\`를 다시 평가하고, 현재 화면의 Candidate는 바꾸지 않습니다. 준비 실패는 집계하고 다음 시도를 계속하며, 성공한 후보만 하나의 서버 CAE Batch로 제출합니다. 모두 실패하면 제출하지 않습니다. 서버는 각 후보의 Simulation과 RecordedData 저장을 실행하고, 브라우저는 성공한 Measurement의 CalculationData를 후처리합니다. 개별 Simulation 또는 Calculation 실패는 다른 후보의 처리를 막지 않습니다. 준비·업로드·서버 실행·후처리 진행 상태를 표시하며 기존 CAE Batch 화면에서도 작업을 확인할 수 있습니다. Cancel은 준비와 후처리를 중단하고 등록된 Batch의 취소를 요청합니다. Experiment 또는 source 변경은 현재 화면의 처리를 분리하며, 이미 제출된 서버 작업은 Batch 화면에서 관리합니다. 브라우저를 닫아도 제출된 Simulation은 계속되지만 Calculation 후처리는 브라우저가 필요합니다. 누락된 CalculationData는 기존 누락 계산 기능으로 보완하세요. Batch 종료·취소·중단 뒤 저장된 점이 있으면 모델을 한 번 자동 갱신합니다. 서버에서 나중에 실패한 후보도 이번 실행의 임시 center에는 포함되지만, 다음 실행의 center는 실제 Recorded Measurement로 다시 구성합니다.\r
\r
### Save & Run 검증\r
\r
최신 예측이 현재 Candidate와 일치하고 Experiment가 저장된 clean 상태일 때 리본의 **Save & Run**을 사용할 수 있습니다. 실행 시 현재 CalculationData와 Candidate revision을 비교 snapshot으로 고정하고, 현재 vars를 새 Measurement로 저장한 뒤 실제 Simulation, RecordedData 저장과 저장된 Calculation 자동 계산을 끝까지 수행합니다. 완료해도 Prediction 세부 정보 창을 자동으로 열지 않고 결과를 기존 Calculation Data 카드에 표시합니다. **Model Details**는 리본에서 사용자가 요청할 때만 엽니다. Forward에서는 Predicted와 실제 CalculationData를 겹쳐 비교합니다. Inverse에서는 Target과 그 Target으로 추론한 Vars의 Re-predicted를 먼저 비교하고, 실행이 끝나면 Save + Run Actual까지 더해 세 결과를 함께 비교합니다.\r
\r
비교에는 rank와 각 차원의 길이(shape)가 같아야 하며, 호환되는 각 Calculation에 대해 MAE, RMSE와 최대 절대 오차를 오른쪽 카드와 **Model Details**에 표시합니다. Inverse에서는 Target↔Re-predicted, Target↔Actual, Re-predicted↔Actual을 각각 독립적으로 비교합니다. 유효한 숫자 tensor는 dtype·축 이름·단위·좌표가 달라도 shape가 같으면 같은 배열 인덱스끼리 비교합니다. 겹쳐 표시할 때는 Predicted 또는 Target의 축을 사용하며, 원본 좌표를 보존하고 보간이나 단위 변환은 하지 않습니다. Re-predicted 또는 Save + Run Actual의 shape가 기준 시리즈와 다르면, 같은 카드 안에 원래 shape와 좌표를 사용하는 읽기 전용 결과로 별도 표시합니다. shape의 기준값과 실제값을 안내하며, 해당 쌍의 겹치기와 오차 계산만 중단합니다. source 불일치와 잘못된 tensor는 정상 결과로 표시하지 않습니다. Simulation·저장·계산 실패나 Cancel은 검증 실패로 표시되고, 실제 CalculationData가 없는 대상은 개별 오류가 됩니다. 성공하면 새 Measurement를 포함하도록 모델을 자동 갱신하고 현재 방향을 다시 예측하지만, Calculation Data 카드에는 Save & Run을 시작한 시점의 Predicted 또는 Target·Re-predicted와 완료된 Actual 비교 snapshot을 유지합니다. 이 snapshot은 Vars·Target·Prediction Settings·Experiment·source/layout을 변경하거나 수동으로 데이터를 다시 불러오거나 새 Save & Run을 시작할 때 해제됩니다.\r
\r
Calculation과 Prediction의 Sample & Run은 같은 Client build·S3 업로드·Batch 실행·후처리 경로를 사용합니다. Calculation에서는 Monte Carlo(random), Prediction에서는 위의 LHS 후보 풀과 최대 거리 선택 방식을 사용하며 별도 알고리즘 선택 창은 없습니다. 큰 BuiltMeasurement와 결과 본문은 S3로 직접 전달됩니다.\r
`,ge=`# Admin: 공개 Demo 큐레이션\r
\r
**Admin** 메뉴는 admin 역할에만 표시되며 **Users**, **All Experiments**, **Demo Curation** 화면을 제공합니다. 모델 정의는 **Model Catalog**에서 조회하며, 재료별 계수를 저장하는 관리 화면은 제공하지 않습니다.\r
\r
Demo Curation에는 admin 사용자가 소유한 정확한 Experiment Version만 등록할 수 있습니다. Prediction 데이터가 없어도 Demo와 대표 Demo로 지정할 수 있습니다. **Ready**와 **Not Ready**는 완전한 Recorded Measurement 및 그 Measurement를 사용하는 ready Calculation·CalculationData가 있는지 알려 주는 Prediction 준비 상태이며, Demo 등록 조건은 아닙니다. 순서를 바꾸고 대표 Demo를 별표로 지정한 뒤 저장하세요. 대표 Demo를 해제하거나 삭제하면 다음 순서의 Demo가 대표가 됩니다.\r
\r
Admin은 Demo의 Experiment source, Measurement, RecordedData, Calculation과 CalculationData를 Workbench에서 관리할 수 있습니다. Measurement가 있는 기존 Experiment Version의 source는 잠겨 있으므로 덮어쓰지 말고 **New Version**으로 저장해야 합니다. 새 Version은 자동으로 Demo가 되지 않으며 Demo Curation에서 명시적으로 교체해야 합니다. Measurement나 Calculation을 삭제해 준비 조건이 깨져도 Demo는 자동 공개 해제되지 않고 **Not Ready**로 표시됩니다.\r
\r
**주의:** Demo 등록은 스냅샷을 만들지 않습니다. 해당 Version의 source bundle과 현재 및 향후 생성되는 전체 ExperimentRecord, Measurement, RecordedData, Calculation, CalculationData가 즉시 공개되고 복사 가능한 정보로 간주됩니다. 민감하거나 앞으로 공개되어서는 안 되는 데이터를 가진 Experiment는 등록하지 마세요. 공개 해제를 저장하면 익명 접근은 즉시 철회됩니다.\r
`,xe=`# Analysis: Explore, Mining과 Data\r
\r
**Analysis**는 현재 Experiment에서 CalculationData가 하나 이상 저장된 Measurement만 분석합니다. Measurement의 숫자 input vars와 Model Parameter는 feature로 유지하고, 저장된 CalculationData만 target으로 사용합니다. RecordedData는 Analysis에서 조회하거나 사용하지 않습니다. 중앙 3D Viewer와 Console은 그대로 유지되며, 오른쪽 Analysis 결과와 왼쪽 탭별 설정은 각각 스크롤할 수 있습니다.\r
\r
### Explore\r
\r
Analysis에 들어오면 사용할 수 있는 숫자 input vars와 숫자 CalculationData target의 모든 조합을 계산합니다. scalar CalculationData는 원값을 사용하고 rank 1–2 결과는 모든 원소의 \`mean\`과 표본 \`std\` 열로 요약합니다. 원소가 하나인 tensor의 \`std\`는 0이며 빈 tensor는 결측값입니다. Model Parameter는 기본 상관 순위에 포함하지 않습니다. \`|Pearson r|\`이 큰 순서로 정렬하고, 같으면 \`|Spearman ρ|\`와 안정적인 key 순서를 사용합니다. 1위 조합이 자동으로 선택되며 검색 가능한 두 선택기나 순위 행으로 다른 조합을 고를 수 있습니다.\r
\r
Pearson과 Spearman은 완전한 input/target 값 쌍이 3개 이상이고 두 축이 상수가 아닐 때만 계산합니다. \`n\`은 실제 계산에 사용한 완전한 쌍의 수입니다. 산점도의 점에 포인터를 올리면 Measurement ID와 좌표를 확인할 수 있습니다.\r
\r
### Mining\r
\r
**Mining**은 2–50개 feature를 표준화해 PCA projection, 자동 K-Means, principal-component loadings와 reconstruction anomaly를 계산합니다. Explore 선택과는 독립적이며 검색, source 그룹, 전체 선택과 초기화를 사용할 수 있습니다.\r
\r
### Data와 CSV\r
\r
**Data**에는 histogram, scalar profile과 100행 데이터 표가 있습니다. 표와 **선택 데이터 CSV**는 Data 설정에서 선택한 feature 및 CalculationData 요약 열만 사용하며 CalculationData 원본 tensor 배열은 포함하지 않습니다.\r
`,ye=`# 3D Viewer에서 Geometry와 Surface ID 확인\r
\r
3D Viewer의 **Off / Geometry / Surface** 선택 모드로 렌더링된 대상의 실제 Scene 전역 경로를 확인할 수 있습니다. 최초 모드는 **Off**이며 이 상태에서는 기존 카메라 회전·이동만 동작합니다.\r
\r
- **Geometry** 모드에서 클릭하면 가장 가까운 part 전체가 강조되고 \`starter.body\` 같은 geometry 전역 경로가 표시됩니다.\r
- **Surface** 모드에서 클릭하면 해당 면만 강조되고 \`starter.body/surface/1\` 같은 surface 전역 경로가 표시됩니다.\r
- 선택 카드의 복사 버튼으로 Solver group에 사용할 경로를 복사할 수 있습니다. Focus 버튼은 해당 geometry 또는 surface에 현재 카메라 방향을 유지한 채 화면을 맞춥니다. 선택된 경로는 Source에서 자동으로 확인되며 정확한 문자열 사용처가 있을 때만 Source 찾기 버튼이 활성화됩니다. 한 곳이면 바로 이동하고 여러 곳이면 결과 목록을 표시합니다. 빈 공간을 클릭하거나 Clear 버튼을 누르면 Viewer 선택이 해제됩니다.\r
- 마우스를 움직인 동작은 클릭이 아니라 카메라 조작으로 처리하므로 드래그 도중 대상이 바뀌지 않습니다.\r
\r
Source 편집기에서 \`geometryGroup\`·\`surfaceGroup\`의 전역 경로 문자열에 커서를 두면 정확한 대상이 Viewer에서 강조됩니다. 정적인 JSX \`id="body"\`에 커서를 두면 해당 local segment가 만든 현재 Scene의 모든 실행 인스턴스를 강조하고 각각의 전역 경로를 보여 줍니다.\r
\r
계산식이나 expression이 포함된 template ID는 Source에 하나의 구체적인 실행 경로가 없으므로 코드에서 자동 역매칭하지 않습니다. 이 경우 Viewer에서 인스턴스를 직접 선택해 확정된 전역 경로를 확인하세요. Viewer 선택만으로는 코드 탭이나 커서를 이동시키지 않으며 Source 찾기 버튼을 누른 경우에만 검색 결과로 이동합니다. 선택은 Draft나 URL에 저장되지 않습니다.\r
\r
## Output 시각화\r
\r
여러 Output의 최초 자동 선택에서는 공간 격자 수 \`nx × ny × nz\`가 가장 많은 Box Grid를 우선 표시합니다. 시간·주파수·성분 수와 물리적 부피는 비교하지 않습니다. 로딩 완료 후 오류 없이 데이터와 유효한 격자 크기가 있는 결과를 비교하며, 동률이면 목록에서 먼저 나오는 항목을 선택합니다. Geometry 겹치기 가능 여부는 선택 순위에 영향을 주지 않습니다. 유효한 Box Grid가 없으면 기존 자동 선택 규칙을 사용합니다. 사용자가 선택하거나 복원된 결과와 이미 자동 선택된 결과는 이후 갱신에도 유지합니다.\r
\r
Box Grid Output에서 Histogram, Line Chart, Heatmap, 3D Point cloud를 선택합니다. 처음 열면 **3D Point cloud · x/y/z 축**에서 벡터 크기를 점 색상으로 표시합니다. 스칼라는 해당 성분을 사용합니다. 기본 채널은 Amplitude입니다. 진동 가능한 복소 결과는 **공통 시간 t=0**을 표시하며 자동 재생하지 않습니다. 실수 또는 0 Hz만 있는 결과는 정적으로 표시합니다. 강조된 **재생** 버튼을 누르면 시간 진행을 시작합니다. 복원된 비교 화면 설정과 사용자가 변경한 설정을 유지합니다. Phase는 방향 성분 하나만 선택합니다. Line은 t/f 중 긴 축이 가로축, 짧은 축이 여러 line을 구분하는 축이며 동률이면 t가 가로축입니다. 표시 방식을 Heatmap 또는 3D로 전환할 때는 표본 수가 가장 큰 두/세 축을 사용하고 동률은 x→y→z→t→f 순서입니다.\r
\r
초기 Frequency 집계는 **sum**, time과 나머지 표시하지 않는 축은 **mean**이며 sum·min·max·median·std·개별 index로 변경할 수 있습니다. **표본 조회**에서 축별 index와 실제 좌표·값을 확인합니다. 화면 표본 수 제한은 범례에 표시되며 집계·코드 복사는 전체 데이터로 수행합니다.\r
\r
공간 축만 사용하는 Heatmap/3D는 기본으로 **Geometry 겹치기**를 사용하며 기본 Geometry 투명도는 **50%**입니다. 차트는 불투명하게 유지되고 Geometry만 투명해집니다. Heatmap은 남은 공간 축의 index 평면 또는 집계 시 Box 중앙 평면에 표시됩니다. Geometry와 저장 결과의 source/Vars가 일치해야 합니다. 처음 열 때는 점 색상으로 표시하고, XYZ 벡터에서 3D 표시 방식으로 전환하면 화살표를 선택하며 t/f가 표시 축에 포함되면 점 색상으로 표시합니다. 공간 좌표에는 Box 변환과 길이 단위를 적용합니다.\r
\r
**재생**에서 **진동 · 공통 시간** 또는 표시 축이 아닌 t/f의 index 순회를 선택합니다. Histogram에서는 t/f 순회 모두 가능합니다. 진동은 각 주파수를 \`A_f,c*cos(φ_f,c+2πf t)\`로 진행하며 Frequency sum/mean에서는 성분별 합성 후 벡터 크기를 구합니다. 실제 시간과 재생 구간은 s로 표시합니다. 기본 구간은 선택된 최저 양의 주파수 한 주기이고, 최고 주파수 한 주기를 20프레임으로 나누어 약 2초에 재생합니다. 계산이 느리면 재생도 느려집니다. 구간 길이·재생·일시정지·프레임·속도·반복을 조절하고, 재생 중 값 범위와 카메라는 고정됩니다. 반복은 지정 구간 끝에서 시간을 0으로 되돌리므로 양 끝의 값이 일치하지 않을 수 있습니다. 비교 Viewer는 양쪽 주파수를 고려한 구간과 공통 시간을 사용합니다.\r
\r
3D Viewer는 바닥 격자와 원점 Axis 선 없이 표시됩니다. 왼쪽 아래 Scale bar는 카메라 중심 깊이의 길이이며 zoom과 창 크기에 따라 갱신됩니다. t/f가 포함된 3D 차트는 각 축을 정규화하므로 공간 Scale bar를 표시하지 않습니다. Mesh-field는 도구모음과 범례를 제외한 가용 영역을 채웁니다.\r
\r
3D Point cloud는 변환·집계 후 값이 정확히 0인 표본을 숨깁니다. 화살표도 같은 규칙을 적용합니다. 점의 면적은 값의 절대값에 비례하며 최대 가로·세로 크기는 10 CSS px입니다. 크기는 표본 제한 전 전체 데이터로 정규화하고, Animation에서는 재생 전체의 기준을 고정합니다. 색상 범위를 수동으로 바꿔도 점 크기는 바뀌지 않습니다. 방향 성분만 상쇄되고 표시값이 양수인 화살표 표본은 점으로 표시합니다. 숨긴 0값은 집계·표본 조회·복사 데이터에 남으며, Heatmap은 0값도 표시합니다. Calculation의 3차원 결과에도 같은 점 표시 규칙을 적용합니다.\r
`,fe="# Experiment Program의 파일과 책임\r\n\r\nExperiment Program은 공통 정의와 solver별 task, 실행 정책을 분리합니다.\r\n\r\n| 파일 | 책임 |\r\n| --- | --- |\r\n| `experiment.tsx` | 공통 lengthUnit, geometry, varsSchema, Material 역할 주입, group과 최종 recordedData 계약 |\r\n| `geometry.tsx` | Experiment와 Task가 공유하는 named Geometry component |\r\n| `material.tsx` | named Material 객체 또는 vars를 받는 Material factory |\r\n| `tasks/<name>.tsx` | solver identity, 선택적 Task-local scene과 `config({ vars })` |\r\n| `simulate.py` | named task 실행 순서, 분기, artifact 전달·해제·기록 |\r\n| 그 밖의 `.ts`, `.tsx` 파일 | bundle 내부에서 상대 import하는 보조 모듈 |\r\n\r\n공통 형상과 Task 보조 형상은 `geometry.tsx`, Material 정의는 `material.tsx`에서 named export하고 `experiment.tsx`와 각 Task에서 상대 import합니다. 필요한 보조 코드는 bundle에 파일을 추가해 로컬 상대 import할 수 있습니다. Source bundle 밖 package, URL, 동적 `import()`와 `require()`는 지원하지 않습니다.\r\n\r\n`experiment.tsx`의 `lengthUnit`, `varsSchema`, `geometry({ vars })`, `geometryGroup`, `surfaceGroup`, `recordedData`가 여러 Task가 공유하는 물리 세계와 최종 결과 계약입니다. 숫자만 보고 SI라고 가정하지 말고 scene 길이 단위와 각 DataSchema의 UCUM 단위를 명시하세요.\r\n",be="# experiment.tsx: 변수와 RecordedData 계약\r\n\r\n`experiment({...})`의 `recordedData`는 `결과이름: { task, output }`으로 선언합니다. `output`은 해당 Task가 요청한 Box Grid output의 `key`입니다. target은 Experiment 또는 해당 Task의 Box 하나이며 `gridShape`를 필수로 지정합니다. 공통 빌드가 Catalog 계약에서 7차원 데이터 schema와 시각화 의미를 가져와 고정합니다. 메쉬·ray path는 별도 자동 시각화로 포함되며 `recordedData`에 선언하지 않습니다. 수동 tensor/group schema는 허용하지 않습니다.\r\n\r\n성공 실행에서는 모든 declared key가 정확히 한 번 기록되어야 합니다. `sim.record`에는 선언한 Task/output의 live artifact를 전달합니다. undeclared, duplicate, missing record와 출처가 다른 artifact는 실행 오류입니다. 자세한 저장·조회·Viewer 규칙은 [RecordedData 계약](program-domain-recording.md)을 참고하세요.\r\n\r\n`varsSchema`의 각 항목은 `min`, `max`와 선택적인 `shape`를 사용합니다. scalar는 `shape`를 생략할 수 있으며 기본값은 `[]`입니다. 명시적인 `shape: []`도 유효합니다. tensor는 `[3]`, `[4, 4, 1]`처럼 양의 safe integer 차원을 반드시 명시합니다. `min`과 `max`는 tensor가 아니라 모든 원소에 공통 적용되는 finite scalar이고 `min <= max`여야 합니다. shape 전체 원소 수는 65,536개 이하여야 하며 tensor shape 추론과 scalar/tensor broadcast는 지원하지 않습니다.\r\n\r\n```tsx\r\nvarsSchema: {\r\n  radius: { min: 2, max: 5 },\r\n  position: { shape: [3], min: -10, max: 10 },\r\n}\r\n```\r\n\r\nCandidate는 선언한 shape와 정확히 같은 dense rectangular numeric tensor여야 합니다. 축별 범위가 다르면 `positionX`, `positionY`, `positionZ`처럼 의미별 scalar 변수로 분리한 뒤 Geometry callback에서 다시 조합하세요. Geometry callback은 `({ vars })`로 값을 받고 외부의 변경 가능한 상태에 의존하지 않아야 합니다. 같은 parent 아래의 component `id`는 고유해야 하며, 이 ID를 `geometryGroup`에 넣어 `experiment.geometry.<group>`으로 참조합니다. CAD API v1의 surface member는 `<geometry-id>/surface/<non-negative-index>` 형식이며 Geometry Catalog에 표시된 primitive별 고정 slot을 사용합니다.\r\n\r\n[Electro-Thermal Notched Bar의 canonical experiment.tsx 열기](/doc?help=examples&item=caemble:experiment/caemble/verified/electro-thermal-notched-bar@5.0.0)\r\n",ve="# Material 역할과 Model Parameter\r\n\r\nMaterial은 이번 Experiment에서 사용할 모델 인스턴스와 명시적인 계수의 묶음입니다. `new Material(name, { color?, models })`을 `material.tsx`에서 만들고 named 객체 또는 `vars`를 받는 factory로 export합니다. 이름은 Experiment와 모든 Task 안에서 구별하기 위한 것이며 외부 재료 데이터 조회에 사용하지 않습니다.\r\n\r\n`models`의 key는 Material 내부의 인스턴스 이름입니다. 각 인스턴스에는 정확한 버전의 `model` ID와 `parameters`를 입력합니다. Model Catalog가 모델 식, 파라미터 구조·단위·생략 의미를 소유하고, 실제 계수는 소스에 직접 쓰거나 `vars`로 구성합니다. 별도의 계수 저장소, source/version 선택자와 `errorRate` sampling은 없습니다.\r\n\r\n[Model Catalog](/doc?help=materials)에서 사용할 모델을 확인하고 [Physics Catalog](/doc?help=solvers)에서 해당 Solver의 지원 조합을 확인하세요. 모델이 등록되어 있어도 모든 Solver가 지원하는 것은 아닙니다. 실행 가능한 완성 예제는 Catalog의 Experiment bundle을 사용합니다.\r\n\r\n파라미터 구조는 값, 객체, 리스트로 구성됩니다. 선택 객체를 넣었다면 그 안의 필수 필드를 모두 채워야 하고 리스트의 각 항도 완전한 입력 세트여야 합니다. 수치 quantity에는 `value`, UCUM `unit`과 필요한 `dtype`·`basis`를 사용합니다. QuantityKind와 shape는 모델의 규격을 따르며 값에서 추정하거나 scalar를 tensor로 자동 확장하지 않습니다. 등방성 3×3 입력을 명시하려면 `Mat(value)`를 사용할 수 있습니다.\r\n\r\n`materials` key는 `tire`, `wheel`, `shell` 같은 Geometry 역할 이름입니다. primitive는 `body` 역할을 소비합니다. child에서 map을 생략하면 상속하고, 명시하면 교체하며, `{}`는 상속을 지웁니다. 중간 Geometry는 `materials={{ body: materials?.wheel }}`처럼 역할을 remap할 수 있습니다. 같은 이름의 Material을 여러 부품에 사용할 수 있지만 Experiment와 Task 안에서 그 정의가 서로 달라서는 안 됩니다.\r\n\r\nSolver의 모델 그룹은 각 대상 Material에 따로 적용됩니다. 필수 그룹마다 허용된 모델 인스턴스가 하나 필요하며, 여러 개가 호환되면 [Task의 명시적 모델 선택](/doc?help=manual&item=program-task)을 사용합니다. 다른 물리 영역의 유효한 모델은 함께 둘 수 있지만 미등록 모델이나 불완전한 파라미터는 실행을 차단합니다.\r\n\r\nVars를 바꾸어 새 Candidate를 만들면 `material.tsx`도 다시 평가합니다. Measurement에는 실제 사용한 모델 정의·계수·선택 결과와 source/vars 식별자를 저장합니다. 저장된 실행 입력은 그 snapshot으로 재현하며 현재 소스나 외부 계수로 덮어쓰지 않습니다.\r\n\r\n[Two-material Wheel Assembly의 canonical Experiment bundle 열기](/doc?help=examples&item=caemble:experiment/caemble/assemblies/two-material-wheel-assembly@5.0.0)\r\n\r\n## MaterialInteraction: 재료 쌍의 모델\r\n\r\n두 재료 사이의 성질은 `material.tsx`에서 `new MaterialInteraction(name, { between: [first, second], models })`로 선언하고 named export합니다. `between`은 Material 객체 두 개를 받습니다. 같은 재료끼리의 접촉도 선언할 수 있습니다.\r\n\r\n재료 쌍마다 객체 하나만 허용합니다. A–B와 B–A는 같은 쌍이므로 다른 이름으로도 중복 선언할 수 없습니다. 서로 다른 물리 모델은 그 객체의 `models` 안에 함께 선언합니다. 인스턴스 형식은 Material과 같은 `{ model, parameters }`이며 같은 모델 ID와 버전도 객체 안에서 한 번만 사용할 수 있습니다. Model Catalog의 대상이 재료 쌍인 모델만 넣을 수 있습니다. 대칭 모델은 양쪽 방향으로 사용하고, 순서가 있는 모델은 선언한 `between` 순서를 보존합니다.\r\n\r\nExperiment에 별도의 Interaction 목록을 지정하지 않습니다. Candidate를 평가할 때 exported Interaction을 자동으로 찾고, Experiment와 Task Geometry에서 실제 사용한 두 Material에 해당하는 관계를 포함합니다. 사용하지 않은 선언도 중복·파라미터 검증을 받습니다. 같은 객체를 여러 이름으로 export한 경우는 한 선언으로 처리합니다.\r\n\r\nVars에 따라 계수를 바꾸려면 두 번째 인자로 `({ vars }) => ({ between, models })` 콜백을 사용합니다. 콜백은 Candidate마다 한 번 평가합니다. Vars의 타입은 `MaterialInteraction<{ friction: number }>`처럼 선언하면 콜백 안에서도 그대로 검사합니다. Material factory를 사용하는 경우 콜백에서도 같은 Vars로 같은 이름과 정의의 Material을 만들어야 합니다.\r\n\r\nTask의 Solver가 같은 모델 그룹에서 여러 모델을 지원하고 Interaction에 그 후보들이 함께 있으면 `config.interactionModels[role][interactionName][group]`에 인스턴스 이름을 지정합니다. 후보가 하나이면 자동 선택합니다. 적용되지 않는 선택, 중복 모델 또는 필수 모델 누락은 오류입니다. 선택 그룹의 누락 동작은 Solver Catalog가 정의합니다.\r\n\r\nTask 소스 아래의 Material Interactions에서 적용된 재료 쌍과 모델을 확인하고 `material.tsx`로 이동할 수 있습니다. Measurement는 관계의 계수와 Task별 선택도 함께 저장하며 실행 시 다시 검증합니다.\r\n\r\n[정지 바닥 위 미끄럼 접촉 예제](/doc?help=examples&item=caemble:experiment/caemble/rigid/sliding-contact@1.0.0)\r\n",Ce=`# tasks/*.tsx: solver task 선언\r
\r
\`defineTask({...})\`는 \`kernel: { name, version }\`, Task 전용 \`lengthUnit\`과 \`geometry\`, 그리고 \`config({ vars })\`를 선언합니다. Task Geometry는 Experiment Geometry와 별도 scene으로 평가·Build·렌더링되며 서로 겹친다는 이유로 CSG 형상을 바꾸지 않습니다. 광원·충돌체·경계조건 등의 물리적 역할과 상호작용은 Solver 계약이 정합니다.\r
\r
Catalog에는 Solver 이름마다 현재 버전 하나와 그 버전에 맞는 예제를 제공합니다. 제거된 Solver 버전을 참조하는 Experiment는 오류가 나며 자동으로 새 버전을 선택하지 않습니다. 기존 source를 고치려면 현재 예제와 계약을 기준으로 새 Experiment Version을 만드세요.\r
\r
\`parameters\`, \`initializations\`, \`boundaryConditions\`, \`outputs\`, \`exports\`의 이름과 occurrence는 [Physics Catalog](/doc?help=solvers)의 현재 계약이 단일 원본입니다. 수치 output의 target은 \`experiment.geometry.*\` 또는 \`task.geometry.*\`에서 Box 하나로 resolve되어야 하며 \`parameters.gridShape\`를 필수로 받습니다. 회전된 Box도 사용할 수 있습니다. 초기화·경계조건·native export는 각 method가 요구하는 geometry 또는 surface target을 사용합니다. 연성용 native 값은 \`config.exports\`로 요청하고 mesh·ray 표시는 자동 시각화로 제공받습니다.\r
\r
[Catalog 예제에서 Electro-Thermal Notched Bar의 현재 Task source 확인하기](/doc?help=examples)\r
\r
Material 역할마다 \`modelGroups\`에 선언된 그룹을 모두 확인합니다. 각 필수 그룹 안에서는 \`oneOf\`에 포함된 모델 인스턴스 하나를 선택합니다. 호환 인스턴스가 여러 개이면 \`config({ vars })\`의 \`materialModels[role][materialName][groupKey]\`에 선택한 인스턴스 이름을 지정하세요. 그룹·Material·인스턴스 이름이 틀리거나 선택한 모델이 호환되지 않으면 오류가 납니다.\r
\r
RC/TRC 같은 수치 방법은 Task 설정입니다. Material의 물리 모델과 별개로 선택하며, 선택한 모델을 지원하지 않는 방법으로 조용히 대체하지 않습니다.\r
\r
## 구조해석의 자동 메쉬\r
\r
구조 task에는 CSG 부품과 재료, 물리 조건, 해석 종류·공간 해상도, 요청 결과를 선언합니다. 절점·요소 배열이나 수기 메쉬 생성 규칙, 단면 행렬을 작성하지 않습니다. Solver가 체적 메쉬와 연결 구속을 생성합니다. 이전 수기 메쉬 계약을 새 계약으로 자동 변환하지 않으므로 현재 Catalog 예제로 새 Version을 작성하세요.\r
\r
지지·힘·압력·접촉과 관측은 \`surfaceGroup\` 또는 \`geometryGroup\`을 참조합니다. 형상의 변수나 해상도를 바꾸어도 같은 그룹의 의미를 유지할 수 있습니다. 연결·스프링의 내부 기준점은 선택한 부착 면에서 생성되고, 적층은 층별 실제 CSG 체적·재료 방향으로 표현합니다. 접합과 접촉은 다른 조건입니다. 부품이 닿는다는 이유만으로 자동 접합하지 않습니다.\r
\r
화면 미리보기의 분할 수와 실제 계산 메쉬는 구별합니다. 브라우저·CLI의 공통 전처리가 원래 곡면과 Fiber 함수를 조밀하게 평가하고, 구조 Solver가 그 경계 내부를 체적 요소로 채웁니다. 미리보기의 성긴 점을 task에서 더 많은 배열로 복사할 필요가 없습니다.\r
\r
정적·고유진동·주파수응답·선형 좌굴·시간해석의 지원 재료 및 비선형 조합은 현재 Solver 설명을 확인하세요. 큰 회전은 작은 변형률 탄성의 corotational 체적 경로이며, 유한변형률 소성이나 자동 보·쉘 축소를 뜻하지 않습니다. 거의 비압축성 재료, 얇은 굽힘과 응력 집중에서는 공간·시간 해상도 수렴을 확인해야 합니다.\r
\r
Solver의 [자동 시각화](program-domain-recording.md)로 실제 계산 메쉬·단면·재료와 지지·하중·변위·응력을 Viewer에서 검토할 수 있습니다. Box 내부에 절점이 없어도 수치 output은 해석장 보간으로 구합니다. 생성 번호는 해당 시각화 안에서만 유효합니다. 형상 또는 해상도를 바꾸면 이전 메쉬의 checkpoint나 연성 하중을 재사용하지 않습니다.

## 강체의 자유 병진·회전

강체 task에는 Boolean CSG 형상과 균일 밀도 재료를 연결합니다. 질량·질량중심·
관성텐서는 자동 계산되므로 mesh나 관성을 직접 입력하지 않습니다. 한 root 안에
떨어진 물질이 여러 개 있으면 각각 독립 강체가 됩니다. 빈 공동의 안쪽 표면은
새 강체가 아닙니다. 열린 표면과 유효하지 않은 solid는 오류로 표시됩니다.

Root에 설정한 초기속도·각속도·하중은 분리된 각 강체에 동일하게 적용됩니다.
예를 들어 힘 10 N은 각 강체에 10 N입니다. 서로 다른 조건이 필요하면 별도
root로 선언하세요. 초기속도는 질량중심의 world 속도이며 각속도·힘·토크도
world 기준입니다. 부착점만 형상 원점 기준 body-local 좌표를 사용합니다.

내부 시간간격, 한 번의 실행 시간창, 전체 실행 시간과 출력 간격을 구분합니다.
출력 간격은 내부 시간간격의 정수배일 필요가 없습니다. 여러 번 실행할 때
이전 state를 연결하면 운동이 이어지고 질량특성을 다시 계산하지 않습니다.
시간창 끝의 부분 step이 달라지면 시간간격 수렴으로 결과를 비교하세요.

질량특성의 곡면 정밀도와 관측 Grid·subcell 정밀도는 별개입니다. 밀도 출력은
셀 안의 질량을 셀 전체 부피로 나눈 값이며, 속도 출력은 셀 안 물질의 질량가중
평균입니다. 밀도가 0인 셀의 속도 0은 빈 공간의 저장값입니다. 물체가 겹치면
질량·운동량을 더하고, 접촉·충돌 반력은 계산하지 않습니다. Subcell 정밀도를
높이며 Box가 포함한 질량의 수렴을 확인하세요.

밀도·속도·운동량 중 필요한 수치 출력만 기록할 수 있습니다. Native snapshot은
각 body의 실제 호출 종료 상태와 질량특성을 제공하고, 자동 시각화는 기준
CSG mesh를 배율 1로 이동·회전합니다. [현재 강체 예제와 정확한 Task 설정은
Catalog에서 확인하세요](/doc?help=examples).
`,we=`# Non-sequential Ray Tracing\r
\r
Catalog의 \`ray-tracing\`은 미리 정한 표면 순서를 따르지 않고, 광선이 기하와 만나는 순서대로 반사·굴절·산란·흡수를 추적하는 non-sequential solver입니다. 다중 반사, stray light, 바플과 혼탁 매질을 포함한 광학계에 사용하세요.\r
\r
### 광원과 산란\r
\r
- 광원은 point, area, directional, Lambertian 형식을 지원합니다. 모든 광원의 emitter locator geometry 또는 surface는 \`ray.domain\` group에서 제외하고, 실제 방출 위치도 모든 collision solid 바깥에 두세요. 각 광원 initialization call은 하나의 이산 wavelength line을 나타내므로, 여러 call을 나란히 추가해 다중 파장 광원을 구성합니다.\r
- 편광은 광원의 4성분 Stokes vector로 주입합니다. 표면의 ABg 및 Lambertian scatter와 체적의 Henyey–Greenstein(HG) scatter를 사용하며, 산란된 광선은 depolarized 상태로 계속 추적됩니다.\r
- \`ray.domain\` collision solid는 올바르게 중첩할 수 있지만 서로 부분적으로 겹치면 안 됩니다. 매질 경계의 진입·이탈 순서가 모호한 overlap은 실행을 거부합니다.\r
\r
### Shell layer의 적응형 박막 처리\r
\r
\`<coating>\` element를 따로 만들지 마세요. Solver가 canonical \`<shell>\`의 **각 layer에 대한 물리적 두께**를 판정합니다. 두께가 엄격히 \`50 µm\` 미만인 layer는 transfer-matrix method(TMM) 박막으로 적응형 처리하고, 인접한 박막 layer는 하나의 multilayer stack으로 계산합니다. 정확히 \`50 µm\`인 layer와 그보다 두꺼운 layer는 일반 광선–표면 collision으로 추적됩니다.\r
\r
박막과 체적에 사용할 광학 모델과 계수는 \`material.tsx\`에 명시합니다. Solver의 지원 모델과 입력 규격은 [Model Catalog](/doc?help=materials)에서 확인하세요. 주파수 표본 모델은 Hz로 엄격히 증가하는 표본열을 받아 광원 파장의 \`frequency = c / wavelength\`에서 각 성분을 선형 보간합니다. 표본 범위 밖에서는 가장 가까운 끝점 값을 사용합니다. 복소 굴절률 모델의 부호 및 감쇠 해석은 모델의 관례를 따릅니다.\r
\r
### Detector와 ray path\r
\r
수치 output은 Box 내부의 fluence rate와 radiant flux density입니다. \`ray.fluence-rate\`는 방향을 합한 스칼라, \`ray.radiant-flux-density\`는 방향 성분을 가진 벡터를 기록하며 둘 다 Box target과 \`gridShape\`를 받습니다. 흡수 검출면의 detected power는 실행 observation으로 확인합니다. 경로는 자동 시각화로 포함되므로 outputs나 \`recordedData\`에 선언하지 않습니다. Task가 반복 실행되면 마지막 성공 invocation의 경로 snapshot을 표시합니다. Catalog의 polyline 계약이 경로 구성 데이터와 표시 방식을 결정합니다. 다른 Solver의 mesh field와도 같은 Viewer에서 선택하거나 Overlay할 수 있으며 Calculation·Analysis·Prediction 입력에는 포함하지 않습니다.\r
\r
[Catalog 예제에서 Folded Ray-Tracing Bench의 source와 현재 Solver 계약 확인하기](/doc?help=examples)\r
\r
### 회절격자 Spectrometer\r
\r
광학 배치는 [Newport의 Czerny–Turner 설명](https://www.newport.com/n/grating-monochromator-design)을 참고합니다. 첫 오목거울이 슬릿의 빛을 모아 평면 격자에 보내고, 두 번째 오목거울이 분산된 빛을 검출기에 모읍니다.\r
\r
Examples에서 **Czerny–Turner Spectrometer**를 열면 슬릿, 두 오목거울, 평면 반사격자와 검출기의 배치를 볼 수 있습니다. Vars의 각 범위 중앙값이 기준 설계입니다. 슬릿 폭, 격자 밀도·회전각, 초점거리와 검출기 이동을 바꾼 뒤 **Save & Run**으로 현재 조건을 실행하세요. 격자를 회전해도 검출기는 자동으로 따라가지 않습니다.\r
\r
반사격자는 지정한 여러 회절 차수로 광선을 나눕니다. 양의 차수 방향은 월드 좌표의 홈 방향과 형상 바깥쪽 법선의 외적으로 정합니다. 효율은 입사 파워에 대한 비율이며 합은 1 이하여야 합니다. 전파할 수 없는 차수와 남은 파워는 손실로 처리하고 다른 차수로 재분배하지 않습니다.\r
\r
검출기는 기준 파장의 +1차 광로에 배치되어 있습니다. 3D Viewer에서 파장별 광선과 diffraction 이벤트, Box Grid의 fluence rate와 radiant flux density를 확인하세요. 거울은 정점 곡률을 초점거리에 맞춘 편평 타원면 오목거울입니다. 격자의 효율과 거울 광학 상수는 교육용 지정값이며, 홈 형상에 따른 편광·파장별 효율, 위상 지연과 회절 한계 분해능은 계산하지 않습니다.\r
\r
[Catalog 예제에서 Spectrometer의 source와 현재 Solver 계약 확인하기](/doc?help=examples)\r
`,ke='# simulate.py: 실행, 전달, 기록\r\n\r\nPython `simulate(*, sim, tasks, vars)`가 named Task의 실행 순서를 정합니다. `sim.run()`의 결과에는 nested 값을 읽을 수 있는 불변 `state`, 다음 Solver에 전달하거나 기록할 `artifacts`, 작은 scalar `observations`가 있습니다.\r\n\r\n- `await sim.record(name, artifact)`: declared RecordedData로 승격하고 서버의 임시 저장 확인까지 대기\r\n- `sim.release(artifact)`: 더 사용하지 않는 중간 artifact 해제\r\n- `sim.release(state, keep=next_state)`: 다음 계산에 필요한 state를 보호하면서 이전 state 해제\r\n- `inputs={port: artifact}`: producer artifact를 호환되는 consumer input port에 전달\r\n- `state=...`: 같은 실행에서 받은 live state revision을 이어서 계산할 때 사용\r\n\r\n변경이 없는 Task는 입력과 같은 state handle을 돌려줍니다. 반복 계산에서는 매번 이전 state를 무조건 해제하지 말고 `keep`으로 새 state를 보호하세요. checkpoint도 남기려면 `keep=(result["state"], checkpoint)`를 사용합니다. 다음 예제의 `state`는 앞선 `sim.run()`에서 받은 값입니다.\r\n\r\n```python\r\nresult = await sim.run(tasks["step"], state=state)\r\nsim.release(state, keep=result["state"])\r\nstate = result["state"]\r\n```\r\n\r\n[Electro-Thermal Notched Bar의 canonical simulate.py 열기](/doc?help=examples&item=caemble:experiment/caemble/verified/electro-thermal-notched-bar@5.0.0)\r\n',Me=`# 실행 중 state와 artifact 규칙\r
\r
state와 artifact handle은 현재 run 안에서만 유효합니다. 다른 run의 handle이나 해제한 handle을 다시 사용하면 실행이 실패합니다. 해제한 state root는 새로 읽거나 다음 \`sim.run()\`에 전달할 수 없지만 계산 계보는 run 종료까지 남습니다.\r
\r
\`sim.release()\`와 \`keep\`은 handle 하나 또는 handle을 담은 mapping/list/tuple을 받습니다. 값의 내용이 아니라 같은 state revision 또는 같은 artifact인지 비교하며, 모든 대상을 확인한 뒤 해제합니다. 시작점인 빈 state revision 0을 해제해도 다음 계산에서 계속 사용할 수 있습니다. 실행 중인 Task의 base state 해제는 거부되므로 \`await sim.run()\`이 끝난 뒤 해제하세요.\r
\r
state 하나를 해제해도 같은 값을 사용하는 다른 state, artifact나 ACK 대기 기록은 유지됩니다. 이미 꺼낸 array를 다른 변수에 보관하면 그 참조가 남아 있는 동안 메모리도 유지될 수 있습니다. 기존 코드는 state를 자동 해제하지 않으므로, 반복 계산에서 필요 없는 과거 state는 명시적으로 해제하세요.\r
\r
Solver 호출이 실패하면 해당 호출이 만든 state와 artifact를 함께 rollback합니다. sim.record() 결과는 실행이 끝날 때까지 provisional이며, 뒤 Task나 Python orchestration이 실패하면 모두 폐기됩니다. 실행 전체가 성공해야 서버가 RecordedData를 확정합니다.\r
\r
time-series는 같은 이름을 반복 기록하지 말고 시간축이 있는 하나의 tensor artifact로 만드세요. 작은 반복 조건은 observation을 사용하고 큰 물리 데이터는 artifact로 전달합니다.\r
`,Se=`# Catalog 기반 RecordedData와 Viewer\r
\r
Experiment의 \`recordedData\`는 \`결과이름: { task, output }\`으로 선언합니다. \`task\`는 Task 파일의 이름이고 \`output\`은 해당 Task가 요청한 Box Grid output의 \`key\`입니다. 각 output은 Experiment 또는 해당 Task의 Box 하나를 target으로 지정하고 \`gridShape\`를 필수로 받습니다. 결과 이름은 자유롭게 정하며 수동 dtype/group schema는 지원하지 않습니다.\r
\r
공통 빌드는 Catalog output의 7차원 tensor schema와 표시 계약을 해석하고, Task·output·Solver 버전·Catalog revision을 결과 계약에 고정합니다. 같은 Experiment에서 여러 Solver의 결과를 함께 선언할 수 있습니다. 실행 순서와 데이터 전달은 \`simulate.py\`의 \`sim.run\`, \`sim.record\`, \`sim.release\`가 소유합니다. \`sim.record(name, artifact)\`에는 선언한 Task/output에서 생성된 live Box Grid artifact를 전달해야 합니다. Solver 사이에 전달할 native field/domain은 Task의 \`config.exports\`로 요청하며 기록할 수 없습니다.\r
\r
Experiment와 Measurement 결과 조회, CLI 로컬 결과 및 export에는 고정된 결과 계약이 함께 제공됩니다. 저장 결과를 열 때 최신 Catalog나 편집 중인 소스로 재해석하지 않습니다. Measurement가 있는 Experiment의 source와 계약은 변경할 수 없으므로 새 버전을 만드세요. 표준 전환 시 과거 결과·결과 계약·Calculation preflight는 초기화되며 source, Measurement vars와 material snapshot은 보존됩니다. 과거 결과를 새 축으로 자동 변환하지 않습니다.\r
\r
메쉬·ray path는 Solver가 자동으로 제공하는 별도 시각화 데이터입니다. outputs나 \`recordedData\`에 선언하지 않으며 Calculation·Analysis·Prediction 입력에 포함하지 않습니다. 반복 실행에서는 Task마다 마지막 성공 invocation의 전체 시각화 snapshot을 저장하고, 시간 이력은 그 snapshot 안에 유지합니다. Viewer의 결과 선택 영역에서 Geometry, Box Grid와 자동 시각화를 선택합니다. renderer는 결과 이름이 아닌 저장된 semantic kind로 결정합니다.\r
\r
- \`mesh-field\`: 기록된 메쉬와 Field를 표시합니다. 성분·크기, 단면, 모서리, 범례를 제공합니다. displacement 의미가 선언된 결과는 변형 배율을, stress 의미가 선언된 결과는 von Mises 표시를 제공합니다.\r
- \`polyline\`: 계약에 연결된 정점과 offset으로 경로를 구성합니다. 여러 결과를 독립적으로 선택할 수 있습니다.
- \`particle-set\`: 입자의 저장 시각·물리량 성분·ID·Material을 확인합니다. DEM의 실제 반경과 SPH·MPM의 화면 점 크기를 구분합니다. [입자 해석 안내](program-particles.md)에서 실행 예제와 제한을 확인하세요.
- \`box-grid\`: Histogram, Line Chart, Heatmap, 3D Point cloud로 수치 Output을 표시합니다. 채널·성분·표시 축과 나머지 축의 집계 또는 개별 index를 선택합니다.\r
\r
초기 Overlay는 기준 Geometry 위 mesh field 하나와 여러 polyline 결과를 지원합니다. 길이 단위를 변환하며 같은 Experiment 좌표계로 선언된 결과만 연결합니다. 현재 Geometry source 또는 Vars가 저장 결과와 다르면 Geometry Overlay를 표시하지 않습니다. 기본 Geometry는 원래 좌표이며 변형 배율이 적용된 mesh와 원래 좌표의 polyline을 동시에 표시하지 않습니다. Measurement를 바꾸면 선택과 Overlay를 초기화합니다. 개별 결과의 형식 오류는 다른 결과 조회를 막지 않습니다.\r
\r
Box Grid 데이터는 float32 또는 float64이며 축 순서는 항상 \`[x, y, z, time, frequency, amplitudePhase, component]\`입니다. 사용하지 않는 축도 길이 1로 보존합니다. 실수는 \`value\` 채널 하나, 복소수는 \`amplitude\`, \`phase\` 두 채널로 저장하며 위상 단위는 rad입니다. 각 RecordedData의 ExperimentRecord ID는 Calculation dependency로 사용합니다. 자동 시각화는 별도 \`/measurement/{id}/visualizations\` 조회와 CLI export에 포함됩니다.\r
\r
[Catalog 공식 예제](/doc?help=examples)에서 현재 Box Grid outputs와 자동 mesh·ray 시각화의 실행 소스를 확인하세요.\r
\r
## 변형 형상과 시간 이력\r
\r
tet4 displacement 결과는 변형 표시와 자동 확대가 기본입니다. 자동 확대는 전체\r
시간 구간의 최대 변위를 원래 mesh bounding box 대각선의 10%로 맞춥니다.\r
화면에 표시되는 배율은 좌표에만 적용되며 물리 값과 색상 범례는 바뀌지 않습니다.\r
\`실제 크기 1×\` 또는 \`직접 입력\`으로 배율을 바꾸고, \`원형 윤곽 비교\`로 기준 mesh를\r
함께 볼 수 있습니다. 변형 표시에서는 원래 Geometry의 불투명 면을 숨깁니다.\r
\r
stress 결과는 같은 Task와 domain, 절점 ID, 연결성, 좌표계가 확인된 정적 displacement를\r
선택해 변형 형상 위에 표시합니다. 후보가 하나면 자동 연결하며, 일부 영역 mesh나\r
서로 다른 domain은 배열 크기가 같아도 연결하지 않습니다.\r
\r
시간 이력은 mesh와 모든 절점의 변위가 함께 기록된 결과에서 재생합니다. 일반 표면\r
평균 history나 최종 displacement만으로 전체 구조 애니메이션을 복원하지 않습니다.\r
재생은 첫 프레임에서 정지한 상태로 시작합니다. 기본 속도는 전체 구간을 5초에\r
보여주며 실제 시간 대비 배속을 표시합니다. 슬라이더와 이전·다음 프레임으로 저장된\r
시점을 선택하고, 재생·일시정지, 반복과 속도를 조절할 수 있습니다. 시간 보간은 하지\r
않습니다. 색상 범위와 자동 배율은 전체 구간에 고정되며 최종 stress를 과거 시점의\r
응력으로 표시하지 않습니다.\r
\r
직접 확인하려면 Catalog의 **structural-analysis-modes** 예제를 새로 빌드·실행한 뒤\r
transient Task의 자동 displacement history 시각화를 선택합니다. 전체 절점 이력은\r
별도 output이나 \`sim.record\` 선언 없이 포함됩니다. 초기 자동 확대, 실제 크기 1×,\r
원형 윤곽 비교, 시간 슬라이더와 재생을 차례로 확인하세요. 재생 중 카메라를 이동해도\r
자동으로 맞춤이 반복되지 않아야 하고, Measurement를 바꾸면 재생과 선택이 초기화되어야\r
합니다. 마지막 상태와 전체 시간 이력은 각 자동 시각화에서 확인합니다.\r
상세한 output 문법은 현재 Catalog 계약과 이 예제 소스를 기준으로 확인하세요.\r
\r
## 복소수 장과 3D 단면\r
\r
Spectral field와 시간 기록 모두 \`[x, y, z, time, frequency, amplitudePhase, component]\`\r
순서의 실수 tensor입니다. 주파수 입력은\r
명시적인 \`frequencies\` tensor이며 입력 순서가 그대로 기록됩니다. 서로 다른\r
검출기와 전기장·자기장은 독립 결과로 유지됩니다. 정확한 authoring 문법은\r
현재 Catalog의 FDTD output 계약과 공식 예제에서 확인합니다.\r
\r
실수 장은 \`amplitudePhase\` 축의 \`value\` 하나를 사용합니다. 복소수 장은 이 축에\r
진폭과 위상을 저장하며 \`boxGrid.channels\`는 \`['amplitude', 'phase']\`입니다.\r
진폭은 장의 물리 단위, 위상은 rad이며 진폭이 0인 표본의 저장 위상도 0입니다.\r
저장·attachment·CLI export는 같은 7차원 형식을 사용합니다.\r
\r
Box Grid의 표시 방식은 **Histogram / Line Chart / Heatmap / 3D Point cloud**에서\r
선택합니다. 공간 축만 사용하는 Heatmap과 3D는 저장된 Box의 origin, rotation과\r
길이 단위로 Geometry에 겹칩니다. x·y·z ticks는 Box local 셀 중심이며 해석\r
영역 밖 표본은 0입니다. Geometry와 결과의 source/Vars가 일치해야 겹칠 수 있습니다.\r
\r
기본 채널은 실수 장의 Value 또는 복소수 장의 Amplitude입니다. 벡터는\r
절대값(크기)이나 개별 성분을 선택하고, Phase는 성분 하나의 위상을 rad로\r
표시합니다. 전체 크기는 \`sqrt(Σ|component|²)\`이며 광강도가 아닙니다.\r
초기 Frequency 집계는 sum, 나머지 표시하지 않는 축은 mean이므로 특정 시점·주파수·단면을 보려면\r
해당 축을 **개별 index**로 바꿉니다. 공간 Heatmap의 남은 공간 축을 집계하면\r
Box 중앙 평면에 표시합니다. 상세한 기본 축 선택과 표본 조회는\r
[Output 시각화](../workbench/workbench-viewer-selection.md#output-시각화)를 따릅니다.\r
\r
### 진동과 시간·주파수 순회\r
\r
**재생**에서 **진동 · 공통 시간**을 선택하면 복소 성분을\r
\`A_f,c × cos(φ_f,c + 2πf t)\`로 표시합니다. 모든 주파수가 동일한 시간 \`t\`를\r
사용하므로 각 주파수의 위상은 주파수에 비례해 진행하며 0 Hz는 일정합니다.\r
Frequency sum/mean에서는 성분별 순간값을 합성한 뒤 벡터 크기를 구하고 나머지\r
축을 집계합니다. mean은 주파수 표본 수로 나눕니다. 저장된 진폭·위상을 그대로\r
사용하며 추가 주파수 가중치나 FFT 정규화를 적용하지 않습니다. 원래 펄스의\r
역변환을 보장하는 기능은 아닙니다. 실수부·허수부를 별도 저장 채널로 추가하지 않습니다.\r
\r
시간 또는 주파수가 표시 축에 포함되지 않으면 해당 축의 **index 순회**를\r
선택할 수 있습니다. Histogram은 둘 다 순회할 수 있습니다. 재생·일시정지,\r
프레임·속도·반복을 조절하며 재생 중 값 범위와 카메라를 유지합니다. 진동 시간과\r
구간은 s로 표시하고, 기본 구간은 최저 양의 주파수 한 주기입니다. 최고 주파수\r
한 주기를 20프레임, 화면에서 약 2초에 재생하며 구간 길이를 직접 바꿀 수 있습니다.\r
반복은 구간 끝에서 0으로 돌아가며 공통 주기를 보장하지 않습니다.\r
\r
Gold FCC Array의 새 결과에서 \`referenceScattered\`, \`incident\`, \`scattered\`를\r
선택하고 Heatmap의 공간 축과 frequency 개별 index를 지정하세요. 성분과\r
Amplitude·Phase를 바꾸고, **진동 · 공통 시간** 및 **frequency index 순회**를\r
차례로 확인합니다. Geometry 겹치기, 투명도, 값 범위 고정과 표본 조회도 확인하세요.\r
\r
### Catalog·Draft에서 임시 실행

강체 결과는 고정된 기준 mesh에 body별 위치·자세를 적용해 표시합니다.
변형 배율은 1이며, 재생 frame 사이에서 회전을 보간해 형상이 찌그러지지
않습니다. Result 선택에서 강체 운동과 기록된 밀도·속도 Grid를 확인할 수
있습니다. History의 final 출력은 마지막 수락된 출력 표본이며, 실제 호출
종료 시각의 상태는 native snapshot에 있습니다.

**Experiment 탭**에서 Catalog 예제나 Draft를 열고 Vars 준비가 끝나면
리본의 **실행**을 누릅니다. **Candidate 재생성 + 실행**은 새 Candidate의\r
평가·빌드가 성공한 뒤 실행합니다. 현재 설정을 그대로 사용하며 자동으로\r
격자·ray 수·시간 간격을 줄이지 않습니다. 로그인과 연결된 CAE Launcher가\r
필요하고 준비·실행 중에는 취소할 수 있습니다.\r
\r
실행 중에는 이전 결과를 유지하고, 새 결과가 도착하면 Viewer의 선택·체크 설정과\r
카메라를 유지하며 데이터를 교체합니다. 아직 선택하지 않은 Viewer는 Geometry와\r
겹쳐 표시 가능한 결과를 무작위 선택합니다. 임시 결과는 실행 당시 Geometry와\r
Vars에 연결되며 **임시 결과 닫기**로 현재 작업 화면으로 돌아갑니다.\r
Experiment나 Measurement는 저장하지 않습니다. 작은 결과는 DB에, 큰 결과는\r
Bucket에 저장하고 완료 후 24시간이 지나면 서버가 정리합니다.\r
\r
Gold FCC Array에서는 주파수·성분과 3D 단면을, Structural 예제에서는 변형과\r
시간 재생을 확인하세요. 데이터 교체 시 재생은 정지하고 범위를 벗어난 축·프레임은\r
보정됩니다. Experiment·Measurement 전환 시 임시 Viewer 상태는 초기화됩니다.\r
`,De=`# 검증된 Examples\r
\r
다음 Examples는 SQLite 카탈로그의 source bundle을 Workbench와 UI-CAE 계약 테스트가 직접 사용합니다.\r
\r
- [Electro-Thermal Notched Bar](/doc?help=examples&item=caemble:experiment/caemble/verified/electro-thermal-notched-bar@5.0.0)\r
- [Folded Ray-Tracing Bench](/doc?help=examples&item=caemble:experiment/caemble/verified/folded-ray-tracing@5.0.0)\r
- [FDTD Drude Slab Pulse](/doc?help=examples&item=caemble:experiment/caemble/verified/fdtd-drude-slab@6.0.0)\r
- [Fiber Bundle](/doc?help=examples&item=caemble:experiment/caemble/advanced-shapes/fiber-bundle@5.0.0)\r
- [Shell Cutaways](/doc?help=examples&item=caemble:experiment/caemble/advanced-shapes/shell-cutaways@5.0.0)\r
- [Random Curved-edge Cylinder Array](/doc?help=examples&item=caemble:experiment/caemble/arrays/random-curved-edge-cylinder-array@5.0.0)\r
- [Random Curved-surface Sphere HCP Array](/doc?help=examples&item=caemble:experiment/caemble/arrays/random-curved-surface-sphere-hcp-array@5.0.0)\r
- [Two-material Wheel Assembly](/doc?help=examples&item=caemble:experiment/caemble/assemblies/two-material-wheel-assembly@5.0.0)\r
`,Ee=`# Multiphysics 예제: Electro-Thermal Notched Bar\r
\r
[Electro-Thermal Notched Bar의 canonical bundle 열기](/doc?help=examples&item=caemble:experiment/caemble/verified/electro-thermal-notched-bar@5.0.0)\r
`,Pe='# 공개 Source와 import 경계\r\n\r\nExperiment source bundle은 핵심 파일뿐 아니라 사용자가 추가한 로컬 `.ts`, `.tsx` 파일도 함께 저장합니다. TypeScript/TSX 파일은 bundle 안의 다른 파일을 상대 경로로 import할 수 있습니다. Python은 핵심 `simulate.py` 한 파일만 사용합니다. `@caemble/core` 외 package, URL, 동적 `import()`와 `require()`는 지원하지 않습니다.\r\n\r\nExperiment 정의는 `experiment({...})`, 각 Task는 `defineTask({...})`를 default export합니다. `material.tsx`는 named Material 객체 또는 factory를 export하고, `geometry.tsx`는 PascalCase named `Geometry<Props>` 함수 component를 여러 개 export할 수 있습니다. 모든 의존 코드는 같은 Experiment bundle 안에 있으므로 별도 Geometry Repository나 Version coordinate를 해석하지 않습니다.\r\n\r\n부분 예시 — 다음 fence는 완성 파일이 아니라 로컬 bundle import 경계만 보여줍니다.\r\n\r\n```tsx\r\n// geometry.tsx\r\nimport { profilePoints } from "./lib/profile";\r\nexport const Conductor: Geometry = () => <Polygon points={profilePoints} />;\r\n```\r\n\r\nExperiment Manager는 source-only **Example**, 저장된 사용자 Experiment Version, 데이터가 있는 공개 **Demo**를 구분해 엽니다. 저장된 coordinate는 `namespace / repository / key / SemVer`로 식별하며, Repository는 별도 관리 객체가 아니라 저장된 Experiment에서 파생되는 그룹입니다.\r\n\r\n**Save**는 Draft이면 Save As를 열고, 저장된 Version에 Measurement가 없으면 덮어씁니다. Measurement가 하나라도 있으면 현재 Experiment를 대상으로 Save As를 엽니다. **Save As**에서 기존 대상을 선택하면 최신 버전에서 patch/minor/major를 증가시키고, 새 Experiment를 선택하면 새 repository/key의 `0.1.0`을 만듭니다. 저장 과정에서 컴파일된 RecordedData 선언은 ExperimentRecord 계약으로 함께 동기화됩니다. Measurement가 있는 Version은 source와 Record 계약이 잠기므로 key·QuantityKind·tensorOrder·dtype·data schema를 바꾸려면 새 Version 또는 Save As를 사용해야 합니다. Workbench에서는 metadata만 바꾸더라도 Measurement가 있으면 새 Version으로 저장합니다. 기존 CLI/API의 metadata 저장 계약은 유지됩니다.\r\n\r\nStandalone preview는 선택한 named export를 props 없이 호출할 수 있습니다. 모든 local PascalCase `Geometry<Props>` 함수는 custom prop을 직접 구조 분해하고 각각 명시적인 기본값을 제공해야 합니다. `id`, Material, children과 transform은 evaluator가 공통 기본값을 주입합니다.\r\n\r\nSource revision은 compile한 뒤 명시적인 Candidate vars로 같은 compiled source를 다시 evaluate합니다. 브라우저나 Node 전역, 시간, 네트워크 같은 외부 상태에 의존하는 코드는 재현 가능한 Measurement를 만들 수 없습니다.\r\n\r\n카탈로그 예제에 등록된 Calculation은 개인 Experiment로 저장할 때 함께 저장됩니다. **Save As**에서 새 Experiment를 만들면 현재 원본의 Calculation을 복사하고, 기존 대상을 선택하여 새 버전을 만들면 그 대상 Version의 Calculation 전체 이름·설명·코드를 계승합니다. 새 Calculation은 새 ID와 revision 1을 가지며, Measurement·실행 결과·기존 검증 계약은 복사하지 않습니다. 대상 Experiment에서 Measurement를 실행하고 Calculation을 다시 검증한 뒤 저장하세요. 편집 중인 미저장 Calculation 초안은 복사 대상이 아닙니다.\r\n\r\nCalculation만 있고 Measurement가 없으면 Experiment source와 Record 계약을 덮어쓸 수 있습니다. source 또는 Record 계약을 변경하면 기존 Calculation은 재검증 대기로 전환됩니다. 이름·설명만 수정하면 검증 상태를 유지합니다. 실행 전이라도 저장된 Measurement가 하나 있으면 source와 Record 계약은 잠깁니다.\r\n',Re="# Geometry 저작 골격과 좌표계\r\n\r\nCAD API v1 Geometry는 JSX를 반환하는 순수 함수 component입니다. `geometry.tsx`에는 재사용할 named `Geometry<Props>`를 두고, `experiment.tsx`의 `geometry` callback에서 호출합니다. 모든 custom prop은 required/optional 표기와 관계없이 구조 분해 initializer가 있어야 하므로 `<Assembly />`처럼 props 없이 호출할 수 있습니다. 숫자로 된 길이는 모두 해당 scene의 `lengthUnit`으로 해석됩니다.\r\n\r\n새 Experiment를 만들 때 Workbench가 제공하는 starter source bundle도 이 규칙을 따르며, AI reference 생성 시 같은 `experiment.tsx`와 `geometry.tsx`를 사용합니다.\r\n\r\n좌표계는 오른손 좌표계입니다. `+X`, `+Y`, `+Z`와 회전의 양의 방향에는 오른손 법칙을 적용합니다. primitive의 기준축과 원점은 요소마다 다르므로 추측하지 말고 [Geometry Catalog](/doc?help=geometry)의 **Origin / surfaces**를 확인하세요. 예를 들어 기본 cylinder 축은 Z이고, box와 cylinder는 자신의 local origin을 중심으로 생성됩니다.\r\n\r\ncomponent는 입력 props와 `vars`만으로 같은 tree를 만들어야 합니다. 시간, 난수, DOM, 네트워크나 변경 가능한 module 상태에 의존하면 같은 source와 Measurement를 재현할 수 없습니다.\r\n\r\nPrimitive는 props를 생략하면 Catalog에 표시된 canonical 단위 형상 기본값을 사용합니다. 자동 ID는 authoring name의 lower-kebab과 sibling 순번(`box`, `box-2`)으로 정해집니다.\r\n\r\n`for`, `Array.from`/`map`, `if`와 조건부 JSX를 사용할 수 있습니다. 반복 횟수는 유한하고 입력으로 재현 가능해야 하며, 반복되는 sibling에는 삽입·재정렬에도 유지되는 index나 domain key 기반의 명시적 `id`를 만드세요. 규칙적인 격자는 JS loop보다 `array` operation을 우선합니다.\r\n",Ae='# Transform: direct props와 operation wrapper\r\n\r\nPrimitive, Boolean·shell·array operation과 `Geometry` component 호출은 같은 direct transform 계약을 사용합니다. `translate`·`rotate`·`scale` wrapper는 별도의 전용 prop 계약을 사용합니다.\r\n\r\n| Prop | 형식 | 의미 |\r\n| --- | --- | --- |\r\n| `position` | `[x, y, z]` | parent 좌표계에서의 이동 |\r\n| `rotation` | `[x, y, z]` | radian 단위의 intrinsic XYZ Euler, `THREE.Euler(x, y, z, "XYZ")`와 같은 의미 |\r\n| `scale` | `[x, y, z]` | 축별 배율. 균일 배율은 세 값을 같게 작성 |\r\n\r\n한 node 안에서는 **scale → rotation → position** 순서로 적용됩니다. parent와 child transform은 tree 계층대로 합성됩니다. 각도는 degree가 아니라 radian이므로 `Math.PI / 2`처럼 작성하세요.\r\n\r\n부분 예시 — 아래 fence는 완성 파일이 아닌 단일 intrinsic element 식입니다.\r\n\r\n```tsx\r\n<Cylinder\r\n  id="arm"\r\n  radius={2.5}\r\n  height={200}\r\n  position={[0, 100, 298]}\r\n  rotation={[Math.PI / 2, 0, 0]}\r\n/>\r\n```\r\n\r\n여러 child를 한 local transform 아래 묶을 때는 lowercase operation wrapper를 사용합니다. Wrapper는 아래 전용 prop만 받고 direct transform prop과 섞지 않습니다. 안쪽 wrapper부터 적용되므로 다음 순서는 scale → rotate → translate입니다.\r\n\r\n```tsx\r\nimport { Box, radians } from \'@caemble/core\'\r\n\r\n<translate offset={[100, 0, 0]}>\r\n  <rotate axis={[0, 0, 1]} angle={radians(90)}>\r\n    <scale x={2} y={1} z={1}>\r\n      <Box id="body" size={[20, 10, 5]} />\r\n    </scale>\r\n  </rotate>\r\n</translate>\r\n```\r\n\r\n`radians(number)`와 `radians(Vec3)`는 degree를 radian으로 바꿉니다. Direct `rotation`은 intrinsic XYZ Euler Vec3이고, `<rotate>`는 오른손 법칙의 axis-angle이므로 두 표현의 의미를 구분하세요.\r\n\r\n`pos`와 `{ axis, angle }` 형태의 `rotate`는 v7 안에서 기존 source를 잠시 옮기기 위한 deprecated 호환 문법입니다. 새 코드는 `position`과 `rotation`만 사용하세요. 같은 node에서 canonical family와 deprecated family를 섞을 수 없으며 `translation` prop은 지원하지 않습니다.\r\n',je="# ID, group과 surface identity\r\n\r\n`id`는 단순한 화면 label이 아니라 Geometry 결과의 identity입니다. custom `Geometry` component를 호출할 때는 `id`가 필수이고, 모든 intrinsic primitive와 operation에는 필요할 때 `id`를 줄 수 있습니다. Fragment(`<>...</>`)에는 `id`나 transform을 줄 수 없습니다.\r\n\r\n- primitive의 `id`는 그 primitive가 만든 part를 소유합니다.\r\n- topology를 바꾸는 `union`, `subtract`, `intersect`, `shell` 같은 operation에 `id`가 있으면 그 operation의 최종 결과가 해당 identity를 소유합니다. 피연산자 ID가 Boolean 결과의 ID라고 가정하지 마세요.\r\n- component의 `id`는 재사용되는 subtree의 namespace/root identity가 됩니다. 같은 parent 아래의 sibling ID는 서로 달라야 합니다.\r\n- evaluator가 component 호출의 `id`를 이미 소비하므로 받은 `id`를 leaf intrinsic에 그대로 전달하지 마세요. child에 별도 local segment가 필요할 때만 intrinsic `id`를 부여합니다.\r\n- `geometryGroup`에는 의도적으로 부여한 결과 ID만 넣고, 실행 전에 Viewer에서 실제 resolve 결과를 확인하세요.\r\n- CAD API v1 surface는 `<geometry-id>/surface/<non-negative-index>`로 참조합니다. 예를 들어 `conductor.body` Box leaf의 local +X slot은 `conductor.body/surface/1`입니다. leaf에 명시적 `id`를 주고 Geometry Catalog에 표시된 고정 slot을 사용하세요.\r\n- 공식 Catalog는 각 Example의 공개 계약 v1 Version만 제공합니다. 제거된 이전 coordinate에는 alias나 redirect가 없으며 조회 시 `404 catalog_not_found`를 반환합니다.\r\n- 한 Boolean operation은 최대 128개 operand를 받습니다. 큰 lattice를 중첩 Boolean으로 전개하면 Manifold 실행 전에 triangle 및 triangle-pair work 예산에서 거부됩니다.\r\n\r\n중간 조립용 Fragment에 억지로 identity를 만들기보다 named `Geometry` component로 추출하세요. 반대로 solver가 최종 Boolean body 하나만 필요하면 operation에 `id`를 주는 편이 소유권이 가장 분명합니다.\r\n",Te="# Primitive 선택과 operation 규칙\r\n\r\n표현할 수 있다면 `Box`, `Cylinder`, `Sphere`부터 사용하세요. Primitive는 `@caemble/core`에서 PascalCase로 import하고 operation은 lowercase JSX tag로 작성합니다. 곡선 단면·표면이 실제 요구사항일 때만 `CurvedEdgeCylinder`, `CurvedSurfaceSphere`, `Fiber`를 선택하면 parameter와 mesh 비용을 줄일 수 있습니다. 각 prop의 type, 필수 여부, 기본값, 제약, 기준 원점, surface 의미와 실행 가능한 예제는 [Geometry Catalog](/doc?help=geometry)가 공식 원본입니다.\r\n\r\n| Operation   | child 계약                                              | 핵심 규칙                                                             |\r\n| ----------- | ------------------------------------------------------- | --------------------------------------------------------------------- |\r\n| `translate` | 1개 이상                                                | `offset` Vec3로 child group을 상대 이동                               |\r\n| `rotate`    | 1개 이상                                                | `axis`와 radian `angle`로 오른손 axis-angle 회전                      |\r\n| `scale`     | 1개 이상                                                | `x`, `y`, `z` 축별 배율을 local 원점 기준으로 적용                    |\r\n| `union`     | 1개 이상                                                | 모든 child를 하나의 결과로 결합                                       |\r\n| `subtract`  | 2개 이상                                                | 첫 child가 base, 이후 child는 cutter                                  |\r\n| `intersect` | 2개 이상                                                | 모든 child의 공통 체적만 유지                                         |\r\n| `shell`     | 정확히 1개                                              | material role별 offset surface 생성                                   |\r\n| `array`     | 정확히 1개의 identified intrinsic 또는 `Geometry` child | `shape`, `period`, 선택적 `axes`와 canonical `inject`로 instance 생성 |\r\n\r\nBoolean child 순서는 source 계약의 일부입니다. ring은 큰 cylinder 하나로 근사하지 말고, 큰 cylinder에서 더 높고 작은 cylinder를 빼서 실제 annular solid를 만드세요. 0 두께, 음수 크기, NaN/Infinity, 퇴화한 축처럼 유효하지 않은 입력은 evaluator가 거부합니다.\r\n\r\nMaterial은 root에서 역할 map으로 주입하고 leaf에서 `body`로 remap합니다. 생략하면 parent map을 상속하고, 명시하면 교체하며, `materials={{}}`는 상속을 지웁니다. 자세한 모델 입력과 역할 계약은 [Material과 Model Parameter](/doc?help=manual&item=program-materials)을 참고하세요.\r\n",Ie="# @caemble/core 핵심 API\r\n\r\n| Symbol            | 사용 위치          | 역할                                                                      |\r\n| ----------------- | ------------------ | ------------------------------------------------------------------------- |\r\n| `experiment`      | `experiment.tsx`   | 공통 geometry, vars, Material 역할 주입, group과 RecordedData schema 정의 |\r\n| `defineTask`      | `tasks/*.tsx`      | solver identity, Task scene과 config 정의                                 |\r\n| `Material`        | `material.tsx`     | Experiment 안의 모델 인스턴스와 명시적인 Model Parameter 정의             |\r\n| `Mat`             | Material tensor 값 | scalar를 등방성 3×3 tensor로 표현                                         |\r\n| `Geometry<Props>` | TSX component type | 재사용 가능한 Geometry component의 props 정의                             |\r\n| `Vec3`            | 위치·크기 props    | 길이 3 vector type                                                        |\r\n| `Box` 등          | Geometry TSX       | PascalCase primitive literal alias                                        |\r\n| `radians`         | Geometry transform | degree number 또는 Vec3를 radian으로 변환                                 |\r\n\r\nGeometry element의 실제 tag와 prop syntax는 [Geometry Catalog](/doc?help=geometry), solver method와 parameter는 [Physics Catalog](/doc?help=solvers)를 사용하세요. catalog가 declaration과 manifest의 최신 단일 원본입니다.\r\n",Ne="# DataSchema, QuantityKind와 UCUM 단위\r\n\r\n물리 데이터는 값만 전달하지 않습니다. `dtype`, `unit`, `quantityKind`, 필요하면 `axes`가 함께 계약을 이룹니다.\r\n\r\n아래의 scalar/component 규칙은 Material 모델 파라미터 등 일반 DataSchema에 적용합니다.\r\n\r\n- scalar는 axes가 없습니다.\r\n- vector 또는 matrix의 component shape는 QuantityKind의 `tensorOrder`와 일치해야 합니다.\r\n- 공간장과 time-series의 sample 축은 `axes`에서 길이와 의미를 선언합니다.\r\n- unit은 [Quantity Catalog](/doc?help=quantity-kinds)의 `applicableUnits`에 있고 worker가 변환할 수 있는 UCUM 문자열이어야 합니다.\r\n- `{fraction}`처럼 중괄호가 있는 UCUM annotation도 문자열 그대로 사용합니다.\r\n\r\nModel Catalog의 각 파라미터가 요구하는 QuantityKind·shape·unit과 실제 worker의 단위 변환 계약을 모두 만족해야 합니다.\r\n\r\nRecordedData의 Box Grid Output은 별도 계약입니다. scalar도 `[x, y, z, time, frequency, amplitudePhase, component]` 일곱 축을 유지하고, 모든 성분을 마지막 축에 평탄화합니다. `tensorOrder`만큼 추가 차원을 붙이지 않습니다. 복소수도 float32/float64의 진폭·위상 채널로 저장하며, 자세한 계약은 [출력과 기록](../program/program-domain-recording.md)을 참고하세요.\r\n",Ge=`# Target, run 상태와 결과 경계\r
\r
target 문자열은 \`<scene>.<kind>.<group>\` 형태입니다. \`experiment.*\`는 공통 물리 scene, \`task.*\`는 현재 named Task의 local scene을 가리킵니다. method manifest의 \`source\`와 \`kind\`가 target과 일치해야 합니다.\r
\r
Prepared Measurement는 고정 입력 조건입니다. CAE 실행은 서버 batch의 개별 작업으로 추적하며 worker가 큰 결과를 S3에 직접 업로드하고 결과 참조가 서버에 저장되면 Measurement가 Recorded 상태가 됩니다. opaque solver state와 중간 artifact는 CAE worker 밖으로 나오지 않습니다. 브라우저는 서버에서 진행 상태와 결과 참조를 받고 큰 RecordedData 본문은 S3에서 직접 읽습니다. 기존 inline/base64 결과도 계속 읽을 수 있습니다. trace와 provenance는 진단용이며 사용자 결과 schema에 자동 추가되지 않습니다.

주파수응답의 Box Grid는 진폭과 위상을 보존합니다. 진폭은 peak 값이며
RMS가 필요하면 단일 조화 신호에서 진폭을 \`sqrt(2)\`로 나눕니다. Native mesh의
주파수·위상 선택은 그 응답의 순간값을 표시합니다. 처음에는 첫 계산 주파수와
위상 0°가 선택되며 선택값을 화면에서 확인하고 변경할 수 있습니다.
비교 대상에 같은 주파수가 없으면 해당 값을 표시할 수 없음을 알립니다.

압력은 위상에 따라 양수와 음수가 되는 순간 음압입니다. 응력에 변형 형상을
겹칠 때는 같은 결과·주파수·위상의 변위를 사용합니다. 표시용 변형 배율은
기록된 물리 값이나 단위를 바꾸지 않습니다. Native 표시와 다른 Solver에
전달하는 표면 운동은 Box Grid 기록과 별개이며 Calculation·Prediction에는
선택한 수치 Record만 사용합니다.
`,Ve=`# 문서가 Ready가 되지 않을 때

## 증상과 확인 위치

Source를 수정한 뒤 \`Ready\`가 되지 않거나 실행 버튼이 비활성화되면 **Experiment → Source의 diagnostics**에서 첫 오류를 확인하세요. 뒤따르는 오류는 첫 오류가 해결되면 사라질 수 있습니다.

| 증상                     | 비교할 정보                   | 해결 방법                                             |
| ------------------------ | ----------------------------- | ----------------------------------------------------- |
| import·export·TSX 오류   | 표시된 파일명과 줄 번호       | 현재 API Reference와 Geometry 문법에 맞춰 수정합니다. |
| Vars·shape 오류          | \`varsSchema\`와 실제 Candidate | scalar와 tensor 선언, 값의 shape를 일치시킵니다.      |
| Material validation 오류 | Material Model의 필수 값·단위 | 해당 모델의 입력 규격을 확인하고 빠진 값을 채웁니다.  |
| Surface·ID 오류          | Geometry의 ID와 Surface 슬롯  | 중복 ID와 범위를 벗어난 Surface 참조를 수정합니다.    |

## 해결 순서

1. diagnostics에 표시된 **파일명, line, column과 첫 오류**부터 확인합니다.
2. import가 \`@caemble/core\`인지, 올바른 default export를 사용하는지 확인합니다.
3. TSX tag와 prop 이름을 Geometry Catalog의 syntax와 비교합니다.
4. \`varsSchema\`의 scalar min/max, tensor의 필수 shape, Candidate의 정확한 shape, Geometry ID 중복과 group member ID를 확인합니다.
5. surface group이 \`<geometry-id>/surface/<non-negative-index>\`를 사용하고 Geometry Catalog의 primitive별 고정 slot 범위에 있는지 확인합니다.
6. 모델 ID와 필수 파라미터, dtype, unit과 tensor shape를 Model Catalog와 비교합니다.

source를 고친 뒤에도 이전 조건만 보인다면 상태가 \`Ready\`인지 확인하고 새 Candidate를 생성합니다. 이전 Experiment revision의 Measurement는 현재 revision에서 실행할 수 없습니다.

## 해결 확인

첫 오류가 사라지고 \`Ready\`가 되면 Viewer의 형상과 Vars를 다시 확인하세요. 실행 단계에서 실패한다면 [Measurement 실행 또는 결과 오류](troubleshooting-runtime-results.md)로 이동하세요.
`,Be="# target 또는 solver manifest 오류\r\n\r\n## 증상과 확인 위치\r\n\r\nTask 검증에서 method·target·호출 횟수 오류가 나오면 **Solver 카탈로그 → Methods**에서 같은 이름과 버전의 계약을 확인하세요. 재료 요구 사항은 **Materials**, 결과 연결은 **Artifacts**에서 확인합니다.\r\n\r\n## 해결 순서\r\n\r\n- Physics Catalog에서 `name@version`이 정확히 존재하는지 확인합니다.\r\n- method가 `initializations`, `boundaryConditions`, `outputs` 중 어디에 속하는지 확인합니다.\r\n- required parameter와 occurrence의 최소·최대 횟수를 확인합니다.\r\n- target의 scene(`experiment`/`task`)과 kind(`geometry`/`surface`)를 확인합니다.\r\n- group 이름이 source에 선언되어 있고 실제 Geometry 또는 surface로 resolve되는지 확인합니다.\r\n\r\n검증 오류를 우회하기 위해 Solver 계약을 UI에 복사해 수정하지 마세요. [Solver 카탈로그](/doc?help=solvers)의 해당 버전 계약에 맞춰 Task를 수정하고 다시 빌드하세요. Launcher 실행 manifest는 이 Solver 계약과 별개입니다.\r\n",_e=`# unit, QuantityKind 또는 Material 오류

## 증상과 확인 위치

오류에 표시된 모델 ID와 파라미터 경로를 기준으로 **Material Model**에서 입력 규격을 확인하세요. 물리량 이름을 누르면 **QuantityKind**의 허용 단위와 사용 관계로 이동할 수 있습니다.

## 해결 순서

1. Model Catalog에서 정확한 \`model\` ID와 버전을 확인합니다. Material 이름은 외부 조회 키가 아닙니다.
2. 오류가 표시한 \`models.<instance>.parameters\` 경로에서 필수 값·객체·리스트 항을 확인합니다.
3. 해당 Model Parameter의 QuantityKind, shape와 단위를 확인합니다. Quantity Catalog의 \`applicableUnits\`와 실제 worker 변환 계약을 모두 만족해야 합니다.
4. Solver가 그 Material 역할에 요구하는 모델 그룹을 확인합니다. 호환 인스턴스가 여러 개이면 Task의 \`materialModels\`에서 하나를 지정합니다.
5. 수치 tensor의 shape·dtype·basis를 확인하고, Vars를 변경했다면 새 Candidate의 Material 입력이 다시 생성됐는지 확인합니다.

## 해결 확인

등록되지 않은 모델이나 불완전한 파라미터는 실행을 차단합니다. Material 이름, source/version, 예전 DB 값으로 누락된 계수를 보충하지 않습니다. 계수를 직접 입력하고 다시 빌드하세요.

\`invalid_unit\`은 worker가 해당 QuantityKind에 대해 변환할 수 없는 단위라는 뜻입니다. catalog membership 하나만 보고 새 단위를 추가하지 마세요.
`,$e=`# Measurement 실행 또는 결과 오류

## 실패한 단계를 먼저 찾기

**Console**에서 첫 오류를 확인하고 **Setting → CAE Jobs**에서 해당 작업의 상태와 오류를 비교하세요. 아래 표에서 실패한 단계부터 확인하면 됩니다.

| 증상                     | 확인 위치                            | 다음 행동                                                                    |
| ------------------------ | ------------------------------------ | ---------------------------------------------------------------------------- |
| 제출 전에 실패함         | Source diagnostics·Console           | 입력 build 오류를 수정하고 다시 제출합니다.                                  |
| 작업이 실행되지 않음     | Setting → Launchers·CAE Jobs         | 내 Launcher 연결과 작업 상태를 확인합니다.                                   |
| Solver 실행이 실패함     | CAE Jobs의 오류와 현재 task·method   | Task 입력과 Solver 계약을 비교하고 원인을 해결한 뒤 명시적으로 재시도합니다. |
| 실행 후 예상 결과가 없음 | Measurement의 RecordedData·기록 계약 | 출력 이름, 기록 이름과 artifact 수명을 확인합니다.                           |

## 입력과 기록 계약 점검

1. 로그인과 CAE Launcher 연결 상태를 확인합니다.
2. 현재 Experiment revision에 속하고 RecordedData가 아직 없는 prepared Measurement를 선택했는지 확인합니다.
3. Python의 task 이름이 \`tasks/<name>.tsx\` 파일명과 일치하는지 확인합니다.
4. output key와 \`result["artifacts"]\` key를 확인합니다.
5. \`sim.record()\` 이름과 Experiment \`recordedData\` 이름을 확인합니다.
6. release한 artifact를 다시 전달하거나 기록하지 않았는지 확인합니다.
7. source를 수정했다면 새 revision에서 새 Measurement를 준비해 실행합니다. 이전 결과는 해당 revision의 기록으로 남습니다.

## 재시도와 취소

실패한 서버 작업은 자동으로 다시 실행되지 않습니다. 오류 원인을 해결하고 **CAE Jobs**에서 명시적으로 재시도하세요. 소스나 입력을 변경해야 한다면 수정한 조건으로 새 작업을 제출하세요. 서버 접수가 완료된 작업은 브라우저를 닫아도 계속되지만, 로컬 build·업로드 중에는 브라우저를 유지해야 합니다.

취소는 정상적인 terminal 상태일 수 있습니다. 실패 원인을 분석할 때는 사용자에게 보이는 첫 오류와 현재 task/method를 함께 기록하고, opaque worker state나 전체 binary 결과를 복사하지 마세요.
`,Le=`# 입자 해석: DEM, SPH, MPM

입자 해석은 Geometry 내부에 입자를 생성하고, 각 입자의 위치·물리량·ID·Material을
함께 추적합니다. DEM은 구형 입자의 접촉과 회전, SPH는 유체 흐름, MPM은
변형하는 고체를 다룹니다. 같은 입자 표시와 결과 형식을 사용하지만 서로 다른
물리 모델과 적분 방법을 사용합니다.

## 실행할 예제 선택

[Catalog Examples](/doc?help=examples)에서 다음 이름으로 검색하고 전체 source를
확인하세요. 계수·단위·정확한 method ID는 예제와 연결된
[Solver 계약](/doc?help=solvers), [Material Model 계약](/doc?help=materials)이 기준입니다.

| 예제 | 확인할 내용 |
| --- | --- |
| dem-floor-contact | 중력으로 떨어지는 입자와 고정 바닥의 접촉 |
| dem-two-material-collision | 서로 다른 Material 입자의 충돌과 명시적 접촉 모델 선택 |
| dem-incline-rolling | 경사면 위에서 마찰에 의해 발생하는 이동과 회전 |
| sph-hydrostatic-column | 닫힌 유체 기둥의 초기 침강 과정; 짧은 실행의 최종값은 정수압 평형이 아님 |
| sph-periodic-channel | 주기 방향으로 흐르는 점성 유체의 속도 분포 |
| mpm-affine-compression | 바닥이 고정된 고체의 초기 압축과 뒤이은 탄성 반등의 변형·응력 |

Workbench의 Experiment 탭에서 예제를 열고 Vars 준비 후 **실행**을 누릅니다.
연결된 CAE Launcher가 필요합니다. CLI에서 실행하려면
[Experiment 작성·실행 안내](../../authoring/experiment.md)의 \`catalog show examples\`,
\`experiment init\`, \`experiment check\`, \`experiment test\` 순서를 따르세요.
\`check\`는 입력을 검증하고, \`test\`가 검증된 입력으로 로컬 Solver를 실행합니다.
실행 범위와 source를 그대로 유지하며 표시 편의를 위해 시간 간격이나 입자 수를
자동으로 줄이지 않습니다.

## 설정은 어디에 두나요

- **Geometry**는 입자를 생성할 실제 체적과 고정 벽을 제공합니다. 생성 간격은
  입자 배치를, DEM 반경은 접촉에 사용할 구의 실제 크기를 결정합니다.
  잘린 체적이나 구멍을 bounding box 전체로 채우지 않습니다.
- **Material**은 밀도·점도·탄성 같은 물리 모델과 계수를 소유합니다.
  Material 이름을 바꾸어도 다른 물성이 자동 적용되지 않습니다.
- **MaterialInteraction**은 Material 쌍에 적용할 DEM 접촉·마찰 모델을 선택합니다.
  입자와 고정 벽은 같은 body target에 포함됩니다. 명시하지 않은 선택적 그룹에는
  Solver 계약의 기본 모델을 사용하고, 잘못되거나 모호한 명시적 선택은 오류입니다.
  같은 Material 쌍의 입자–입자와 입자–벽 접촉은 같은 선택을 사용합니다.
- **Task 설정**은 시간 적분, 초기 속도·중력과 해석 영역을 소유합니다.
  SPH의 평활 길이·수치 음속, MPM의 계산 격자도 여기에 속합니다.
- **Output Box와 gridShape**는 관측 위치와 기록 해상도를 결정합니다.
  MPM 계산 격자와 Output Box는 별개입니다. 관측 Box나 출력 표본 간격을 바꾸어도
  물리적 초기 조건이나 적분 시간 간격은 바뀌지 않습니다.

한 번의 실행 구간이 끝나면 입자 상태와 필요한 접촉·재료 이력을 보존합니다.
다음 \`sim.run\`은 그 Task의 상태에서 계속합니다. 입자 ID는 배열의 현재 행 번호가
아니며, 수치 Solver가 배열을 재정렬해도 ID·Material·물리량의 대응을 유지합니다.

## 입자와 수치 Output 보기

Viewer의 결과 선택에서 Task의 자동 **particles** 시각화를 엽니다.
시간 슬라이더, 이전·다음 프레임과 재생 버튼으로 저장된 시점을 확인합니다.
프레임 사이에 새로운 물리 상태를 계산하거나 입자 위치를 보간하지 않습니다.
카메라는 재생 중 유지합니다.

**물리량**에서 Material 또는 저장된 속성을 선택합니다. 벡터·Tensor는
**성분** 또는 **Norm**으로 표시하고, 물리량 종류와 단위를 함께 확인합니다.
Norm은 기록된 성분의 유클리드 크기이며 응력의 von Mises 값이 아닙니다.
색상 범위는 현재 프레임의 값에 맞춥니다. **ID**를 선택하면 그 입자의
Material, 위치와 모든 저장 물리량을 아래에서 읽을 수 있습니다.

DEM은 저장된 물리적 반경으로 구를 그립니다. SPH·MPM의 **점 크기**는 화면 표시만
바꾸며 입자 질량·체적·계산 간격을 바꾸지 않습니다. Geometry는 필요할 때 켜고,
저장 결과와 source·Vars가 일치할 때만 겹칩니다.

수치 분석에는 별도로 기록한 Box Grid를 선택합니다. 밀도는 cell 질량을 전체
cell 체적으로, 운동량 밀도는 cell 운동량을 전체 cell 체적으로 나눈 값입니다.
속도는 운동량을 질량으로 나누며 빈 cell은 0입니다. Histogram·Heatmap과
Calculation에서는 이 수치 Output을 사용합니다. 자동 입자 시각화와 native
particle export는 \`sim.record\`나 Calculation 입력이 아닙니다.
자세한 구분은 [RecordedData와 Viewer](program-domain-recording.md)를 참고하세요.

저장된 Measurement와 CLI 로컬 결과는 실행 당시의 계약·단위·ID·Material 및 시간
표본으로 다시 엽니다. 다른 Solver가 native particle export를 받을 수 있는지는
그 Solver의 입력 계약에 따릅니다. 서로 다른 Solver의 continuation state를
그대로 이어 쓰지는 않습니다.

## 현재 지원 범위

- DEM은 구형 입자와 움직이지 않는 벽의 접촉을 계산합니다. 반발계수를 입력해
  감쇠계수를 추정하지 않으며, 접촉 모델이 소유한 강성·감쇠 계수를 사용합니다.
- SPH는 단일 유체 Material, 일정한 입자 간격과 평활 길이를 사용합니다.
  영역은 축에 정렬된 Box이고, 주기가 아닌 방향의 양쪽 면에는 대응하는 고정 벽이
  필요합니다. 주기 면에 벽을 동시에 둘 수 없습니다. 열린 자유표면과 임의 형상의
  내부 장애물 해석은 현재 범위에 포함하지 않습니다. 주기 방향의 길이는 kernel
  support 반경보다 커야 합니다. 압력은 기준 밀도에 대한 gauge pressure이므로
  음수 값이 나올 수 있습니다.
- MPM은 단일 고체 Material과 정육면체 cell의 계산 격자를 사용합니다.
  고정 벽은 해당 격자의 고정 node로 반영합니다. 입자가 계산 격자에서 필요한
  보간 영역을 벗어나면 오류가 발생하므로 변형할 여유를 두세요.
  압축 예제는 초기 속도 구배로 운동을 시작하며, 지정한 속도로 계속 움직이는
  압반 경계조건은 지원하지 않습니다.
- 세 Solver 모두 생성 이후 입자 수가 고정됩니다. 지원하지 않는 설정은
  다른 물리 모델로 바꾸어 계산하지 않고 오류로 알려 줍니다.
`,qe=[{id:"workbench-quickstart",section:"workbench",anchor:"workbench-quickstart",title:"CAE Workbench 빠른 시작",summary:"Experiment candidate를 준비하고 Measurement로 고정한 뒤 실행하는 전체 흐름입니다.",keywords:["Quickstart","시작","Candidate","Measurement","Prepared","Recorded","Launcher","Ready"],sourcePath:"docs/manual/workbench/workbench-quickstart.md",content:i(me)},{id:"workbench-authoring-cycle",section:"workbench",anchor:"workbench-authoring-cycle",title:"편집, Candidate 생성과 실행 결과의 관계",summary:"source 수정과 candidate 생성이 prepared·recorded Measurement에 미치는 영향을 설명합니다.",keywords:["Dirty","Checking","Compiling","Evaluating","Validating Models","Candidate","Prepared","Recorded"],sourcePath:"docs/manual/workbench/workbench-authoring-cycle.md",content:i(ue)},{id:"workbench-calculation",section:"workbench",anchor:"workbench-calculation",title:"Calculation으로 RecordedData 후처리",summary:"선택한 Measurement의 RecordedData를 JavaScript와 Math.js로 계산하고 scalar, line, heatmap으로 확인합니다.",keywords:["Calculation","Vars","Candidate","RecordedData","Math.js","mathjs","Output","scalar","line","heatmap"],sourcePath:"docs/manual/workbench/workbench-calculation.md",content:i(pe)},{id:"workbench-prediction",section:"workbench",anchor:"workbench-prediction",title:"Prediction으로 Vars와 CalculationData 상호 예측",summary:"저장된 Measurement의 k-Nearest Neighbor 모델로 Forward·Inverse 예측을 자동 전환하고 Save & Run으로 검증합니다.",keywords:["Prediction","Forward","Inverse","kNN","k-Nearest Neighbor","Vars","RecordedData","CalculationData","Save & Run","Validation"],sourcePath:"docs/manual/workbench/workbench-prediction.md",content:i(he)},{id:"workbench-admin-demo-curation",section:"workbench",anchor:"workbench-admin-demo-curation",title:"Admin: 공개 Demo 큐레이션",summary:"관리자가 공개 Prediction Demo의 순서와 대표 항목을 관리하고 공개 범위를 확인합니다.",keywords:["Admin","Demo","Curation","Model Catalog","Users","공개","대표 Demo"],sourcePath:"docs/manual/workbench/workbench-admin-demo-curation.md",content:i(ge)},{id:"workbench-analysis",section:"workbench",anchor:"workbench-analysis",title:"Analysis: Explore, Mining과 Data",summary:"CalculationData가 저장된 Measurement를 탐색하고 고급 분석과 CSV 내보내기를 사용하는 방법입니다.",keywords:["Analysis","Explore","Pearson","Spearman","Mining","PCA","CSV"],sourcePath:"docs/manual/workbench/workbench-analysis.md",content:i(xe)},{id:"workbench-viewer-selection",section:"workbench",anchor:"workbench-viewer-selection",title:"3D Viewer에서 Geometry와 Surface ID 확인",summary:"Viewer 클릭과 Source의 ID 선택을 연결해 실제 Scene 전역 경로를 확인합니다.",keywords:["Viewer","Geometry ID","Surface ID","selection","전역 경로","surface"],sourcePath:"docs/manual/workbench/workbench-viewer-selection.md",content:i(ye)},{id:"program-overview",section:"program",anchor:"experiment-program-overview",aliases:["experiment-program-mental-model","experiment-physical-model"],title:"Experiment Program의 파일과 책임",summary:"공통 계약, named task와 Python orchestration을 독립 파일로 나눕니다.",keywords:["Experiment Program","experiment.tsx","geometry.tsx","material.tsx","tasks","simulate.py","orchestration"],sourcePath:"docs/manual/program/program-overview.md",content:i(fe)},{id:"program-definition",section:"program",anchor:"experiment-program-definition",aliases:["experiment-vars-geometry"],title:"experiment.tsx: 변수와 RecordedData 계약",summary:"실험 공통 변수와 Measurement에 남길 최종 데이터만 선언합니다.",keywords:["experiment()","varsSchema","recordedData","DataSchema","Measurement"],sourcePath:"docs/manual/program/program-definition.md",content:i(be)},{id:"program-materials",section:"program",anchor:"experiment-program-materials",aliases:["experiment-materials","experiment-program-material-roles"],title:"Material 역할과 Model Parameter",summary:"모델 인스턴스와 명시적인 계수를 선언하고 Geometry 역할로 연결합니다.",keywords:["Material","material.tsx","role map","body","Mat","canonical key","dtype","unit","modelGroups","tire","wheel"],sourcePath:"docs/manual/program/program-materials.md",content:i(ve)},{id:"program-task",section:"program",anchor:"experiment-program-task",aliases:["experiment-program-minimal-pair","experiment-program-kernel-limits","experiment-program-methods"],title:"tasks/*.tsx: solver task 선언",summary:"manifest의 parameter, method, target과 output 계약을 defineTask로 작성합니다.",keywords:["defineTask","kernel","config","parameters","initializations","boundaryConditions","outputs"],sourcePath:"docs/manual/program/program-task.md",content:i(Ce)},{id:"program-ray-tracing",section:"program",anchor:"experiment-program-ray-tracing",aliases:["non-sequential-ray-tracing","ray-tracing-thin-film"],title:"Non-sequential Ray Tracing",summary:"광선의 비순차 추적, 적응형 박막 처리와 detector 결과를 구성하는 방법입니다.",keywords:["ray-tracing@0.4.0","non-sequential","point source","area source","directional source","Lambertian source","Stokes","ABg","Henyey-Greenstein","detector","thin film","TMM","50 um","frequency","ray paths"],sourcePath:"docs/manual/program/program-ray-tracing.md",content:i(we)},{id:"program-particles",section:"program",anchor:"experiment-program-particles",title:"입자 해석: DEM, SPH, MPM",summary:"Geometry에서 입자를 생성하고 시간·물리량·Material을 확인하는 실행과 Viewer 안내입니다.",keywords:["particles","DEM","SPH","MPM","입자","접촉","유체","압축","MaterialInteraction"],sourcePath:"docs/manual/program/program-particles.md",content:i(Le)},{id:"program-simulate",section:"program",anchor:"experiment-program-simulate",title:"simulate.py: 실행, 전달, 기록",summary:"sim.run, sim.record, sim.release로 Task 실행과 state·artifact의 수명을 제어합니다.",keywords:["simulate","sim.run","sim.record","sim.release","artifact","state","inputs"],sourcePath:"docs/manual/program/program-simulate.md",content:i(ke)},{id:"program-runtime-rules",section:"program",anchor:"experiment-program-runtime-rules",aliases:["experiment-program-troubleshooting"],title:"실행 중 state와 artifact 규칙",summary:"state와 artifact의 해제, checkpoint, rollback과 RecordedData ACK 규칙입니다.",keywords:["state","artifact","rollback","provisional","ACK","fatal","release"],sourcePath:"docs/manual/program/program-runtime-rules.md",content:i(Me)},{id:"program-domain-recording",section:"program",anchor:"experiment-program-domain-recording",title:"Catalog 기반 RecordedData와 Viewer",summary:"Field artifact의 좌표, connectivity와 물리적 의미를 명시적인 기록 group에 보존합니다.",keywords:["RecordedData","FieldValue","domain","mesh","connectivity","quantity","valueUnit"],sourcePath:"docs/manual/program/program-domain-recording.md",content:i(Se)},{id:"program-verified-examples",section:"program",anchor:"experiment-program-examples",aliases:["experiment-verified-example"],title:"검증된 Examples",summary:"실제 UI-CAE fixture로 검증되는 단계별 Experiment Program입니다.",keywords:["program examples","DC","current density","notched","electro thermal","multiphysics"],sourcePath:"docs/manual/program/program-verified-examples.md",content:i(De)},{id:"program-multiphysics-example",section:"program",anchor:"experiment-program-multiphysics",title:"Multiphysics 예제: Electro-Thermal Notched Bar",summary:"DC의 Joule heating artifact를 정상상태 Heat task로 전달하는 orchestration입니다.",keywords:["multiphysics","Joule heating","heatSource","electric","thermal"],collapsed:!0,sourcePath:"docs/manual/program/program-multiphysics-example.md",content:i(Ee)},{id:"reference-source-import",section:"reference",anchor:"cad-reference-overview",aliases:["cad-reference-source-import"],title:"공개 Source와 import 경계",summary:"TSX source에서 사용할 수 있는 @caemble/core 공개 경계를 설명합니다.",keywords:["CAD Reference","@caemble/core","import","default export","compile","evaluate"],sourcePath:"docs/manual/reference/reference-source-import.md",content:i(Pe)},{id:"reference-geometry-skeleton",section:"reference",anchor:"cad-reference-geometry-skeleton",title:"Geometry 저작 골격과 좌표계",summary:"CAD API v1 source의 기본 구조, 필수 prop 기본값, PascalCase primitive와 제어문 활용을 함께 보여줍니다.",keywords:["CAD API v1","geometry.tsx","Geometry","PascalCase","loop","control flow","right-handed","lengthUnit","좌표계"],sourcePath:"docs/manual/reference/reference-geometry-skeleton.md",content:i(Re)},{id:"reference-geometry-transforms",section:"reference",anchor:"cad-reference-geometry-transforms",aliases:["cad-reference-v7-migration"],title:"Transform: direct props와 operation wrapper",summary:"direct Euler prop과 계층적인 translate·rotate·scale wrapper를 구분해 사용합니다.",keywords:["position","rotation","scale","translate","axis angle","radians","Euler","transform order","pos","rotate"],sourcePath:"docs/manual/reference/reference-geometry-transforms.md",content:i(Ae)},{id:"reference-geometry-identity",section:"reference",anchor:"cad-reference-geometry-identity",title:"ID, group과 surface identity",summary:"안정적인 solver target을 위해 component, primitive와 operation의 소유권을 구분합니다.",keywords:["id","identity","geometryGroup","surfaceGroup","numeric surface","surface-N","operation","Fragment"],sourcePath:"docs/manual/reference/reference-geometry-identity.md",content:i(je)},{id:"reference-geometry-elements",section:"reference",anchor:"cad-reference-geometry-elements",title:"Primitive 선택과 operation 규칙",summary:"가장 단순한 primitive에서 시작하고 child cardinality와 순서 계약을 지킵니다.",keywords:["box","cylinder","sphere","fiber","array","shell","union","subtract","intersect","children"],sourcePath:"docs/manual/reference/reference-geometry-elements.md",content:i(Te)},{id:"reference-core-api",section:"reference",anchor:"cad-reference-core-api",aliases:["cad-reference-primitives","cad-reference-operations","cad-reference-vars-geometry"],title:"@caemble/core 핵심 API",summary:"CAE 저작에서 가장 자주 사용하는 공개 symbol의 책임을 정리합니다.",keywords:["experiment","defineTask","Material","Mat","Geometry","Vec3","DataSchema"],sourcePath:"docs/manual/reference/reference-core-api.md",content:i(Ie)},{id:"reference-data-schema",section:"reference",anchor:"cad-reference-data-schema",aliases:["cad-reference-material"],title:"DataSchema, QuantityKind와 UCUM 단위",summary:"scalar·tensor shape와 물리 의미, 변환 가능한 단위를 함께 선언합니다.",keywords:["DataSchema","dtype","axes","shape","QuantityKind","UCUM","unit","tensorOrder"],sourcePath:"docs/manual/reference/reference-data-schema.md",content:i(Ne)},{id:"reference-targets-results",section:"reference",anchor:"cad-reference-targets-results",aliases:["cad-reference-task-recorded-data","cad-reference-kernels","cad-reference-results"],title:"Target, run 상태와 결과 경계",summary:"Experiment/Task scene target과 RecordedData가 worker 경계를 통과하는 방식을 설명합니다.",keywords:["target","experiment.geometry","task.geometry","run status","RecordedData","trace","provenance"],sourcePath:"docs/manual/reference/reference-targets-results.md",content:i(Ge)},{id:"troubleshooting-ready",section:"troubleshooting",anchor:"troubleshooting-ready",title:"문서가 Ready가 되지 않을 때",summary:"compile/evaluate 단계와 source 위치를 기준으로 오류를 좁힙니다.",keywords:["troubleshooting","Ready","compile","evaluate","diagnostic","source error"],sourcePath:"docs/manual/troubleshooting/troubleshooting-ready.md",content:i(Ve)},{id:"troubleshooting-target-manifest",section:"troubleshooting",anchor:"troubleshooting-target-manifest",title:"target 또는 solver manifest 오류",summary:"solver identity, method occurrence와 group target을 현재 manifest에 맞춥니다.",keywords:["target","manifest","methodId","occurrence","group","solver","invalid_manifest"],sourcePath:"docs/manual/troubleshooting/troubleshooting-target-manifest.md",content:i(Be)},{id:"troubleshooting-units-materials",section:"troubleshooting",anchor:"troubleshooting-units-materials",title:"unit, QuantityKind 또는 Material 오류",summary:"canonical key와 변환 가능한 UCUM 단위, tensor shape를 함께 점검합니다.",keywords:["invalid_unit","UCUM","QuantityKind","Material","tensor","conductivity"],sourcePath:"docs/manual/troubleshooting/troubleshooting-units-materials.md",content:i(_e)},{id:"troubleshooting-runtime-results",section:"troubleshooting",anchor:"troubleshooting-runtime-results",title:"Measurement 실행 또는 결과 오류",summary:"선택 입력, artifact 수명과 RecordedData 계약을 순서대로 점검합니다.",keywords:["Measurement","artifact","recordedData","stale","failed","cancelled","Launcher"],sourcePath:"docs/manual/troubleshooting/troubleshooting-runtime-results.md",content:i($e)}],y=[...de.map(r=>({id:`authoring-${r.id}`,section:"reference",anchor:`authoring-${r.id}`,title:r.title,summary:r.summary,keywords:["CLI","external agent","authoring",r.id,...r.referenceIds],sourcePath:`docs/authoring/${r.id}.md`,content:r.content})),...qe],ze=["home","manual","geometry","materials","quantity-kinds","solvers","examples"];function s(r,t,o){const u=new URLSearchParams({help:r});return t&&u.set("item",t),o&&u.set("anchor",o),`/doc?${u}`}function Oe(r){const t=new URLSearchParams(r),o=t.get("help");return o===null?null:{kind:ze.includes(o)?o:"home",item:t.get("item"),anchor:t.get("anchor")}}const Fe=y.map(r=>({...r,section:r.section,keywords:r.keywords,href:s("manual",r.id)})),Ue=Object.freeze([...ee.map(r=>Object.freeze({id:`geometry:${r.tag}`,section:"geometry",title:r.authoringName,summary:r.summary,item:r.tag,href:s("geometry",r.tag),keywords:Object.freeze([r.authoringName,r.tag,r.category,r.syntax,...r.keywords,...r.properties.flatMap(({name:t,type:o})=>[t,o])]),content:[`Authoring name: ${r.authoringName}`,`Registry tag: ${r.tag}`,`Category: ${r.category}`,`Syntax: ${r.syntax}`,`Summary: ${r.summary}`,`Origin: ${r.origin}`,`Children (${r.children.count}): ${r.children.description}`,"","Properties:",...r.properties.map(t=>`- ${t.name}: ${t.type}; ${t.required?"required":"optional"}${"default"in t&&t.default!==void 0?`; default ${t.default}`:""}. ${t.description}`),"","Surfaces:",...r.surfaces.length?r.surfaces.map(t=>`- \`surface/${t.index}\` — ${t.label}: ${t.description}`):["- No fixed surface contract."],"","검증된 부분 TSX 예시 — 완성 파일이 아닌 단일 element 식:","```tsx",r.example,"```"].join(`
`)}))]);function Ke(r){return Object.freeze(r.map(t=>{const o=t.kind==="quantityKind"?"quantity-kinds":t.kind==="experiment"?"examples":t.kind==="solver"?"solvers":"materials",u=t.key;return Object.freeze({id:`${t.kind}:${t.key}`,section:o,title:t.title,summary:t.subtitle,item:u,href:s(o,u),keywords:Object.freeze([t.kind,t.key,t.title,t.subtitle]),content:t.subtitle})}))}function L(){return[...Fe,...Ue]}function He(r,t=L()){const o=r.normalize("NFKC").trim().toLocaleLowerCase();if(!o)return[];const u=o.split(/\s+/).filter(Boolean);return t.flatMap(d=>{const h=d.title.normalize("NFKC").toLocaleLowerCase(),v=d.keywords.map(c=>c.normalize("NFKC").toLocaleLowerCase()),P=v.join(" "),g=`${h} ${d.summary} ${P} ${d.content}`.normalize("NFKC").toLocaleLowerCase(),f=u.filter(c=>g.includes(c)).length;if(!g.includes(o)&&f===0)return[];const w=h===o?0:h.startsWith(o)?1:v.some(c=>c===o)?2:v.some(c=>c.startsWith(o))?3:g.includes(o)?4:5;return[{chunk:d,matchedTerms:f,rank:w}]}).sort((d,h)=>d.rank-h.rank||h.matchedTerms-d.matchedTerms||d.chunk.title.localeCompare(h.chunk.title,"ko")||d.chunk.id.localeCompare(h.chunk.id)).map(({chunk:d})=>d)}function We(r,t=250){const[o,u]=m.useState(r);return m.useEffect(()=>{const d=window.setTimeout(()=>u(r),t);return()=>window.clearTimeout(d)},[r,t]),o}const Qe=m.lazy(()=>E(()=>import("./CadCatalogPage-CeVuXqnJ.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21])).then(r=>({default:r.GeometryCatalog}))),Je=m.lazy(()=>E(()=>import("./MaterialCatalogPage-EKUGRM7E.js"),__vite__mapDeps([22,1,2,23,6,7,8,3,4,5,9,10,11,24,25,26,18,16,27,17,19,28,29,30])).then(r=>({default:r.MaterialCatalog}))),Xe=m.lazy(()=>E(()=>import("./QuantityKindCatalogPage-032ZKQqM.js"),__vite__mapDeps([31,1,2,23,6,7,8,3,4,5,9,10,11,12,13,14,15,16,24,25,26,18,27,17,19,28,29,30])).then(r=>({default:r.QuantityCatalog}))),Ye=m.lazy(()=>E(()=>import("./SolverCatalogPage-CK3uj1mx.js"),__vite__mapDeps([32,1,2,23,6,7,8,3,4,5,9,10,11,33,34,13,24,25,26,18,16,27,17,19,28,29,30])).then(r=>({default:r.PhysicsCatalog}))),Ze=m.lazy(()=>E(()=>import("./SolverCatalogPage-CK3uj1mx.js"),__vite__mapDeps([32,1,2,23,6,7,8,3,4,5,9,10,11,33,34,13,24,25,26,18,16,27,17,19,28,29,30])).then(r=>({default:r.ExampleExperimentCatalog}))),R=[{title:"시작하기",summary:"첫 Experiment를 준비하고 실행 흐름을 익힙니다.",ids:["workbench-quickstart","workbench-authoring-cycle","workbench-viewer-selection"]},{title:"Experiment 작성",summary:"형상, 변수, 재료와 Solver 작업을 구성합니다.",ids:["program-overview","program-definition","program-materials","program-task","program-ray-tracing","program-runtime-rules"]},{title:"실행·결과 확인",summary:"Measurement를 실행하고 기록된 결과를 확인합니다.",ids:["program-simulate","program-domain-recording","program-verified-examples","program-multiphysics-example"]},{title:"Calculation·Prediction",summary:"결과를 계산하고 다음 변수 조건을 탐색합니다.",ids:["workbench-calculation","workbench-prediction","workbench-analysis"]},{title:"문제 해결",summary:"증상에서 시작해 확인할 위치와 해결 방법을 찾습니다.",ids:y.filter(r=>r.section==="troubleshooting").map(r=>r.id)}],A=[{kind:"geometry",label:"Geometry"},{kind:"materials",label:"Material Model"},{kind:"quantity-kinds",label:"QuantityKind"},{kind:"solvers",label:"Solver"},{kind:"examples",label:"Examples"}],ea=L();function aa({kind:r,item:t,anchor:o,onNavigate:u}){const[d,h]=m.useState(""),[v,P]=m.useState(!1),g=We(d.trim()),f=F(X(g,100,!!g)),w=m.useMemo(()=>He(g,[...ea,...Ke(f.data??[])]),[g,f.data]),c=r==="manual"?y.find(e=>e.id===t):void 0,T=m.useRef(null),M=m.useMemo(()=>{let e=!1;const n=new Map;return(c?.content??"").split(`
`).flatMap((l,p)=>{/^\s*(```|~~~)/.test(l)&&(e=!e);const b=!e&&/^(#{2,4})\s+(.+)/.exec(l);if(!b)return[];const S=b[2].replace(/[`*_]/g,""),D=S.toLowerCase().replace(/[^\p{L}\p{N}\s_-]/gu,"").replace(/\s/g,"-"),G=n.get(D)??0;return n.set(D,G+1),[{id:`${D}${G?`-${G}`:""}`,title:S,level:b[1].length,line:p+1}]})},[c?.content]),k=R.find(e=>e.ids.includes(t??"")),I=c?k?k.ids:y.filter(e=>e.section===c.section).map(e=>e.id):[],N=I[I.indexOf(t??"")+1],x=e=>{h(""),P(!1),u(e)};m.useEffect(()=>{if(T.current?.scrollTo?.(0,0),!o)return;[...T.current?.querySelectorAll("[id]")??[]].find(n=>n.id===o)?.scrollIntoView?.({block:"start"})},[r,t,o]);const z=r==="home"?"Documentation":r==="manual"?c?.title??"매뉴얼":A.find(e=>e.kind===r)?.label;return a.jsxs("section",{"aria-label":"Documentation",className:"flex h-full min-h-0 flex-col bg-background text-foreground",onClickCapture:e=>{if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;const n=e.target.closest("a[href]"),l=n?.getAttribute("href");if(!l||n?.getAttribute("target")==="_blank")return;let p;if(l.startsWith("/doc?help="))p=l;else if(l.startsWith("#")&&c)p=s("manual",c.id,new URLSearchParams(`anchor=${l.slice(1).replace(/\+/g,"%2B")}`).get("anchor"));else if(c&&!/^(?:[a-z]+:|\/)/i.test(l)){const b=new URL(l,`https://documentation.invalid/${c.sourcePath}`),S=y.find(D=>`/${D.sourcePath}`===decodeURIComponent(b.pathname));S&&(p=s("manual",S.id,decodeURIComponent(b.hash.slice(1))))}p&&(e.preventDefault(),x(p))},children:[a.jsxs("header",{className:"flex shrink-0 items-center gap-3 border-b px-4 py-3",children:[a.jsx(C,{"aria-label":"Documentation 메뉴",className:"lg:hidden",size:"icon",variant:"ghost",onClick:()=>P(!v),"aria-expanded":v,children:a.jsx(ie,{})}),a.jsxs("button",{className:"flex items-center gap-2 font-semibold",onClick:()=>x(s("home")),children:[a.jsx(U,{className:"size-5 text-primary"}),a.jsx("span",{className:"hidden sm:inline",children:"Documentation"})]}),a.jsxs("label",{className:"relative mx-auto w-full max-w-2xl",children:[a.jsx(ae,{className:"pointer-events-none absolute top-2.5 left-3 size-4 text-muted-foreground"}),a.jsx(W,{"aria-label":"Documentation 전체 검색",type:"search",placeholder:"무엇을 하고 싶으신가요? 문서, 문법, 단위, Solver 검색",className:"pl-9",value:d,onChange:e=>h(e.target.value)})]})]}),a.jsxs("div",{className:"relative flex min-h-0 flex-1",children:[a.jsx("aside",{className:`${v?"absolute inset-y-0 left-0 z-20 shadow-xl":"hidden"} w-64 shrink-0 overflow-auto border-r bg-background p-3 lg:static lg:block lg:shadow-none`,children:a.jsxs("nav",{"aria-label":"Documentation 탐색",className:"space-y-4",children:[a.jsx("a",{href:s("home"),"aria-current":r==="home"?"page":void 0,className:"block rounded-md px-3 py-2 font-medium hover:bg-muted",children:"Documentation 홈"}),R.map(e=>a.jsxs("details",{open:k?.title===e.title,children:[a.jsx("summary",{className:"cursor-pointer px-2 py-2 text-sm font-semibold",children:e.title}),a.jsx("div",{className:"mt-1 space-y-1",children:e.ids.map(n=>y.find(l=>l.id===n)).filter(n=>n!==void 0).map(n=>a.jsx("a",{href:s("manual",n.id),"aria-current":t===n.id?"page":void 0,className:`block rounded-md px-3 py-2 text-xs leading-5 hover:bg-muted ${t===n.id?"bg-primary/10 text-primary":"text-muted-foreground"}`,children:n.title},n.id))})]},e.title)),a.jsxs("details",{open:r==="manual"&&!k,children:[a.jsx("summary",{className:"cursor-pointer px-2 py-2 text-sm font-semibold",children:"API Reference·추가 가이드"}),y.filter(e=>!R.some(n=>n.ids.includes(e.id))).map(e=>a.jsx("a",{href:s("manual",e.id),"aria-current":t===e.id?"page":void 0,className:`block rounded-md px-3 py-2 text-xs leading-5 hover:bg-muted ${t===e.id?"bg-primary/10 text-primary":"text-muted-foreground"}`,children:e.title},e.id))]}),a.jsxs("div",{className:"border-t pt-3",children:[a.jsx("p",{className:"px-2 text-xs font-semibold text-muted-foreground",children:"카탈로그·예제"}),A.map(e=>a.jsx("a",{href:s(e.kind),"aria-current":r===e.kind?"page":void 0,className:`mt-1 block rounded-md px-3 py-2 text-sm hover:bg-muted ${r===e.kind?"bg-primary/10 text-primary":""}`,children:e.label},e.kind))]})]})}),a.jsxs("div",{ref:T,className:"min-w-0 flex-1 overflow-auto","aria-label":"Documentation 본문",children:[a.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2 border-b px-5 py-3 text-xs text-muted-foreground",children:[a.jsx("span",{children:r==="home"?"Documentation 홈":`Documentation / ${k?.title?`${k.title} / `:""}${z}`}),a.jsx(_,{label:"링크 복사",text:new URL(s(r,t,o),window.location.origin).href})]}),d.trim()?a.jsxs("div",{className:"mx-auto max-w-5xl space-y-6 p-5 sm:p-8","aria-live":"polite",children:[a.jsx("h1",{className:"text-2xl font-semibold",children:"검색 결과"}),d.trim()!==g||f.isFetching?a.jsx("p",{role:"status",className:"text-sm text-muted-foreground",children:"검색 중…"}):null,f.isError?a.jsxs("div",{className:"rounded-lg border p-4 text-sm",children:["카탈로그 검색을 불러오지 못했습니다. 매뉴얼과 Geometry 결과는 계속 이용할 수 있습니다."," ",a.jsx(C,{variant:"outline",size:"sm",onClick:()=>{f.refetch()},children:"다시 시도"})]}):null,!w.length&&d.trim()===g?a.jsx("p",{children:"일치하는 문서가 없습니다. 다른 이름이나 단위로 검색해 보세요."}):null,[...new Set(w.map(e=>e.section))].map(e=>a.jsxs("section",{className:"space-y-2",children:[a.jsxs("h2",{className:"font-semibold",children:[A.find(n=>n.kind===e)?.label??"매뉴얼"," · ",e]}),w.filter(n=>n.section===e).slice(0,20).map(n=>{const l=n.content.replace(/[`#*]/g,""),p=l.toLocaleLowerCase().indexOf(g.toLocaleLowerCase()),b=p>=0?l.slice(Math.max(0,p-45),p+160):n.summary;return a.jsxs("a",{href:n.href,className:"block rounded-lg border p-4 hover:bg-muted",children:[a.jsx("span",{className:"font-medium text-primary",children:n.title}),a.jsx("span",{className:"mt-1 line-clamp-3 block text-sm text-muted-foreground",children:b})]},n.id)}),w.filter(n=>n.section===e).length>20?a.jsx("p",{className:"text-xs text-muted-foreground",children:"상위 20개를 표시합니다. 검색어를 구체적으로 입력해 주세요."}):null]},e))]}):r==="home"?a.jsxs("div",{className:"mx-auto max-w-5xl p-5 sm:p-8",children:[a.jsx("p",{className:"text-sm font-medium text-primary",children:"CAE Workbench 안내"}),a.jsx("h1",{className:"mt-2 text-3xl font-semibold tracking-tight",children:"하고 싶은 작업에서 시작하세요"}),a.jsx("p",{className:"mt-3 text-muted-foreground",children:"처음 실행부터 결과 해석까지, 필요한 단계와 정확한 문법을 한곳에서 찾으세요."}),a.jsx("div",{className:"mt-8 grid gap-4 md:grid-cols-2",children:R.map((e,n)=>a.jsxs("a",{href:s("manual",e.ids[0]),className:"group rounded-xl border p-5 transition-colors hover:bg-muted",children:[a.jsxs("span",{className:"text-xs font-medium text-primary",children:["0",n+1]}),a.jsxs("h2",{className:"mt-3 flex items-center justify-between text-lg font-semibold",children:[e.title,a.jsx(B,{className:"size-4"})]}),a.jsx("p",{className:"mt-2 text-sm leading-6 text-muted-foreground",children:e.summary})]},e.title))}),a.jsx("h2",{className:"mt-9 font-semibold",children:"문법·규격·예제 바로 찾기"}),a.jsxs("div",{className:"mt-3 flex flex-wrap gap-2",children:[A.map(e=>a.jsx(C,{asChild:!0,variant:"outline",children:a.jsx("a",{href:s(e.kind),children:e.label})},e.kind)),a.jsx(C,{asChild:!0,variant:"outline",children:a.jsx("a",{href:s("manual","reference-core-api"),children:"API Reference"})})]})]}):r==="manual"?c?a.jsxs("article",{className:"mx-auto max-w-5xl p-5 sm:p-8",children:[a.jsx("h1",{className:"text-2xl font-semibold tracking-tight sm:text-3xl",children:c.title}),a.jsx("p",{className:"mt-3 leading-7 text-muted-foreground",children:c.summary}),M.length?a.jsxs("nav",{"aria-label":"문서 목차",className:"my-6 rounded-lg border bg-muted/30 p-4",children:[a.jsx("p",{className:"mb-2 text-sm font-semibold",children:"이 문서에서"}),M.map(e=>a.jsx("a",{href:s("manual",c.id,e.id),className:`block py-1 text-sm text-primary hover:underline ${e.level>2?"pl-4":""}`,children:e.title},e.id))]}):null,a.jsx("div",{className:"help-markdown mt-6 min-w-0 text-sm leading-7 [&_a]:text-primary [&_a]:underline [&_code]:rounded [&_code]:bg-muted [&_code]:px-1 [&_h2]:mt-8 [&_h2]:mb-3 [&_h2]:text-xl [&_h2]:font-semibold [&_h3]:mt-6 [&_h3]:font-semibold [&_li]:my-1 [&_ol]:list-decimal [&_ol]:pl-6 [&_p]:my-4 [&_pre]:max-h-[560px] [&_pre]:overflow-auto [&_pre]:rounded-lg [&_pre]:bg-muted [&_pre]:p-4 [&_pre_code]:bg-transparent [&_pre_code]:p-0 [&_td]:border [&_td]:p-3 [&_th]:border [&_th]:bg-muted [&_th]:p-3 [&_ul]:list-disc [&_ul]:pl-6",children:a.jsx(re,{remarkPlugins:[te],components:{h2:({node:e,children:n})=>m.createElement("h2",{id:M.find(l=>l.line===e?.position?.start.line)?.id,className:"scroll-mt-4"},n),h3:({node:e,children:n})=>m.createElement("h3",{id:M.find(l=>l.line===e?.position?.start.line)?.id,className:"scroll-mt-4"},n),h4:({node:e,children:n})=>m.createElement("h4",{id:M.find(l=>l.line===e?.position?.start.line)?.id,className:"scroll-mt-4"},n),table:({children:e})=>a.jsx("div",{className:"my-4 overflow-x-auto",children:a.jsx("table",{className:"w-full border-collapse",children:e})}),pre:({node:e,children:n})=>a.jsxs("div",{className:"my-4 min-w-0",children:[a.jsx("div",{className:"mb-1 flex justify-end",children:a.jsx(_,{text:e?.children.flatMap(l=>l.type==="element"?l.children.flatMap(p=>p.type==="text"?p.value:[]):[]).join("")??""})}),a.jsx("pre",{children:n})]})},children:c.content})}),a.jsxs("footer",{className:"mt-10 border-t pt-5",children:[a.jsx("h2",{className:"font-semibold",children:"관련 문서"}),a.jsx("div",{className:"mt-3 flex flex-wrap gap-2",children:I.filter(e=>e!==c.id).map(e=>y.find(n=>n.id===e)).filter(e=>e!==void 0).map(e=>a.jsx("a",{href:s("manual",e.id),className:"rounded-md border px-3 py-2 text-sm hover:bg-muted",children:e.title},e.id))}),N?a.jsxs("a",{className:"mt-5 flex items-center gap-2 font-medium text-primary",href:s("manual",N),children:["다음 단계: ",y.find(e=>e.id===N)?.title,a.jsx(B,{className:"size-4"})]}):null]})]}):a.jsxs("div",{className:"p-8",children:[a.jsx("h1",{className:"text-xl font-semibold",children:"문서를 찾을 수 없습니다"}),a.jsx("p",{className:"my-3 text-muted-foreground",children:"문서가 이동했거나 주소가 올바르지 않습니다."}),a.jsxs(C,{onClick:()=>x(s("home")),children:[a.jsx(V,{}),"Documentation 홈으로"]})]}):a.jsxs(m.Suspense,{fallback:a.jsx("p",{className:"p-8",role:"status",children:"카탈로그를 불러오는 중…"}),children:[r==="geometry"?a.jsx(Qe,{embedded:!0,selectedKey:t,onSelectedKeyChange:e=>x(s(r,e))}):r==="materials"?a.jsx(Je,{embedded:!0,selectedKey:t,onSelectedKeyChange:e=>x(s(r,e))}):r==="quantity-kinds"?a.jsx(Xe,{embedded:!0,selectedKey:t,onSelectedKeyChange:e=>x(s(r,e))}):r==="examples"?a.jsx(Ze,{embedded:!0,selectedKey:t,onSelect:e=>x(s("examples",e)),onSelectSolver:(e,n)=>x(s("solvers",`${e}@${n}`))}):a.jsx(Ye,{embedded:!0,selectedKey:t,onSelectedKeyChange:e=>x(e.startsWith("experiment:")?s("examples",e.slice(11)):s("solvers",e))}),a.jsx("div",{className:"px-6 pb-6",children:a.jsxs(C,{variant:"ghost",onClick:()=>x(s(r)),children:[a.jsx(V,{className:"size-4"}),"목록으로"]})})]})]})]})]})}function q(){const r=K(),t=H(),o=m.useMemo(()=>Oe(r.search)??{kind:"home",item:null,anchor:null},[r.search]),u=m.useCallback(d=>{const h=new URL(d,window.location.origin);t({pathname:"/doc",search:h.search,hash:""})},[t]);return a.jsx("main",{className:"h-full min-h-0 overflow-hidden",children:a.jsx(aa,{...o,onNavigate:u})})}const ra=q,pa=Object.freeze(Object.defineProperty({__proto__:null,Component:ra,DocumentationPage:q},Symbol.toStringTag,{value:"Module"}));export{_ as C,pa as D,We as u};
