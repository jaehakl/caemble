import"./core-B4lC9ccM.js";import"./index-Bf40e79f.js";import"./runtime-CCmOT4OH.js";import{f as e}from"./document-0gOELFzm.js";import"./index-C4hnMESb.js";const n=`import {
  Mat,
  Material,
  structure,
  type Geometry,
  type Vec3,
} from '@caemble/core'

const NotchedConductor: Geometry<{
  notchPosition: Vec3
  notchSize: Vec3
  size: Vec3
}> = ({ notchPosition, notchSize, size }) => (
  <subtract>
    <box size={size} />
    <box pos={notchPosition} size={notchSize} />
  </subtract>
)

export default structure({
  lengthUnit: 'mm',

  varsSchema: {
    conductorSize: { min: [100, 12, 10], max: [100, 12, 10] },
    notchPosition: { min: [0, 4.5, 3], max: [0, 4.5, 3] },
    notchSize: { min: [30, 5, 6], max: [30, 5, 6] },
    electricalConductivity: { min: 5.96e7, max: 5.96e7 },
  },

  geometry: ({ vars }) => (
    <NotchedConductor
      id="conductor"
      size={vars.conductorSize}
      notchPosition={vars.notchPosition}
      notchSize={vars.notchSize}
      materials={[
        new Material('Copper', 'reference', {
          errorRate: 0,
          'electrical.conductivity': {
            dtype: 'float64',
            value: Mat(vars.electricalConductivity),
            unit: 'S.m-1',
          },
          color: '#c2410c',
        }),
      ]}
    />
  ),

  geometryGroup: {
    conductor: ['conductor'],
  },

  surfaceGroup: {
    sourceTerminal: ['conductor/surface-1'],
    referenceTerminal: ['conductor/surface-2'],
  },
})
`,c=`import { experiment } from '@caemble/core'

export default experiment({
  varsSchema: {
    sourceVoltage: { min: 1, max: 1 },
  },
  recordedData: {
    currentDensity: {
      dtype: 'float64',
      unit: 'A.m-2',
      quantityKind: 'electromagnetism.ElectricCurrentDensity',
      basis: [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
      ],
      axes: [
        { name: 'cross-section v', unit: 'm', quantityKind: 'Length' },
        { name: 'cross-section u', unit: 'm', quantityKind: 'Length' },
      ],
    },
    totalCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
  },
})
`,s=`import { defineTask } from '@caemble/core'

function FieldProbe() {
  return <box size={[3, 3, 3]} />
}

export default defineTask({
  kernel: { name: 'dc-current-density', version: '0.0.0' },
  lengthUnit: 'mm',
  geometry: () => <FieldProbe id="field-probe" pos={[0, -15, 0]} />,
  config: ({ vars }) => ({
  parameters: {
    relativeTolerance: {
      dtype: 'float64',
      value: 1e-8,
      unit: '{fraction}',
      quantityKind: 'DimensionlessRatio',
    },
    maxIterations: 2000,
  },

  initializations: [
    {
      target: ['structure.geometry.conductor'],
      methodId: 'dc.voxel-grid',
      parameters: {
        gridShape: {
          dtype: 'int32',
          axes: [{ length: 3 }],
          value: [40, 21, 21],
        },
      },
    },
  ],

  boundaryConditions: [
    {
      target: ['structure.surface.sourceTerminal'],
      methodId: 'dc.source-potential',
      parameters: {
        voltage: {
          dtype: 'float64',
          value: vars.sourceVoltage,
          unit: 'mV',
          quantityKind: 'electromagnetism.Voltage',
        },
      },
    },
    {
      target: ['structure.surface.referenceTerminal'],
      methodId: 'dc.reference-potential',
      parameters: {
        voltage: {
          dtype: 'float64',
          value: 0,
          unit: 'mV',
          quantityKind: 'electromagnetism.Voltage',
        },
      },
    },
  ],

  outputs: [
    {
      key: 'currentDensity',
      target: ['structure.geometry.conductor'],
      methodId: 'dc.current-density',
      parameters: {
        crossSectionPosition: {
          dtype: 'float64',
          value: 0.35,
          unit: '{fraction}',
          quantityKind: 'DimensionlessRatio',
        },
      },
    },
    {
      key: 'totalCurrent',
      target: ['structure.geometry.conductor'],
      methodId: 'dc.total-current',
      parameters: {
        crossSectionPosition: {
          dtype: 'float64',
          value: 0.35,
          unit: '{fraction}',
          quantityKind: 'DimensionlessRatio',
        },
      },
    },
  ],
  }),
})
`,u=`async def simulate(*, sim, tasks, vars):
    result = await sim.run(tasks["solveField"])
    await sim.record("currentDensity", result["artifacts"]["currentDensity"])
    await sim.record("totalCurrent", result["artifacts"]["totalCurrent"])
    return result["state"]
`,m=e({"experiment.tsx":c,"simulate.py":u,"tasks/solveField.tsx":s}),l=Object.freeze({id:"dc-notched-current-density",title:"DC Notched Current Density",description:"notch 주변 전류 집중을 2D vector field와 전체 전류로 함께 기록합니다.",concepts:Object.freeze(["simulation이 제공하는 initialState","한 task에서 여러 artifact handle 요청","동적 2D axes와 vector Quantity RecordedData"]),structureCode:n,experimentSourceBundle:m,verification:Object.freeze({kernelTasks:Object.freeze(["solveField"]),recordedData:Object.freeze(["currentDensity","totalCurrent"]),expectations:Object.freeze(["currentDensity value shape = [21, 21, 3]","모든 field 성분과 axis tick이 유한값","totalCurrent > 0 A"])})}),t=`import {
  Mat,
  Material,
  structure,
  type Geometry,
  type Vec3,
} from '@caemble/core'

const Conductor: Geometry<{ size: Vec3 }> = ({ size }) => <box size={size} />

export default structure({
  lengthUnit: 'mm',

  varsSchema: {
    conductorSize: { min: [100, 5, 5], max: [100, 5, 5] },
    electricalConductivity: { min: 5.96e7, max: 5.96e7 },
  },

  geometry: ({ vars }) => (
    <Conductor
      id="conductor"
      size={vars.conductorSize}
      materials={[
        new Material('Copper', 'reference', {
          errorRate: 0,
          'electrical.conductivity': {
            dtype: 'float64',
            value: Mat(vars.electricalConductivity),
            unit: 'S.m-1',
          },
          color: '#d97706',
        }),
      ]}
    />
  ),

  geometryGroup: {
    conductor: ['conductor'],
  },

  surfaceGroup: {
    sourceTerminal: ['conductor/surface-1'],
    referenceTerminal: ['conductor/surface-2'],
  },
})
`,d=`import { experiment } from '@caemble/core'

export default experiment({
  varsSchema: {
    sourceVoltage: { min: 1, max: 1 },
    referenceVoltage: { min: 0, max: 0 },
  },
  recordedData: {
    totalCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
  },
})
`,p=`import { defineTask } from '@caemble/core'

function Probe() {
  return <box size={[2, 2, 2]} />
}

export default defineTask({
  kernel: { name: 'dc-current-density', version: '0.0.0' },
  lengthUnit: 'mm',
  geometry: () => <Probe id="probe" pos={[0, -10, 0]} />,
  config: ({ vars }) => ({
  parameters: {
    relativeTolerance: {
      dtype: 'float64',
      value: 1e-10,
      unit: '{fraction}',
      quantityKind: 'DimensionlessRatio',
    },
    maxIterations: 1000,
  },

  initializations: [
    {
      target: ['structure.geometry.conductor'],
      methodId: 'dc.voxel-grid',
      parameters: {
        gridShape: {
          dtype: 'int32',
          axes: [{ length: 3 }],
          value: [20, 11, 11],
        },
      },
    },
  ],

  boundaryConditions: [
    {
      target: ['structure.surface.sourceTerminal'],
      methodId: 'dc.source-potential',
      parameters: {
        voltage: {
          dtype: 'float64',
          value: vars.sourceVoltage,
          unit: 'mV',
          quantityKind: 'electromagnetism.Voltage',
        },
      },
    },
    {
      target: ['structure.surface.referenceTerminal'],
      methodId: 'dc.reference-potential',
      parameters: {
        voltage: {
          dtype: 'float64',
          value: vars.referenceVoltage,
          unit: 'mV',
          quantityKind: 'electromagnetism.Voltage',
        },
      },
    },
  ],

  outputs: [
    {
      key: 'totalCurrent',
      target: ['structure.geometry.conductor'],
      methodId: 'dc.total-current',
      parameters: {
        crossSectionPosition: {
          dtype: 'float64',
          value: 0.5,
          unit: '{fraction}',
          quantityKind: 'DimensionlessRatio',
        },
      },
    },
  ],
  }),
})
`,f=`async def simulate(*, sim, tasks, vars):
    result = await sim.run(tasks["solveCurrent"])
    await sim.record("totalCurrent", result["artifacts"]["totalCurrent"])
    return result["state"]
`,y=e({"experiment.tsx":d,"simulate.py":f,"tasks/solveCurrent.tsx":p}),g=Object.freeze({id:"dc-uniform-bar",title:"DC Uniform Bar",description:"가장 작은 Experiment Program으로 균일 구리 막대의 전체 전류를 계산합니다.",concepts:Object.freeze(["Structure group과 surface target","task factory와 단일 sim.run()","중간 artifact handle을 RecordedData로 기록"]),structureCode:t,experimentSourceBundle:y,verification:Object.freeze({kernelTasks:Object.freeze(["solveCurrent"]),recordedData:Object.freeze(["totalCurrent"]),expectations:Object.freeze(["totalCurrent = 14.9 A ± 1e-6","dc-current-density@0.0.0 호출 1회","stateless DC 실행은 입력 state revision 유지"]),fixture:Object.freeze({records:Object.freeze([Object.freeze({name:"totalCurrent",dtype:"float64",shape:Object.freeze([]),value:14.9,absoluteTolerance:1e-6})]),terminal:Object.freeze({kind:"complete",sequence:2,recordSequences:Object.freeze([1])})})})}),v=`import { experiment } from '@caemble/core'

export default experiment({
  varsSchema: {
    sourceVoltage: { min: 1, max: 1 },
  },
  recordedData: {
    coarseTotalCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
    fineTotalCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
  },
})
`;function r(a,o,i){return`import { defineTask } from '@caemble/core'

function ConvergenceProbe() {
  return <box size={[2, 2, 2]} />
}

export default defineTask({
  kernel: { name: 'dc-current-density', version: '0.0.0' },
  lengthUnit: 'mm',
  geometry: () => <ConvergenceProbe id="convergence-probe" pos={[0, ${i}, 0]} />,
  config: ({ vars }) => ({
    parameters: {
      relativeTolerance: {
        dtype: 'float64',
        value: 1e-10,
        unit: '{fraction}',
        quantityKind: 'DimensionlessRatio',
      },
      maxIterations: 1000,
    },

    initializations: [
      {
        target: ['structure.geometry.conductor'],
        methodId: 'dc.voxel-grid',
        parameters: {
          gridShape: {
            dtype: 'int32',
            axes: [{ length: 3 }],
            value: ${a},
          },
        },
      },
    ],

    boundaryConditions: [
      {
        target: ['structure.surface.sourceTerminal'],
        methodId: 'dc.source-potential',
        parameters: {
          voltage: {
            dtype: 'float64',
            value: vars.sourceVoltage,
            unit: 'mV',
            quantityKind: 'electromagnetism.Voltage',
          },
        },
      },
      {
        target: ['structure.surface.referenceTerminal'],
        methodId: 'dc.reference-potential',
        parameters: {
          voltage: {
            dtype: 'float64',
            value: 0,
            unit: 'mV',
            quantityKind: 'electromagnetism.Voltage',
          },
        },
      },
    ],

    outputs: [
      {
        key: '${o}',
        target: ['structure.geometry.conductor'],
        methodId: 'dc.total-current',
        parameters: {
          crossSectionPosition: {
            dtype: 'float64',
            value: 0.5,
            unit: '{fraction}',
            quantityKind: 'DimensionlessRatio',
          },
        },
      },
    ],
  }),
})
`}const h=r("[10, 7, 7]","coarseTotalCurrent",-10),x=r("[20, 11, 11]","fineTotalCurrent",-14),C=`async def simulate(*, sim, tasks, vars):
    coarse = await sim.run(tasks["solveCoarse"])
    await sim.record(
        "coarseTotalCurrent",
        coarse["artifacts"]["coarseTotalCurrent"],
    )
    fine = await sim.run(tasks["solveFine"], state=coarse["state"])
    await sim.record(
        "fineTotalCurrent",
        fine["artifacts"]["fineTotalCurrent"],
    )
    return fine["state"]
`,b=e({"experiment.tsx":v,"simulate.py":C,"tasks/solveCoarse.tsx":h,"tasks/solveFine.tsx":x}),T=Object.freeze({id:"dc-resolution-study",title:"DC Resolution Study",description:"같은 물리 문제를 coarse/fine task로 연속 실행해 named task orchestration을 확인합니다.",concepts:Object.freeze(["재사용 가능한 task factory","이전 result.state를 다음 sim.run()에 전달","여러 task의 RecordedData와 trace 비교"]),structureCode:t,experimentSourceBundle:b,verification:Object.freeze({kernelTasks:Object.freeze(["solveCoarse","solveFine"]),recordedData:Object.freeze(["coarseTotalCurrent","fineTotalCurrent"]),expectations:Object.freeze(["trace 순서 = solveCoarse → solveFine","stateless DC task 사이에서 state revision 유지","두 total current 모두 14.9 A ± 1e-6"])})}),z=`import {
  Mat,
  Material,
  structure,
  type Geometry,
  type Vec3,
} from '@caemble/core'

const Conductor: Geometry<{ size: Vec3 }> = ({ size }) => <box size={size} />

export default structure({
  lengthUnit: 'mm',
  varsSchema: {
    conductorSize: { min: [100, 5, 5], max: [100, 5, 5] },
    electricalConductivity: { min: 5.96e7, max: 5.96e7 },
    thermalConductivity: { min: 401, max: 401 },
  },
  geometry: ({ vars }) => (
    <Conductor
      id="conductor"
      size={vars.conductorSize}
      materials={[
        new Material('Copper', 'reference', {
          errorRate: 0,
          'electrical.conductivity': {
            dtype: 'float64',
            value: Mat(vars.electricalConductivity),
            unit: 'S.m-1',
          },
          'thermal.conductivity': {
            dtype: 'float64',
            value: Mat(vars.thermalConductivity),
            unit: 'W.m-1.K-1',
          },
          color: '#d97706',
        }),
      ]}
    />
  ),
  geometryGroup: { conductor: ['conductor'] },
  surfaceGroup: {
    sourceTerminal: ['conductor/surface-1'],
    referenceTerminal: ['conductor/surface-2'],
  },
})
`,k=`import { experiment } from '@caemble/core'

export default experiment({
  varsSchema: {
    sourceVoltage: { min: 1, max: 1 },
    fixedTemperature: { min: 293.15, max: 293.15 },
  },
  recordedData: {
    totalCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
    temperature: {
      dtype: 'float64',
      unit: 'K',
      quantityKind: 'thermodynamics.Temperature',
      axes: [
        { name: 'axial position', unit: 'm', quantityKind: 'Length' },
        { name: 'cross-section v', unit: 'm', quantityKind: 'Length' },
        { name: 'cross-section u', unit: 'm', quantityKind: 'Length' },
      ],
    },
    maximumTemperature: {
      dtype: 'float64',
      unit: 'K',
      quantityKind: 'thermodynamics.Temperature',
    },
  },
})
`,S=`import { defineTask } from '@caemble/core'

function ElectricProbe() {
  return <box size={[2, 2, 2]} />
}

export default defineTask({
  kernel: { name: 'dc-current-density', version: '0.0.0' },
  lengthUnit: 'mm',
  geometry: () => <ElectricProbe id="electric-probe" pos={[0, -10, 0]} />,
  config: ({ vars }) => ({
    parameters: {
      relativeTolerance: { dtype: 'float64', value: 1e-10, unit: '{fraction}', quantityKind: 'DimensionlessRatio' },
      maxIterations: 1000,
    },
    initializations: [{
      target: ['structure.geometry.conductor'],
      methodId: 'dc.voxel-grid',
      parameters: { gridShape: { dtype: 'int32', axes: [{ length: 3 }], value: [20, 11, 11] } },
    }],
    boundaryConditions: [
      {
        target: ['structure.surface.sourceTerminal'],
        methodId: 'dc.source-potential',
        parameters: { voltage: { dtype: 'float64', value: vars.sourceVoltage, unit: 'mV', quantityKind: 'electromagnetism.Voltage' } },
      },
      {
        target: ['structure.surface.referenceTerminal'],
        methodId: 'dc.reference-potential',
        parameters: { voltage: { dtype: 'float64', value: 0, unit: 'mV', quantityKind: 'electromagnetism.Voltage' } },
      },
    ],
    outputs: [
      {
        key: 'totalCurrent',
        target: ['structure.geometry.conductor'],
        methodId: 'dc.total-current',
        parameters: { crossSectionPosition: { dtype: 'float64', value: 0.5, unit: '{fraction}', quantityKind: 'DimensionlessRatio' } },
      },
      { key: 'jouleHeating', target: ['structure.geometry.conductor'], methodId: 'dc.joule-heating', parameters: {} },
    ],
  }),
})
`,D=`import { defineTask } from '@caemble/core'

function ThermalProbe() {
  return <box size={[2, 2, 2]} />
}

export default defineTask({
  kernel: { name: 'steady-state-heat', version: '0.0.0' },
  lengthUnit: 'mm',
  geometry: () => <ThermalProbe id="thermal-probe" pos={[0, -14, 0]} />,
  config: ({ vars }) => ({
    parameters: {
      relativeTolerance: { dtype: 'float64', value: 1e-10, unit: '{fraction}', quantityKind: 'DimensionlessRatio' },
      maxIterations: 1000,
    },
    initializations: [{
      target: ['structure.geometry.conductor'],
      methodId: 'heat.voxel-grid',
      parameters: { gridShape: { dtype: 'int32', axes: [{ length: 3 }], value: [20, 11, 11] } },
    }],
    boundaryConditions: [
      {
        target: ['structure.surface.sourceTerminal'],
        methodId: 'heat.fixed-temperature',
        parameters: { temperature: { dtype: 'float64', value: vars.fixedTemperature, unit: 'K', quantityKind: 'thermodynamics.Temperature' } },
      },
      {
        target: ['structure.surface.referenceTerminal'],
        methodId: 'heat.fixed-temperature',
        parameters: { temperature: { dtype: 'float64', value: vars.fixedTemperature, unit: 'K', quantityKind: 'thermodynamics.Temperature' } },
      },
    ],
    outputs: [
      { key: 'temperature', target: ['structure.geometry.conductor'], methodId: 'heat.temperature', parameters: {} },
      { key: 'maximumTemperature', target: ['structure.geometry.conductor'], methodId: 'heat.maximum-temperature', parameters: {} },
    ],
  }),
})
`,K=`async def simulate(*, sim, tasks, vars):
    electric = await sim.run(tasks["electric"])
    thermal = await sim.run(
        tasks["thermal"],
        state=electric["state"],
        inputs={"heatSource": electric["artifacts"]["jouleHeating"]},
    )
    await sim.record("totalCurrent", electric["artifacts"]["totalCurrent"])
    await sim.record("temperature", thermal["artifacts"]["temperature"])
    await sim.record(
        "maximumTemperature",
        thermal["artifacts"]["maximumTemperature"],
    )
    sim.release(electric["artifacts"]["jouleHeating"])
    return thermal["state"]
`,j=e({"experiment.tsx":k,"simulate.py":K,"tasks/electric.tsx":S,"tasks/thermal.tsx":D}),q=Object.freeze({id:"electro-thermal-uniform-bar",title:"Electro-Thermal Uniform Bar",description:"DC 전류가 만든 Joule heating을 정상상태 Heat solver로 전달해 구리 막대 온도장을 계산합니다.",concepts:Object.freeze(["서로 다른 physics kernel의 typed artifact handoff","Joule heating을 이용한 단방향 전기-열 결합","3D temperature RecordedData와 maximum temperature"]),structureCode:z,experimentSourceBundle:j,verification:Object.freeze({kernelTasks:Object.freeze(["electric","thermal"]),recordedData:Object.freeze(["totalCurrent","temperature","maximumTemperature"]),expectations:Object.freeze(["trace 순서 = electric → thermal","totalCurrent = 14.9 A ± 1e-6","maximumTemperature ≈ 293.1685 K"])})}),B=20260803,P=Object.freeze([g,l,T,q]);export{B as C,P as c};
