import{u as it,d as at,a as lt,k as ot,T as ct,U as ut,r as n,z as Te,e as qe,t as C,l as he,j as t,B as c,i as ge,x as dt,g as Y}from"./main-NbJSz9Ta.js";import{D as mt}from"./DataTable-Cl2wMu6Z.js";import{B as ze}from"./badge-ZLFWnaBT.js";import{C as pt}from"./card-B9d26jgF.js";import{D as ve,a as be,b as je,c as Ee,d as Ce,e as ye}from"./dialog-D4t6SqlX.js";import{I as Ae}from"./input-C1rR-MnR.js";import{r as xt,u as ft,E as Ke,S as ht,s as gt}from"./measurement-return-Cbg4xnO-.js";import{r as vt,P as Ve}from"./resolveMaterials-SLYnpIV8.js";import{c as Se,a as bt,u as jt,C as Et}from"./useCadWorkspace-CwFoqwqk.js";import{S as Ct}from"./StructureExperimentViewer-jdRGG_n8.js";import"./core-DTJcRMva.js";import"./index-BxTvmZKS.js";import"./runtime-Ygud-gGu.js";import"./index-Bsf3HgG-.js";import{C as yt}from"./code-xml-R6IU1c37.js";import{A as ke}from"./arrow-left-Gv01OnBW.js";import{P as Ne}from"./plus-Ci1hZpyB.js";import{S as St}from"./search-BGapJ-DT.js";import{T as $e}from"./trash-2-DZ_l6IwZ.js";import"./preload-helper-CS1eXPs2.js";import"./table-NXb95c_8.js";import"./protocol-DPQIOZkQ.js";import"./client-DrIz7E1g.js";const kt=`import { defineTask, experiment } from '@caemble/core'

function ExperimentDevice() {
  return <box size={[1, 1, 1]} />
}

export default experiment({
  lengthUnit: 'mm',
  varsSchema: {
    sourceVoltage: { min: 1, max: 1 },
    referenceVoltage: { min: 0, max: 0 },
  },
  geometry: () => <ExperimentDevice id="experiment-device" />,

  tasks: ({ vars }) => ({
    electric: defineTask({ name: 'dc-current-density', version: '0.0.0' }, {
      parameters: {
        relativeTolerance: {
          dtype: 'float64',
          value: 1e-8,
          unit: '{fraction}',
          quantityKind: 'DimensionlessRatio',
        },
        maxIterations: 2000,
      },
      initializations: [
        {
          methodId: 'dc.voxel-grid',
          target: ['structure.geometry.conductor'],
          parameters: {
            gridShape: {
              dtype: 'int32',
              axes: [{ length: 3 }],
              value: [100, 41, 41],
            },
          },
        },
      ],
      boundaryConditions: [
        {
          methodId: 'dc.source-potential',
          target: ['structure.surface.sourceTerminal'],
          parameters: {
            voltage: {
              dtype: 'float64',
              value: vars.sourceVoltage,
              unit: 'mV',
              quantityKind: 'electromagnetism.Voltage',
            },
          },
        },
        {
          methodId: 'dc.reference-potential',
          target: ['structure.surface.referenceTerminal'],
          parameters: {
            voltage: {
              dtype: 'float64',
              value: vars.referenceVoltage,
              unit: 'mV',
              quantityKind: 'electromagnetism.Voltage',
            },
          },
        },
      ],
      outputs: [
        {
          key: 'currentDensity',
          methodId: 'dc.current-density',
          target: ['structure.geometry.conductor'],
          parameters: {
            crossSectionPosition: {
              dtype: 'float64',
              value: 0.35,
              unit: '{fraction}',
              quantityKind: 'DimensionlessRatio',
            },
          },
        },
        {
          key: 'totalCurrent',
          methodId: 'dc.total-current',
          target: ['structure.geometry.conductor'],
          parameters: {
            crossSectionPosition: {
              dtype: 'float64',
              value: 0.35,
              unit: '{fraction}',
              quantityKind: 'DimensionlessRatio',
            },
          },
        },
      ],
    }),
  }),

  recordedData: {
    measuredCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
  },

})
`,Nt=`async def simulate(*, sim, tasks, vars, world):
    electric = await sim.run(tasks["electric"])
    await sim.record(
        "measuredCurrent",
        electric["artifacts"]["totalCurrent"],
    )
    sim.release(electric["artifacts"]["currentDensity"])
    return electric["state"]
`,Be=44;function Dt(a){const l=Number(a);return Number.isSafeInteger(l)&&l>0?l:null}function Z(a,l){const m=Date.parse(l.updated_at??"")-Date.parse(a.updated_at??"");return Number.isNaN(m)||m===0?l.id-a.id:m}function Pt(a,l){return!!(l&&(l.roles.includes("admin")||a.user_id===l.id))}function Oe(a,l){const m=Math.max(25,360/l*100),h=Math.min(75,(l-320)/l*100);return Math.min(h,Math.max(m,a))}function Fe({canManage:a,childrenByParent:l,depth:m,onDelete:h,onNavigate:i,row:o,selectedId:d}){const S=l.get(o.id)??[];return t.jsxs("li",{children:[t.jsxs("div",{className:`flex items-center gap-2 border-b px-2 py-2 ${o.id===d?"bg-orange-50":"hover:bg-muted/50"}`,style:{paddingLeft:`${m*18+8}px`},children:[t.jsxs("button",{className:"min-w-0 flex-1 text-left",type:"button",onClick:()=>i(o),children:[t.jsxs("span",{className:"flex items-center gap-2",children:[t.jsx("span",{className:"truncate text-sm font-medium",children:o.name}),m===0?t.jsx(ze,{children:"root"}):null,S.length===0?t.jsx(ze,{children:"leaf"}):null]}),t.jsx("span",{className:"mt-0.5 block truncate text-xs text-muted-foreground",children:o.description||`Experiment #${o.id}`})]}),a(o)?t.jsx(c,{"aria-label":`${o.name} 삭제`,className:"text-destructive hover:text-destructive",size:"icon",title:"Experiment 삭제",variant:"ghost",onClick:()=>h(o),children:t.jsx($e,{})}):null]}),S.length>0?t.jsx("ul",{children:S.map(p=>t.jsx(Fe,{canManage:a,childrenByParent:l,depth:m+1,onDelete:h,onNavigate:i,row:p,selectedId:d},p.id))}):null]})}function Rt({canManage:a,onDelete:l,onNavigate:m,rows:h,selected:i}){const{childrenByParent:o,root:d}=n.useMemo(()=>{const S=new Map(h.map(v=>[v.id,v])),p=new Map;h.forEach(v=>{if(v.parent_id==null||!S.has(v.parent_id))return;const B=p.get(v.parent_id)??[];B.push(v),p.set(v.parent_id,B)}),p.forEach(v=>v.sort(Z));let g=i;const _=new Set;for(;g.parent_id!=null&&S.has(g.parent_id)&&!_.has(g.id);)_.add(g.id),g=S.get(g.parent_id);return{childrenByParent:p,root:g}},[h,i]);return t.jsxs("div",{className:"h-full overflow-auto bg-background",children:[t.jsxs("div",{className:"border-b bg-muted/20 px-4 py-3",children:[t.jsxs("div",{className:"flex items-center gap-2 text-sm font-semibold",children:[t.jsx(dt,{className:"size-4 text-primary"}),"전체 계보"]}),t.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"보이는 root부터 모든 후손을 표시합니다."})]}),t.jsx("ul",{children:t.jsx(Fe,{canManage:a,childrenByParent:o,depth:0,onDelete:l,onNavigate:m,row:d,selectedId:i.id})})]})}function wt(){const a=it(),l=at(),m=lt(),h=ot(),{currentExperimentId:i,currentStructureId:o,setCurrentExperimentId:d,setCurrentStructureId:S}=ct(),[p,g]=ut(),[_,v]=n.useState(""),[B,He]=n.useState(!1),[y,O]=n.useState(null),[ee,$]=n.useState(null),[te,F]=n.useState(null),[q,H]=n.useState(null),[ne,De]=n.useState(""),[Pe,Re]=n.useState(""),[P,z]=n.useState(null),[re,A]=n.useState(null),[Qe,Q]=n.useState(!1),[se,U]=n.useState(!1),[ie,W]=n.useState(!1),[K,X]=n.useState(null),[we,ae]=n.useState(Be),Me=n.useRef(!1),le=n.useRef(null),[w]=n.useState(()=>xt(l.state)),Ue=n.useMemo(()=>({...Te("visible"),limit:null}),[]),L=qe({queryKey:["experiments","visible"],queryFn:()=>Y.Experiment.listRows(Ue)}),N=qe({queryKey:["structures","visible",o],queryFn:async()=>o===null?null:(await Y.Structure.listRows(Te("visible",[o]))).items[0]??null,enabled:o!==null}),b=n.useMemo(()=>(L.data?.items??[]).filter(e=>e.id!==void 0).sort(Z),[L.data?.items]),j=b.find(e=>e.id===i)??null,oe=n.useMemo(()=>N.data?Se("structure",N.data.code):null,[N.data]),I=n.useCallback(e=>Pt(e,a.user),[a.user]),G=!!(j&&I(j)),D=!!(y&&(ee===null||te===null||bt(y)!==ee||y.simulationCode!==te)),_e=n.useMemo(()=>{const e=new Set(b.map(f=>f.id)),s=new Set(b.flatMap(f=>f.parent_id!=null&&e.has(f.parent_id)?[f.parent_id]:[])),r=_.trim().toLocaleLowerCase();return b.filter(f=>!s.has(f.id)&&(!r||[f.name,f.description??""].some(fe=>fe.toLocaleLowerCase().includes(r))))},[_,b]),k=n.useCallback(e=>{g(s=>{const r=new URLSearchParams(s);return e?r.set("experiment",String(e)):r.delete("experiment"),r},{replace:!0})},[g]),E=n.useCallback(e=>{He(e),!(!w&&!p.has("mode"))&&g(s=>{const r=new URLSearchParams(s);return r.set("mode",e?"code":"list"),r},{replace:!0})},[w,p,g]),R=n.useCallback(e=>{O(e.simulation_code===null?null:Se("experiment",e.code,void 0,e.simulation_code)),d(e.id),$(e.code),F(e.simulation_code),k(e.id)},[d,k]),We=n.useCallback(()=>{O(null),d(null),$(null),F(null),E(!1),k(null)},[d,k,E]),ce=n.useCallback(()=>{O(Se("experiment",kt,void 0,Nt)),d(null),$(null),F(null),E(!0),k(null)},[d,k,E]);n.useEffect(()=>{if(Me.current||!L.isSuccess)return;Me.current=!0;const e=p.get("experiment"),s=e===null?i:Dt(e);if(s===null){e!==null&&(C.error("Experiment를 찾을 수 없습니다."),d(null),k(null));return}const r=b.find(f=>f.id===s);if(!r){C.error("Experiment를 찾을 수 없습니다."),d(null),k(null);return}R(r),p.get("mode")==="code"&&r.simulation_code===null?(C.error("Python source가 없는 기존 Experiment는 편집하거나 미리 볼 수 없습니다."),E(!1)):E(p.get("mode")==="code")},[R,L.isSuccess,b,p,i,d,k,E]),n.useEffect(()=>{o!==null&&(N.isSuccess&&N.data===null?(C.error("현재 Structure를 찾을 수 없습니다."),S(null)):N.isError&&C.error("현재 Structure를 불러오지 못했습니다."))},[o,N.data,N.isError,N.isSuccess,S]);const Xe=n.useCallback(e=>vt(e,null),[]),Ge=n.useCallback(e=>O(e),[]),{experimentDocument:u,simulation:T,structureDocument:x}=jt(oe,y,void 0,a.isAuthenticated?Ge:void 0,void 0,void 0,Xe,"standard",a.isAuthenticated),ue=n.useCallback(async()=>{await Promise.all([h.invalidateQueries({queryKey:["experiments"]}),h.invalidateQueries({queryKey:["work","experiments"]})])},[h]),J=he({mutationFn:({description:e,name:s,row:r})=>Y.Experiment.upsertRow([{id:r.id,user_id:r.user_id,parent_id:r.parent_id,name:s.trim(),description:e.trim()||null,code:r.code,simulation_code:r.simulation_code}]),onSuccess:async()=>{H(null),await ue(),C.success("Experiment 정보를 저장했습니다.")},onError:e=>C.error(e instanceof Error?e.message:"Experiment 정보를 저장하지 못했습니다.")}),de=he({mutationFn:({forceRoot:e,values:s})=>{if(!y)throw new Error("저장할 Experiment source가 없습니다.");if(!a.isAuthenticated)throw new Error("로그인이 필요합니다.");if(!e&&(!j||!I(j)))throw new Error("이 Experiment를 수정할 권한이 없습니다.");return gt({document:y,forceRoot:e,kind:"experiment",savedCode:ee,savedSimulationCode:te,selectedId:i,simulationCode:y.simulationCode,values:s})},onSuccess:async({action:e,code:s,id:r,simulationCode:f},{forceRoot:fe})=>{d(r),$(s),F(f??null),k(r),z(null),await ue(),C.success(fe?"현재 Experiment를 새 root로 저장했습니다.":e==="forked"?"구조 변경을 새 child Experiment로 저장했습니다.":"Experiment를 저장했습니다.")},onError:e=>C.error(e instanceof Error?e.message:"Experiment를 저장하지 못했습니다.")}),V=he({mutationFn:async e=>(await Y.Experiment.deleteRows([e.id]),e),onSuccess:async e=>{const s=e.parent_id==null?b.filter(r=>r.parent_id===e.id).sort(Z)[0]??null:b.find(r=>r.id===e.parent_id)??b.filter(r=>r.parent_id===e.id).sort(Z)[0]??null;X(null),i===e.id&&(s?R(s):We()),await ue(),C.success("Experiment를 삭제하고 기존 child의 계보를 재연결했습니다.")},onError:e=>C.error(e instanceof Error?e.message:"Experiment를 삭제하지 못했습니다.")}),Le=n.useCallback((e,s)=>{if(e.id===i){s&&e.simulation_code!==null&&u.handleReroll();return}if(D){A(e);return}R(e)},[R,D,i,u]),Je=n.useCallback(()=>{if(D){U(!0);return}ce()},[D,ce]),me=n.useCallback(e=>{if(e.simulation_code===null){C.error("Python source가 없는 기존 Experiment는 편집하거나 미리 볼 수 없습니다.");return}if(e.id===i){E(!0);return}if(D){A(e),Q(!0);return}R(e),E(!0)},[R,D,i,E]),pe=n.useCallback(()=>{w&&m(ft(w,"experiment",i))},[w,m,i]),Ie=n.useCallback(()=>{if(D){W(!0);return}pe()},[D,pe]),xe=n.useCallback(e=>{H(e),De(e.name),Re(e.description??"")},[]),Ye=n.useMemo(()=>[{accessorKey:"name",header:"Name",cell:({row:e})=>t.jsxs("div",{className:"min-w-40",children:[t.jsx("p",{className:"font-medium",children:e.original.name}),t.jsxs("p",{className:"mt-1 text-xs text-muted-foreground",children:["Experiment #",e.original.id]})]})},{accessorKey:"description",header:"Description",cell:({row:e})=>t.jsx("p",{className:"line-clamp-2 max-w-xl text-sm text-muted-foreground",children:e.original.description||"—"})},{id:"actions",header:"",cell:({row:e})=>{const s=I(e.original);return t.jsxs("div",{className:"flex items-center justify-end gap-1",children:[t.jsx(c,{"aria-label":`${e.original.name} 코드 에디터 열기`,size:"icon",title:"코드 에디터 열기",variant:"ghost",onClick:r=>{r.stopPropagation(),me(e.original)},onDoubleClick:r=>r.stopPropagation(),children:t.jsx(yt,{})}),t.jsx(c,{"aria-label":`${e.original.name} ${s?"정보 편집":"정보 보기"}`,size:"icon",title:s?"이름과 설명 편집":"이름과 설명 보기",variant:"ghost",onClick:r=>{r.stopPropagation(),xe(e.original)},onDoubleClick:r=>r.stopPropagation(),children:s?t.jsx(Ve,{}):t.jsx(Ke,{})})]})}}],[I,xe,me]),Ze=n.useMemo(()=>y?{scene:u.scene,sceneHash:u.sceneHash,variables:u.variables}:null,[y,u.scene,u.sceneHash,u.variables]),et=n.useMemo(()=>oe?{scene:x.scene,sceneHash:x.sceneHash,variables:x.variables}:null,[oe,x.scene,x.sceneHash,x.variables]),tt=n.useCallback(e=>{e.includes("structure")&&x.handleRenderStart(),e.includes("experiment")&&u.handleRenderStart()},[u,x]),nt=n.useCallback(e=>{e.includes("structure")&&x.handleRenderEnd(),e.includes("experiment")&&u.handleRenderEnd()},[u,x]),rt=n.useCallback((e,s)=>{s.includes("structure")&&x.handleRenderError(e),s.includes("experiment")&&u.handleRenderError(e)},[u,x]),st={name:j?.name??"새 Experiment",description:j?.description??""},M=!!(q&&I(q));return t.jsxs("section",{"aria-label":"Experiment 관리 페이지",className:"flex h-full min-h-0 flex-col overflow-auto lg:overflow-hidden",children:[t.jsxs("div",{className:"grid min-h-0 flex-1 grid-cols-1 lg:h-full lg:grid-cols-[minmax(360px,var(--workspace-left-width))_5px_minmax(0,1fr)] lg:overflow-hidden",ref:le,style:{"--workspace-left-width":`${we}%`},children:[t.jsx("div",{className:"min-h-[420px] min-w-0 border-b lg:h-full lg:min-h-0 lg:overflow-hidden lg:border-b-0",children:B&&y?t.jsxs("div",{className:"flex h-full min-h-0 flex-col bg-background",children:[t.jsxs("div",{className:"flex min-h-14 shrink-0 flex-wrap items-center gap-2 border-b px-3 py-2",children:[t.jsxs(c,{size:"sm",variant:"ghost",onClick:()=>E(!1),children:[t.jsx(ke,{}),"목록"]}),w?t.jsxs(c,{size:"sm",variant:"outline",onClick:Ie,children:[t.jsx(ke,{}),"Measurement로 돌아가기"]}):null,t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsxs("div",{className:"flex min-w-0 items-center gap-1",children:[t.jsx("p",{className:"min-w-0 truncate text-sm font-semibold",children:j?.name??"새 Experiment"}),j?t.jsx(c,{"aria-label":`${j.name} ${G?"정보 편집":"정보 보기"}`,className:"size-6",size:"icon",title:G?"이름과 설명 편집":"이름과 설명 보기",variant:"ghost",onClick:()=>xe(j),children:G?t.jsx(Ve,{}):t.jsx(Ke,{})}):null]}),t.jsx("p",{className:"text-xs text-muted-foreground",children:i===null?"저장 전 새 Experiment입니다.":D?"저장되지 않은 코드 변경이 있습니다.":"저장된 코드와 일치합니다."})]}),i===null&&a.isAuthenticated?t.jsxs(c,{size:"sm",onClick:()=>z("create"),children:[t.jsx(Ne,{}),"Experiment 생성"]}):G?t.jsx(c,{size:"sm",variant:"outline",onClick:()=>z("save"),children:"Experiment 저장"}):null,i!==null&&a.isAuthenticated?t.jsxs(c,{size:"sm",onClick:()=>z("root"),children:[t.jsx(Ne,{}),"새 root로 저장"]}):null]}),t.jsx("div",{className:"min-h-0 flex-1",children:t.jsx(Ct,{activeDocumentType:"experiment",structure:null,structureDocument:x,experiment:y,experimentDocument:u,experimentLineage:j?t.jsx(Rt,{canManage:I,rows:b,selected:j,onDelete:X,onNavigate:e=>Le(e,!1)}):null,onActiveDocumentTypeChange:()=>{}})})]}):t.jsxs(pt,{className:"flex h-full min-h-0 flex-col overflow-hidden rounded-none border-0 shadow-none",children:[t.jsxs("div",{className:"border-b bg-muted/20 p-4",children:[t.jsxs("div",{className:"flex items-start justify-between gap-4",children:[t.jsxs("div",{children:[t.jsx("h2",{className:"font-semibold",children:"Experiment"}),t.jsxs("p",{className:"mt-1 text-xs text-muted-foreground",children:[_e.length.toLocaleString()," leaf / ",b.length.toLocaleString()," visible"]})]}),t.jsxs("div",{className:"flex flex-wrap items-center justify-end gap-2",children:[w?t.jsxs(c,{size:"sm",onClick:Ie,children:[t.jsx(ke,{}),"Measurement로 돌아가기"]}):null,a.isAuthenticated?t.jsxs(c,{size:"sm",variant:"outline",onClick:Je,children:[t.jsx(Ne,{}),"새 Experiment 생성"]}):null]})]}),t.jsxs("div",{className:"relative mt-4",children:[t.jsx(St,{className:"pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"}),t.jsx(Ae,{"aria-label":"Experiment 검색",className:"pl-9",placeholder:"이름 또는 설명 검색",value:_,onChange:e=>v(e.target.value)})]})]}),t.jsx("div",{className:"min-h-0 flex-1 overflow-auto",children:L.isLoading?t.jsxs("div",{className:"flex min-h-48 items-center justify-center gap-2 text-sm text-muted-foreground",children:[t.jsx(ge,{className:"animate-spin"}),"Experiment 목록을 불러오는 중입니다."]}):L.isError?t.jsx("div",{className:"flex min-h-48 items-center justify-center text-sm text-destructive",children:"Experiment 목록을 불러오지 못했습니다."}):t.jsx(mt,{columns:Ye,data:_e,emptyLabel:"조건에 맞는 leaf Experiment가 없습니다.",getRowKey:e=>String(e.id),selectedKey:i===null?void 0:String(i),onRowClick:e=>Le(e,!0),onRowDoubleClick:me})})]})}),t.jsx("div",{"aria-label":"Experiment 패널과 Viewer 크기 조절","aria-orientation":"vertical","aria-valuemax":75,"aria-valuemin":25,"aria-valuenow":Math.round(we),className:"group hidden cursor-col-resize touch-none items-stretch justify-center bg-muted outline-none hover:bg-neutral-200 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset lg:flex",role:"separator",tabIndex:0,onDoubleClick:()=>ae(Be),onKeyDown:e=>{if(e.key!=="ArrowLeft"&&e.key!=="ArrowRight")return;const s=le.current?.getBoundingClientRect().width;s&&(e.preventDefault(),ae(r=>Oe(r+(e.key==="ArrowLeft"?-2:2),s)))},onPointerDown:e=>e.currentTarget.setPointerCapture(e.pointerId),onPointerMove:e=>{if(!e.currentTarget.hasPointerCapture(e.pointerId))return;const s=le.current?.getBoundingClientRect();s&&ae(Oe((e.clientX-s.left)/s.width*100,s.width))},onPointerUp:e=>e.currentTarget.releasePointerCapture(e.pointerId),children:t.jsx("span",{className:"w-px bg-border group-hover:bg-neutral-400"})}),t.jsx(Et,{experiment:Ze,recordedData:T.recordedData,simulation:{canRun:T.canRun,cancel:T.cancel,process:T.process,program:u.simulationProgram,run:T.run,stale:T.stale},structure:et,onRenderEnd:nt,onRenderError:rt,onRenderStart:tt})]}),t.jsx(ve,{onOpenChange:e=>!e&&!J.isPending&&H(null),open:q!==null,children:t.jsx(be,{children:t.jsxs("form",{className:"grid gap-5",onSubmit:e=>{e.preventDefault(),q&&M&&J.mutate({row:q,name:ne,description:Pe})},children:[t.jsxs(je,{children:[t.jsx(Ee,{children:M?"Experiment 정보 편집":"Experiment 정보"}),t.jsx(Ce,{children:M?"코드는 변경하지 않고 이름과 설명만 저장합니다.":"이 Experiment는 읽기 전용입니다."})]}),t.jsxs("label",{className:"grid gap-1.5 text-sm font-medium",children:["이름",t.jsx(Ae,{autoFocus:M,disabled:!M,maxLength:200,value:ne,onChange:e=>De(e.target.value)})]}),t.jsxs("label",{className:"grid gap-1.5 text-sm font-medium",children:["설명",t.jsx("textarea",{className:"min-h-28 rounded-md border border-input bg-transparent px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60",disabled:!M,maxLength:2e3,value:Pe,onChange:e=>Re(e.target.value)})]}),t.jsxs(ye,{children:[t.jsx(c,{type:"button",variant:"outline",onClick:()=>H(null),children:"닫기"}),M?t.jsxs(c,{disabled:!ne.trim()||J.isPending,type:"submit",children:[J.isPending?t.jsx(ge,{className:"animate-spin"}):null,"저장"]}):null]})]})})}),t.jsx(ht,{defaults:st,description:P==="create"?"기본 Source code를 내 새 root Experiment로 저장합니다.":P==="root"?"현재 Source code를 선택한 Experiment의 parent 없이 내 새 root로 저장합니다.":void 0,kind:"Experiment",open:P!==null,pending:de.isPending,submitLabel:P==="create"?"Experiment 생성":P==="root"?"새 root로 저장":"Experiment 저장",title:P==="create"?"새 Experiment 생성":P==="root"?"새 Experiment root 저장":"Experiment 저장",onOpenChange:e=>!e&&!de.isPending&&z(null),onSubmit:async e=>{await de.mutateAsync({forceRoot:P!=="save",values:e})}}),t.jsx(ve,{onOpenChange:e=>{e||(A(null),Q(!1),U(!1),W(!1))},open:re!==null||se||ie,children:t.jsxs(be,{children:[t.jsxs(je,{children:[t.jsx(Ee,{children:"저장되지 않은 변경을 버릴까요?"}),t.jsx(Ce,{children:ie?"Measurement로 돌아가면 현재 Editor의 코드 변경을 복구할 수 없습니다.":se?"새 Experiment를 시작하면 현재 Editor의 코드 변경을 복구할 수 없습니다.":"다른 Experiment로 이동하면 현재 Editor의 코드 변경을 복구할 수 없습니다."})]}),t.jsxs(ye,{children:[t.jsx(c,{variant:"outline",onClick:()=>{A(null),Q(!1),U(!1),W(!1)},children:"취소"}),t.jsx(c,{variant:"destructive",onClick:()=>{ie?pe():se?ce():re&&(R(re),Qe&&E(!0)),A(null),Q(!1),U(!1),W(!1)},children:"변경 버리고 이동"})]})]})}),t.jsx(ve,{onOpenChange:e=>!e&&!V.isPending&&X(null),open:K!==null,children:t.jsxs(be,{children:[t.jsxs(je,{children:[t.jsx(Ee,{children:"Experiment를 삭제할까요?"}),t.jsx(Ce,{children:"child는 삭제 노드의 parent로 자동 재연결됩니다. 연결된 Setup과 Designer/Predictor Model도 함께 삭제될 수 있습니다."})]}),t.jsxs("div",{className:"rounded-lg border bg-muted/20 p-3 text-sm",children:[t.jsx("span",{className:"font-medium",children:K?.name}),t.jsxs("span",{className:"ml-2 text-muted-foreground",children:["Experiment #",K?.id]})]}),t.jsxs(ye,{children:[t.jsx(c,{disabled:V.isPending,variant:"outline",onClick:()=>X(null),children:"취소"}),t.jsxs(c,{disabled:V.isPending,variant:"destructive",onClick:()=>K&&V.mutate(K),children:[V.isPending?t.jsx(ge,{className:"animate-spin"}):t.jsx($e,{}),"삭제"]})]})]})})]})}const en=wt;export{en as Component,wt as ExperimentPage};
