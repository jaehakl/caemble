const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-B4p7Ksuz.js","assets/main-Br6dnoM2.js","assets/modulepreload-polyfill-B5Qt9EMX.js","assets/main-VQ-UR0WN.css","assets/index-CXkKwxiP.css"])))=>i.map(i=>d[i]);
import{_ as i}from"./main-Br6dnoM2.js";import{an as d}from"./PageHeader-BYGyVKET.js";function y(n){return new Worker("/assets/editor.worker-ClX6fd1r.js",{type:"module",name:n?.name})}function s(n){return new Worker("/assets/ts.worker-BA62zYty.js",{type:"module",name:n?.name})}const l=`// @caemble/core declaration version: 0.2.0
export type Tensor = number | readonly Tensor[]
export type Vars = Readonly<Record<string, Tensor>>
export type Vec3 = readonly [number, number, number]
export type CartesianBasis = readonly [Vec3, Vec3, Vec3]
export type Rotation = Readonly<{ axis: Vec3; angle: number }>
export type GeometryGroupMap = Readonly<Record<string, readonly string[]>>
export type VarsSchemaEntry = Readonly<{
  min: Tensor
  max: Tensor
}>
export type ExperimentTarget = \`\${'experiment' | 'task'}.\${'geometry' | 'surface'}.\${string}\`
export type DataDType =
  | 'bool'
  | 'string'
  | 'int8'
  | 'int16'
  | 'int32'
  | 'int64'
  | 'uint8'
  | 'uint16'
  | 'uint32'
  | 'uint64'
  | 'float16'
  | 'float32'
  | 'float64'
export type FloatDataDType = Extract<DataDType, \`float\${number}\`>
export type NonFloatDataDType = Exclude<DataDType, FloatDataDType>
export type IntegerDataDType = Exclude<NonFloatDataDType, 'bool' | 'string'>
export type UcumUnit = string
// <generated:quantity-kind-types>
// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface CatalogQuantityKindMap {}
export type QuantityKindName = keyof CatalogQuantityKindMap extends never ? string : keyof CatalogQuantityKindMap
export type QuantityKindDomain = string
export type QuantityKindNameForDomain<Domain extends QuantityKindDomain> = keyof CatalogQuantityKindMap extends never
  ? string & { readonly __domain?: Domain }
  : {
      [Name in keyof CatalogQuantityKindMap]: CatalogQuantityKindMap[Name]['domain'] extends Domain ? Name : never
    }[keyof CatalogQuantityKindMap]
export type TensorQuantityKindName = keyof CatalogQuantityKindMap extends never
  ? string
  : {
      [Name in keyof CatalogQuantityKindMap]: CatalogQuantityKindMap[Name]['tensorOrder'] extends 0 ? never : Name
    }[keyof CatalogQuantityKindMap]
export type ScalarQuantityKindName = keyof CatalogQuantityKindMap extends never
  ? string
  : {
      [Name in keyof CatalogQuantityKindMap]: CatalogQuantityKindMap[Name]['tensorOrder'] extends 0 ? Name : never
    }[keyof CatalogQuantityKindMap]
export type ApplicableUnit<Name extends QuantityKindName> = Name extends keyof CatalogQuantityKindMap
  ? CatalogQuantityKindMap[Name]['applicableUnits'][number]
  : UcumUnit
// </generated:quantity-kind-types>
type QuantityBasisMetadata<Name extends QuantityKindName> = keyof CatalogQuantityKindMap extends never
  ? Readonly<{ basis?: CartesianBasis }>
  : [Name] extends [ScalarQuantityKindName]
    ? Readonly<{ basis?: never }>
    : [Name] extends [TensorQuantityKindName]
      ? Readonly<{ basis?: CartesianBasis }>
      : Readonly<{ basis?: CartesianBasis }>
export type QuantityMetadata<Name extends QuantityKindName = QuantityKindName> = Readonly<{
  unit: ApplicableUnit<Name>
  quantityKind: Name
}> &
  QuantityBasisMetadata<Name>
type DataSchemaAxisBase = Readonly<{
  length?: number
  name?: string
  ticks?: readonly (number | string)[]
}>
export type DataSchemaAxis = DataSchemaAxisBase &
  Readonly<{ unit: UcumUnit; quantityKind: ScalarQuantityKindName } | { unit?: never; quantityKind?: never }>
export type DataAxis = DataSchemaAxis & Readonly<{ length: number }>
type DataTypeMetadata = Readonly<
  | ({
      dtype: FloatDataDType
    } & (QuantityMetadata<ScalarQuantityKindName> | QuantityMetadata<TensorQuantityKindName>))
  | {
      dtype: NonFloatDataDType
      unit?: never
      quantityKind?: never
      basis?: never
    }
>
export type DataSchema = Readonly<{
  axes?: readonly DataSchemaAxis[]
}> &
  DataTypeMetadata
export type DataValueDescriptor = Readonly<{
  axes?: readonly DataAxis[]
  value: boolean | string | number | readonly unknown[]
}> &
  DataTypeMetadata
export type MatrixValue = readonly (readonly number[])[]
export type ScalarValue = boolean | string | number
export type ExperimentParameter = ScalarValue | DataValueDescriptor
export type ExperimentParameters = Readonly<Record<string, ExperimentParameter>>
export type RecordedDataResultAxis = DataSchemaAxis
export type RecordedDataResult = DataSchema
export type RecordedDataAxis = Readonly<{
  ticks?: readonly (number | string)[]
}>
export type DataTensor = Readonly<{
  shape: readonly number[]
  axes?: readonly RecordedDataAxis[]
  storage:
    | Readonly<{ kind: 'inline'; value: unknown }>
    | Readonly<{ kind: 'attachments'; ids: readonly string[]; byteLength: number }>
    | Readonly<{ kind: 'base64'; data: string; byteLength: number }>
}>
export type PersistedDataTensor = DataTensor & Readonly<{ tensorEncodingVersion: 1 }>
export type LegacyRecordedDataTensor = Readonly<{
  value: boolean | string | number | readonly unknown[]
  axes?: readonly RecordedDataAxis[]
}>
export type RecordedDataTensor = DataTensor | PersistedDataTensor | LegacyRecordedDataTensor
export type RecordedData = Readonly<Record<string, RecordedDataTensor>>
export type RecordedDataSpec = RecordedDataResult
export type ResolvedDataSchema = RecordedDataSpec & Readonly<{ tensorOrder: number }>

export type BoxAttributes = Readonly<{
  size: Vec3
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
}>
export type BooleanAttributes = Readonly<{
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
  children?: unknown
}>

export type CylinderAttributes = Readonly<{
  radius: number
  radius_2?: number
  height: number
  segments?: number
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
}>

export type CurvedEdgeCylinderFourierMode = Readonly<{
  amplitude: number
  phase: number
}>
export type CurvedEdgeCylinderTaylorCurve = Readonly<{
  origin: number
  coefficients: readonly number[]
}>
export type CurvedEdgeCylinderAttributes = Readonly<{
  height: number
  azimuthalCurve: readonly CurvedEdgeCylinderFourierMode[]
  verticalCurve: CurvedEdgeCylinderTaylorCurve
  azimuthalSegments?: number
  verticalSegments?: number
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
}>

export type CurvedSurfaceSphereFourierMode = Readonly<{
  amplitude: number
  phase: number
}>
export type CurvedSurfaceSphereAttributes = Readonly<{
  azimuthalCurve: readonly CurvedSurfaceSphereFourierMode[]
  polarCurve: readonly CurvedSurfaceSphereFourierMode[]
  azimuthalSegments?: number
  polarSegments?: number
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
}>

export type SphereAttributes = Readonly<{
  radius: number
  segments?: number
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
}>

export type FiberFourierMode = Readonly<{ amplitude: number; phase: number }>
export type FiberHelix = Readonly<{
  turns: number
  phase?: number
  radius: number | ((u: number, theta: number) => number)
}>
export type FiberAttributes = Readonly<{
  from: Vec3
  to: Vec3
  basePath?: (t: number) => Vec3
  radius: number | ((s: number) => number)
  helix?: FiberHelix
  fourier?: readonly FiberFourierMode[]
  envelopePower?: number
  up?: Vec3
  pathSegments?: number
  radialSegments?: number
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
}>

export type ArrayAttributes = Readonly<{
  shape: readonly [number, number, number]
  period: Vec3
  axes?: Readonly<{ x: Vec3; y: Vec3; z: Vec3 }>
  inject?: Readonly<Record<string, Tensor | Readonly<{ axis: Tensor; angle: Tensor }>>>
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
  children?: unknown
}>

export type ShellAttributes = Readonly<{
  offsets: Readonly<Record<string, number>>
  pos?: Vec3
  rotate?: Rotation
  scale?: Vec3
  children?: unknown
}>

export type GeometryAttributes<P extends object = object> = Readonly<
  P & {
    id: string
    materials?: Readonly<Record<string, Material | undefined>>
    pos?: Vec3
    rotate?: Rotation
    scale?: Vec3
    children?: unknown
  }
>
export type Geometry<P extends object = object> = (props: GeometryAttributes<P>) => unknown

// <generated:material-catalog-types>
// Catalog keys are augmented in memory from the active Solver runtime slice.
// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface MaterialPropertyQuantityKindMap {}
export type MaterialPropertyKey = keyof MaterialPropertyQuantityKindMap extends never
  ? string
  : keyof MaterialPropertyQuantityKindMap
export type MaterialPropertyQuantityKind<Key extends MaterialPropertyKey> =
  Key extends keyof MaterialPropertyQuantityKindMap ? MaterialPropertyQuantityKindMap[Key] : QuantityKindName
export type MaterialPropertyDefinitionFor<Key extends MaterialPropertyKey> = Readonly<{
  key: Key
  quantity_kind: MaterialPropertyQuantityKind<Key>
}>

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface MaterialModelDefinitionMap {}
export type MaterialModelKey = keyof MaterialModelDefinitionMap extends never
  ? string
  : keyof MaterialModelDefinitionMap
export type MaterialModelDefinitionFor<Key extends MaterialModelKey> = Key extends keyof MaterialModelDefinitionMap
  ? MaterialModelDefinitionMap[Key]
  : Readonly<{
      key: Key
      kind: 'sampled_relation'
      input: Readonly<{ quantity_kind: QuantityKindName }>
      output: Readonly<{ quantity_kind: QuantityKindName }>
      minimum_samples: number
      shared_basis: boolean
    }>
export type MaterialCatalogKey = MaterialPropertyKey | MaterialModelKey

type MaterialAuthoringBasis<Name extends QuantityKindName> = Name extends ScalarQuantityKindName
  ? Readonly<{ basis?: never }>
  : Readonly<{ basis?: CartesianBasis }>
type MaterialNormalizedBasis<Name extends QuantityKindName> = Name extends ScalarQuantityKindName
  ? Readonly<{ basis?: never }>
  : Readonly<{ basis: CartesianBasis }>

export type MaterialDataValueDescriptor<Key extends MaterialPropertyKey = MaterialPropertyKey> =
  Key extends MaterialPropertyKey
    ? Readonly<{
        dtype: FloatDataDType
        value: number | readonly unknown[]
        unit: ApplicableUnit<MaterialPropertyQuantityKind<Key>>
        errorRate?: number
        axes?: never
        quantityKind?: never
      }> &
        MaterialAuthoringBasis<MaterialPropertyQuantityKind<Key>>
    : never

export type NormalizedMaterialDataValueDescriptor<Key extends MaterialPropertyKey = MaterialPropertyKey> =
  Key extends MaterialPropertyKey
    ? Readonly<{
        dtype: FloatDataDType
        value: number | readonly unknown[]
        unit: UcumUnit
        quantityKind: MaterialPropertyQuantityKind<Key>
        errorRate: number
        axes?: never
      }> &
        MaterialNormalizedBasis<MaterialPropertyQuantityKind<Key>>
    : never

type MaterialModelInputQuantityKind<Key extends MaterialModelKey> =
  MaterialModelDefinitionFor<Key>['input']['quantity_kind']
type MaterialModelOutputQuantityKind<Key extends MaterialModelKey> =
  MaterialModelDefinitionFor<Key>['output']['quantity_kind']
export type MaterialQuantitySeries<Name extends QuantityKindName> = Readonly<{
  unit: ApplicableUnit<Name>
  values: readonly unknown[]
}> &
  MaterialAuthoringBasis<Name>
export type MaterialSampledRelation<Key extends MaterialModelKey = MaterialModelKey> = Key extends MaterialModelKey
  ? Readonly<{
      kind: 'sampled_relation'
      input: MaterialQuantitySeries<MaterialModelInputQuantityKind<Key>>
      output: MaterialQuantitySeries<MaterialModelOutputQuantityKind<Key>>
    }>
  : never

export type MaterialVariable = string | MaterialDataValueDescriptor | MaterialSampledRelation
export type MaterialVariables = keyof MaterialPropertyQuantityKindMap extends never
  ? Readonly<Record<string, unknown> & { color?: string; errorRate?: number }>
  : Readonly<
      { [Key in keyof MaterialPropertyQuantityKindMap]?: MaterialDataValueDescriptor<Key> } & {
        [Key in keyof MaterialModelDefinitionMap]?: MaterialSampledRelation<Key>
      } & { color?: string; errorRate?: number }
    >
export type NormalizedMaterialVariables = keyof MaterialPropertyQuantityKindMap extends never
  ? Readonly<Record<string, unknown> & { color?: string }>
  : Readonly<
      { [Key in keyof MaterialPropertyQuantityKindMap]?: NormalizedMaterialDataValueDescriptor<Key> } & {
        [Key in keyof MaterialModelDefinitionMap]?: MaterialSampledRelation<Key>
      } & { color?: string }
    >
export type ResolvedMaterialVariables = NormalizedMaterialVariables
// </generated:material-catalog-types>

export class CadModelError extends Error {
  constructor(message: string)
}

export function normalizeUcumUnit(value: unknown, path: string): UcumUnit
export function convertUcumValue(
  value: number,
  fromUnit: UcumUnit | undefined,
  toUnit: UcumUnit | undefined,
  path?: string,
): number
export function assertUcumUnitComparable(
  unit: UcumUnit | undefined,
  expectedUnit: UcumUnit | undefined,
  path: string,
): void
export function isFloatDType(dtype: DataDType): boolean
export function Mat(diagonal: number, offDiagonal?: number, size?: number): MatrixValue

export class Material {
  constructor(name: string)
  constructor(name: string, variables: MaterialVariables)
  constructor(name: string, sourceVersion: string)
  constructor(name: string, sourceVersion: string, variables: MaterialVariables)
  readonly name: string
  readonly source?: string
  readonly version?: string
  readonly errorRate: number
  readonly variables: NormalizedMaterialVariables
}

export type VarsSchemaDefinition = Readonly<Record<string, Readonly<VarsSchemaEntry>>>

type ShapeSource<Entry extends VarsSchemaEntry> = Entry['min'] extends readonly unknown[] ? Entry['min'] : Entry['max']

type WidenTensor<Value> = Value extends number
  ? number
  : Value extends readonly unknown[]
    ? { readonly [Index in keyof Value]: WidenTensor<Value[Index]> }
    : never

export type InferVars<Schema extends VarsSchemaDefinition> = Readonly<{
  [Key in keyof Schema]: WidenTensor<ShapeSource<Schema[Key]>>
}>

export type ModelContext<Schema extends VarsSchemaDefinition> = Readonly<{
  vars: InferVars<Schema>
}>

export type TaskModelContext = Readonly<{
  vars: Readonly<Vars>
}>

export type KernelIdentity = Readonly<{
  name: string
  version: string
}>

export type ExperimentDefinitionOptions<
  Schema extends VarsSchemaDefinition,
  Recorded extends Readonly<Record<string, RecordedDataSpec>>,
> = Readonly<{
  geometry: (context: ModelContext<Schema>) => unknown
  lengthUnit: UcumUnit
  varsSchema: Schema
  geometryGroup?: GeometryGroupMap
  surfaceGroup?: GeometryGroupMap
  recordedData: Recorded
}>

export type TaskDefinitionOptions<Config> = Readonly<{
  kernel: KernelIdentity
  lengthUnit?: UcumUnit
  geometry?: (context: TaskModelContext) => unknown
  geometryGroup?: GeometryGroupMap
  surfaceGroup?: GeometryGroupMap
  config: (context: TaskModelContext) => Config
}>

export class ExperimentDefinition<
  Schema extends VarsSchemaDefinition = VarsSchemaDefinition,
  Recorded extends Readonly<Record<string, RecordedDataSpec>> = Readonly<Record<string, RecordedDataSpec>>,
> {
  constructor(options: ExperimentDefinitionOptions<Schema, Recorded>)
  readonly apiVersion: 6
  readonly documentType: 'experiment'
  readonly varsSchema: Schema
  readonly lengthUnit: UcumUnit
  readonly geometryGroup: GeometryGroupMap
  readonly surfaceGroup: GeometryGroupMap
  readonly recordedData: Recorded
}

export class TaskDefinition<Config = unknown> {
  constructor(options: TaskDefinitionOptions<Config>)
  readonly apiVersion: 6
  readonly documentType: 'task'
  readonly kernel: KernelIdentity
  readonly lengthUnit?: UcumUnit
  readonly geometryGroup: GeometryGroupMap
  readonly surfaceGroup: GeometryGroupMap
}

export declare function experiment<
  const Schema extends VarsSchemaDefinition,
  const Recorded extends Readonly<Record<string, RecordedDataSpec>>,
>(options: ExperimentDefinitionOptions<Schema, Recorded>): ExperimentDefinition<Schema, Recorded>

export declare function defineTask<const Config>(options: TaskDefinitionOptions<Config>): TaskDefinition<Config>

export type SimulationProgramManifest = Readonly<{
  formatVersion: 5
  simulationApiVersion: 3
  pythonSource: string
  tasks: Readonly<
    Record<
      string,
      Readonly<{
        kernel: KernelIdentity
        config: unknown
      }>
    >
  >
  recordedData: Readonly<Record<string, ResolvedDataSchema>>
}>

export type ExternalVars = Readonly<Record<string, Tensor>>
`,p=`// Generated by scripts/generate-cad-api.mjs from elements/manifest.json. Do not edit.
import type {
  ArrayAttributes,
  BooleanAttributes,
  BoxAttributes,
  CurvedEdgeCylinderAttributes,
  CurvedSurfaceSphereAttributes,
  CylinderAttributes,
  FiberAttributes,
  ShellAttributes,
  SphereAttributes,
} from '@caemble/core'

declare global {
  function h(type: unknown, attributes: unknown, ...children: unknown[]): unknown
  function Fragment(props: { children?: unknown }): unknown

  namespace JSX {
    interface IntrinsicElements {
      box: BoxAttributes
      cylinder: CylinderAttributes
      curvedEdgeCylinder: CurvedEdgeCylinderAttributes
      sphere: SphereAttributes
      curvedSurfaceSphere: CurvedSurfaceSphereAttributes
      fiber: FiberAttributes
      shell: ShellAttributes
      array: ArrayAttributes
      union: BooleanAttributes
      subtract: BooleanAttributes
      intersect: BooleanAttributes
    }
  }
}

export {}
`;let r=!1;function u(n){if(r)return;const e=n.typescript;e.typescriptDefaults.setCompilerOptions({target:e.ScriptTarget.ES2020,module:e.ModuleKind.CommonJS,moduleResolution:e.ModuleResolutionKind.NodeJs,allowNonTsExtensions:!0,jsx:e.JsxEmit.React,jsxFactory:"h",jsxFragmentFactory:"Fragment",strict:!0,noEmit:!1,noEmitOnError:!0,sourceMap:!0,inlineSources:!0}),e.typescriptDefaults.setEagerModelSync(!0),e.typescriptDefaults.addExtraLib(l,"file:///node_modules/@caemble/core/index.d.ts"),e.typescriptDefaults.addExtraLib(p,"file:///node_modules/@caemble/core/cad-jsx.d.ts"),d(n),r=!0}let t=null;function o(){if(!t){const n={getWorker(e,a){return a==="typescript"||a==="javascript"?new s:new y}};globalThis.MonacoEnvironment=n,t=i(()=>import("./index-B4p7Ksuz.js").then(e=>e.i),__vite__mapDeps([0,1,2,3,4])).then(e=>(u(e),e))}return t}const x=Object.freeze(Object.defineProperty({__proto__:null,loadMonaco:o},Symbol.toStringTag,{value:"Module"})),M=Object.freeze(Object.defineProperty({__proto__:null,loadMonaco:o},Symbol.toStringTag,{value:"Module"}));export{M as a,x as m};
