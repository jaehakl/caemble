import{c as t,j as e,B as s,L as c}from"./main-CUvazRVe.js";/**
 * @license lucide-react v1.25.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],a=t("arrow-left",r);/**
 * @license lucide-react v1.25.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["path",{d:"m13.5 8.5-5 5",key:"1cs55j"}],["path",{d:"m8.5 8.5 5 5",key:"a8mexj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]],o=t("search-x",n);function x(){return e.jsx("div",{className:"flex min-h-dvh items-center justify-center bg-background px-5 py-16 text-center text-foreground",children:e.jsxs("div",{children:[e.jsx(o,{className:"mx-auto size-12 text-primary"}),e.jsx("p",{className:"mt-5 text-xs font-semibold tracking-[0.2em] text-primary uppercase",children:"404"}),e.jsx("h2",{className:"mt-2 text-3xl font-semibold",children:"페이지를 찾을 수 없습니다"}),e.jsx("p",{className:"mt-3 text-muted-foreground",children:"주소를 확인하거나 CAE Workbench에서 다시 시작해 주세요."}),e.jsx(s,{asChild:!0,className:"mt-6",children:e.jsxs(c,{to:"/",children:[e.jsx(a,{}),"CAE Workbench로"]})})]})})}export{a as A,x as N};
