import{q as e,Q as n}from"./runtime-Ygud-gGu.js";const i=Object.freeze(Object.fromEntries(Object.keys(e).map(t=>[t,new n(t)])));export{i as Q};
