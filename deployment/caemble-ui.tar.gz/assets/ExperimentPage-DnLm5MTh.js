import{u as it,d as at,a as lt,k as ot,T as ct,U as ut,r as n,z as Le,e as _e,t as k,l as xe,j as t,B as u,i as fe,x as dt,g as Y}from"./main-8zfCNhGt.js";import{D as mt}from"./DataTable-BOlkcqA4.js";import{B as Ie}from"./badge-jwdPDp0B.js";import{C as pt}from"./card-v0rhrxDh.js";import{D as he,a as ge,b as ve,c as be,d as je,e as Ee}from"./dialog-CTUoheeG.js";import{I as qe}from"./input-DpEng4Wc.js";import{r as xt,u as ft,E as ze,S as ht,s as gt}from"./measurement-return-bzBtKvNl.js";import{r as vt,P as Ae}from"./resolveMaterials-CGpT6NQH.js";import{u as bt,C as jt}from"./useCadWorkspace-BaOY0UeX.js";import{S as Et}from"./StructureExperimentViewer-DlPLTwF9.js";import"./core-B4lC9ccM.js";import"./index-Bf40e79f.js";import"./runtime-CCmOT4OH.js";import{f as yt,c as ye}from"./document-0gOELFzm.js";import"./index-C4hnMESb.js";import{C as Ct}from"./code-xml-DxZs4Cu7.js";import{A as Ce}from"./arrow-left-DRFXChJQ.js";import{P as Se}from"./plus-DkAm5fSN.js";import{S as St}from"./search-C7FAwet7.js";import{T as Ve}from"./trash-2-B50jKNOZ.js";import"./preload-helper-CS1eXPs2.js";import"./table-UGBRsTfB.js";import"./protocol-BncrCqac.js";import"./client-DrIz7E1g.js";const kt=`import { experiment } from '@caemble/core'

export default experiment({
  varsSchema: {
    sourceVoltage: { min: 1, max: 1 },
    referenceVoltage: { min: 0, max: 0 },
  },

  recordedData: {
    measuredCurrent: {
      dtype: 'float64',
      unit: 'A',
      quantityKind: 'electromagnetism.ElectricCurrent',
    },
  },
})
`,Nt=`import { defineTask } from '@caemble/core'

function ExperimentDevice() {
  return <box size={[1, 1, 1]} />
}

export default defineTask({
  kernel: { name: 'dc-current-density', version: '0.0.0' },
  lengthUnit: 'mm',
  geometry: () => <ExperimentDevice id="experiment-device" />,
  config: ({ vars }) => ({
    parameters: {
      relativeTolerance: {
        dtype: 'float64',
        value: 1e-8,
        unit: '{fraction}',
        quantityKind: 'DimensionlessRatio',
      },
      maxIterations: 2000,
    },
    initializations: [
      {
        methodId: 'dc.voxel-grid',
        target: ['structure.geometry.conductor'],
        parameters: {
          gridShape: { dtype: 'int32', axes: [{ length: 3 }], value: [100, 41, 41] },
        },
      },
    ],
    boundaryConditions: [
      {
        methodId: 'dc.source-potential',
        target: ['structure.surface.sourceTerminal'],
        parameters: {
          voltage: {
            dtype: 'float64',
            value: vars.sourceVoltage,
            unit: 'mV',
            quantityKind: 'electromagnetism.Voltage',
          },
        },
      },
      {
        methodId: 'dc.reference-potential',
        target: ['structure.surface.referenceTerminal'],
        parameters: {
          voltage: {
            dtype: 'float64',
            value: vars.referenceVoltage,
            unit: 'mV',
            quantityKind: 'electromagnetism.Voltage',
          },
        },
      },
    ],
    outputs: [
      {
        key: 'currentDensity',
        methodId: 'dc.current-density',
        target: ['structure.geometry.conductor'],
        parameters: {
          crossSectionPosition: {
            dtype: 'float64',
            value: 0.35,
            unit: '{fraction}',
            quantityKind: 'DimensionlessRatio',
          },
        },
      },
      {
        key: 'totalCurrent',
        methodId: 'dc.total-current',
        target: ['structure.geometry.conductor'],
        parameters: {
          crossSectionPosition: {
            dtype: 'float64',
            value: 0.35,
            unit: '{fraction}',
            quantityKind: 'DimensionlessRatio',
          },
        },
      },
    ],
  }),
})
`,Dt=`async def simulate(*, sim, tasks, vars):
    electric = await sim.run(tasks["electric"])
    await sim.record(
        "measuredCurrent",
        electric["artifacts"]["totalCurrent"],
    )
    sim.release(electric["artifacts"]["currentDensity"])
    return electric["state"]
`,wt=yt({"experiment.tsx":kt,"simulate.py":Dt,"tasks/electric.tsx":Nt}),Be=44;function Pt(a){const l=Number(a);return Number.isSafeInteger(l)&&l>0?l:null}function Z(a,l){const m=Date.parse(l.updated_at??"")-Date.parse(a.updated_at??"");return Number.isNaN(m)||m===0?l.id-a.id:m}function Rt(a,l){return!!(l&&(l.roles.includes("admin")||a.user_id===l.id))}function Ke(a,l){const m=Math.max(25,360/l*100),h=Math.min(75,(l-320)/l*100);return Math.min(h,Math.max(m,a))}function Oe({canManage:a,childrenByParent:l,depth:m,onDelete:h,onNavigate:i,row:c,selectedId:d}){const y=l.get(c.id)??[];return t.jsxs("li",{children:[t.jsxs("div",{className:`flex items-center gap-2 border-b px-2 py-2 ${c.id===d?"bg-orange-50":"hover:bg-muted/50"}`,style:{paddingLeft:`${m*18+8}px`},children:[t.jsxs("button",{className:"min-w-0 flex-1 text-left",type:"button",onClick:()=>i(c),children:[t.jsxs("span",{className:"flex items-center gap-2",children:[t.jsx("span",{className:"truncate text-sm font-medium",children:c.name}),m===0?t.jsx(Ie,{children:"root"}):null,y.length===0?t.jsx(Ie,{children:"leaf"}):null]}),t.jsx("span",{className:"mt-0.5 block truncate text-xs text-muted-foreground",children:c.description||`Experiment #${c.id}`})]}),a(c)?t.jsx(u,{"aria-label":`${c.name} 삭제`,className:"text-destructive hover:text-destructive",size:"icon",title:"Experiment 삭제",variant:"ghost",onClick:()=>h(c),children:t.jsx(Ve,{})}):null]}),y.length>0?t.jsx("ul",{children:y.map(p=>t.jsx(Oe,{canManage:a,childrenByParent:l,depth:m+1,onDelete:h,onNavigate:i,row:p,selectedId:d},p.id))}):null]})}function Mt({canManage:a,onDelete:l,onNavigate:m,rows:h,selected:i}){const{childrenByParent:c,root:d}=n.useMemo(()=>{const y=new Map(h.map(v=>[v.id,v])),p=new Map;h.forEach(v=>{if(v.parent_id==null||!y.has(v.parent_id))return;const V=p.get(v.parent_id)??[];V.push(v),p.set(v.parent_id,V)}),p.forEach(v=>v.sort(Z));let g=i;const T=new Set;for(;g.parent_id!=null&&y.has(g.parent_id)&&!T.has(g.id);)T.add(g.id),g=y.get(g.parent_id);return{childrenByParent:p,root:g}},[h,i]);return t.jsxs("div",{className:"h-full overflow-auto bg-background",children:[t.jsxs("div",{className:"border-b bg-muted/20 px-4 py-3",children:[t.jsxs("div",{className:"flex items-center gap-2 text-sm font-semibold",children:[t.jsx(dt,{className:"size-4 text-primary"}),"전체 계보"]}),t.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"보이는 root부터 모든 후손을 표시합니다."})]}),t.jsx("ul",{children:t.jsx(Oe,{canManage:a,childrenByParent:c,depth:0,onDelete:l,onNavigate:m,row:d,selectedId:i.id})})]})}function Tt(){const a=it(),l=at(),m=lt(),h=ot(),{currentExperimentId:i,currentStructureId:c,setCurrentExperimentId:d,setCurrentStructureId:y}=ct(),[p,g]=ut(),[T,v]=n.useState(""),[V,He]=n.useState(!1),[C,O]=n.useState(null),[ee,H]=n.useState(null),[$e,$]=n.useState(null),[q,F]=n.useState(null),[te,ke]=n.useState(""),[Ne,De]=n.useState(""),[w,z]=n.useState(null),[ne,A]=n.useState(null),[Fe,Q]=n.useState(!1),[re,U]=n.useState(!1),[se,J]=n.useState(!1),[B,W]=n.useState(null),[we,ie]=n.useState(Be),Pe=n.useRef(!1),ae=n.useRef(null),[R]=n.useState(()=>xt(l.state)),Qe=n.useMemo(()=>({...Le("visible"),limit:null}),[]),L=_e({queryKey:["experiments","visible"],queryFn:()=>Y.Experiment.listRows(Qe)}),N=_e({queryKey:["structures","visible",c],queryFn:async()=>c===null?null:(await Y.Structure.listRows(Le("visible",[c]))).items[0]??null,enabled:c!==null}),b=n.useMemo(()=>(L.data?.items??[]).filter(e=>e.id!==void 0).sort(Z),[L.data?.items]),j=b.find(e=>e.id===i)??null,le=n.useMemo(()=>N.data?ye("structure",N.data.code):null,[N.data]),_=n.useCallback(e=>Rt(e,a.user),[a.user]),X=!!(j&&_(j)),D=!!(C&&C.kind==="experiment"&&(ee===null||JSON.stringify(C.sourceBundle)!==JSON.stringify(ee))),Re=n.useMemo(()=>{const e=new Set(b.map(f=>f.id)),r=new Set(b.flatMap(f=>f.parent_id!=null&&e.has(f.parent_id)?[f.parent_id]:[])),s=T.trim().toLocaleLowerCase();return b.filter(f=>!r.has(f.id)&&(!s||[f.name,f.description??""].some(st=>st.toLocaleLowerCase().includes(s))))},[T,b]),S=n.useCallback(e=>{g(r=>{const s=new URLSearchParams(r);return e?s.set("experiment",String(e)):s.delete("experiment"),s},{replace:!0})},[g]),E=n.useCallback(e=>{He(e),!(!R&&!p.has("mode"))&&g(r=>{const s=new URLSearchParams(r);return s.set("mode",e?"code":"list"),s},{replace:!0})},[R,p,g]),P=n.useCallback(e=>{O(ye("experiment",e.source_bundle)),d(e.id),H(e.source_bundle),$(null),S(e.id)},[d,S]),Ue=n.useCallback(()=>{O(null),d(null),H(null),$(null),E(!1),S(null)},[d,S,E]),oe=n.useCallback(()=>{O(ye("experiment",wt)),d(null),H(null),$(null),E(!0),S(null)},[d,S,E]);n.useEffect(()=>{if(Pe.current||!L.isSuccess)return;Pe.current=!0;const e=p.get("experiment"),r=e===null?i:Pt(e);if(r===null){e!==null&&(k.error("Experiment를 찾을 수 없습니다."),d(null),S(null));return}const s=b.find(f=>f.id===r);if(!s){k.error("Experiment를 찾을 수 없습니다."),d(null),S(null);return}P(s),E(p.get("mode")==="code")},[P,L.isSuccess,b,p,i,d,S,E]),n.useEffect(()=>{c!==null&&(N.isSuccess&&N.data===null?(k.error("현재 Structure를 찾을 수 없습니다."),y(null)):N.isError&&k.error("현재 Structure를 불러오지 못했습니다."))},[c,N.data,N.isError,N.isSuccess,y]);const Je=n.useCallback(e=>vt(e,null),[]),We=n.useCallback(e=>O(e),[]),{experimentDocument:o,simulation:I,structureDocument:x}=bt(le,C,void 0,a.isAuthenticated?We:void 0,void 0,void 0,Je,"standard",a.isAuthenticated),ce=n.useCallback(async()=>{await Promise.all([h.invalidateQueries({queryKey:["experiments"]}),h.invalidateQueries({queryKey:["work","experiments"]})])},[h]),G=xe({mutationFn:({description:e,name:r,row:s})=>Y.Experiment.upsertRow([{id:s.id,user_id:s.user_id,parent_id:s.parent_id,name:r.trim(),description:e.trim()||null,source_bundle:s.source_bundle}]),onSuccess:async()=>{F(null),await ce(),k.success("Experiment 정보를 저장했습니다.")},onError:e=>k.error(e instanceof Error?e.message:"Experiment 정보를 저장하지 못했습니다.")}),ue=xe({mutationFn:({forceRoot:e,values:r})=>{if(!C)throw new Error("저장할 Experiment source가 없습니다.");if(!a.isAuthenticated)throw new Error("로그인이 필요합니다.");if(!e&&(!j||!_(j)))throw new Error("이 Experiment를 수정할 권한이 없습니다.");return gt({document:C,forceRoot:e,kind:"experiment",savedCode:null,savedSourceBundle:ee,selectedId:i,values:r})},onSuccess:async({action:e,id:r,sourceBundle:s},{forceRoot:f})=>{d(r),H(s??null),S(r),z(null),await ce(),k.success(f?"현재 Experiment를 새 root로 저장했습니다.":e==="forked"?"구조 변경을 새 child Experiment로 저장했습니다.":"Experiment를 저장했습니다.")},onError:e=>k.error(e instanceof Error?e.message:"Experiment를 저장하지 못했습니다.")}),K=xe({mutationFn:async e=>(await Y.Experiment.deleteRows([e.id]),e),onSuccess:async e=>{const r=e.parent_id==null?b.filter(s=>s.parent_id===e.id).sort(Z)[0]??null:b.find(s=>s.id===e.parent_id)??b.filter(s=>s.parent_id===e.id).sort(Z)[0]??null;W(null),i===e.id&&(r?P(r):Ue()),await ce(),k.success("Experiment를 삭제하고 기존 child의 계보를 재연결했습니다.")},onError:e=>k.error(e instanceof Error?e.message:"Experiment를 삭제하지 못했습니다.")}),Me=n.useCallback((e,r)=>{if(e.id===i){r&&o.handleReroll();return}if(D){A(e);return}P(e)},[P,D,i,o]),Xe=n.useCallback(()=>{if(D){U(!0);return}oe()},[D,oe]),de=n.useCallback(e=>{if(e.id===i){E(!0);return}if(D){A(e),Q(!0);return}P(e),E(!0)},[P,D,i,E]),me=n.useCallback(()=>{R&&m(ft(R,"experiment",i))},[R,m,i]),Te=n.useCallback(()=>{if(D){J(!0);return}me()},[D,me]),pe=n.useCallback(e=>{F(e),ke(e.name),De(e.description??"")},[]),Ge=n.useMemo(()=>[{accessorKey:"name",header:"Name",cell:({row:e})=>t.jsxs("div",{className:"min-w-40",children:[t.jsx("p",{className:"font-medium",children:e.original.name}),t.jsxs("p",{className:"mt-1 text-xs text-muted-foreground",children:["Experiment #",e.original.id]})]})},{accessorKey:"description",header:"Description",cell:({row:e})=>t.jsx("p",{className:"line-clamp-2 max-w-xl text-sm text-muted-foreground",children:e.original.description||"—"})},{id:"actions",header:"",cell:({row:e})=>{const r=_(e.original);return t.jsxs("div",{className:"flex items-center justify-end gap-1",children:[t.jsx(u,{"aria-label":`${e.original.name} 코드 에디터 열기`,size:"icon",title:"코드 에디터 열기",variant:"ghost",onClick:s=>{s.stopPropagation(),de(e.original)},onDoubleClick:s=>s.stopPropagation(),children:t.jsx(Ct,{})}),t.jsx(u,{"aria-label":`${e.original.name} ${r?"정보 편집":"정보 보기"}`,size:"icon",title:r?"이름과 설명 편집":"이름과 설명 보기",variant:"ghost",onClick:s=>{s.stopPropagation(),pe(e.original)},onDoubleClick:s=>s.stopPropagation(),children:r?t.jsx(Ae,{}):t.jsx(ze,{})})]})}}],[_,pe,de]),Ye=n.useMemo(()=>C?{scene:o.scene,sceneHash:o.sceneHash,taskScenes:o.taskScenes,taskSceneHashes:o.taskSceneHashes,variables:o.variables}:null,[C,o.scene,o.sceneHash,o.taskSceneHashes,o.taskScenes,o.variables]),Ze=n.useMemo(()=>le?{scene:x.scene,sceneHash:x.sceneHash,variables:x.variables}:null,[le,x.scene,x.sceneHash,x.variables]),et=n.useCallback(e=>{e.includes("structure")&&x.handleRenderStart(),e.includes("experiment")&&o.handleRenderStart()},[o,x]),tt=n.useCallback(e=>{e.includes("structure")&&x.handleRenderEnd(),e.includes("experiment")&&o.handleRenderEnd()},[o,x]),nt=n.useCallback((e,r)=>{r.includes("structure")&&x.handleRenderError(e),r.includes("experiment")&&o.handleRenderError(e)},[o,x]),rt={name:j?.name??"새 Experiment",description:j?.description??""},M=!!(q&&_(q));return t.jsxs("section",{"aria-label":"Experiment 관리 페이지",className:"flex h-full min-h-0 flex-col overflow-auto lg:overflow-hidden",children:[t.jsxs("div",{className:"grid min-h-0 flex-1 grid-cols-1 lg:h-full lg:grid-cols-[minmax(360px,var(--workspace-left-width))_5px_minmax(0,1fr)] lg:overflow-hidden",ref:ae,style:{"--workspace-left-width":`${we}%`},children:[t.jsx("div",{className:"min-h-[420px] min-w-0 border-b lg:h-full lg:min-h-0 lg:overflow-hidden lg:border-b-0",children:V&&C?t.jsxs("div",{className:"flex h-full min-h-0 flex-col bg-background",children:[t.jsxs("div",{className:"flex min-h-14 shrink-0 flex-wrap items-center gap-2 border-b px-3 py-2",children:[t.jsxs(u,{size:"sm",variant:"ghost",onClick:()=>E(!1),children:[t.jsx(Ce,{}),"목록"]}),R?t.jsxs(u,{size:"sm",variant:"outline",onClick:Te,children:[t.jsx(Ce,{}),"Measurement로 돌아가기"]}):null,t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsxs("div",{className:"flex min-w-0 items-center gap-1",children:[t.jsx("p",{className:"min-w-0 truncate text-sm font-semibold",children:j?.name??"새 Experiment"}),j?t.jsx(u,{"aria-label":`${j.name} ${X?"정보 편집":"정보 보기"}`,className:"size-6",size:"icon",title:X?"이름과 설명 편집":"이름과 설명 보기",variant:"ghost",onClick:()=>pe(j),children:X?t.jsx(Ae,{}):t.jsx(ze,{})}):null]}),t.jsx("p",{className:"text-xs text-muted-foreground",children:i===null?"저장 전 새 Experiment입니다.":D?"저장되지 않은 코드 변경이 있습니다.":"저장된 코드와 일치합니다."})]}),i===null&&a.isAuthenticated?t.jsxs(u,{size:"sm",onClick:()=>z("create"),children:[t.jsx(Se,{}),"Experiment 생성"]}):X?t.jsx(u,{size:"sm",variant:"outline",onClick:()=>z("save"),children:"Experiment 저장"}):null,i!==null&&a.isAuthenticated?t.jsxs(u,{size:"sm",onClick:()=>z("root"),children:[t.jsx(Se,{}),"새 root로 저장"]}):null]}),t.jsx("div",{className:"min-h-0 flex-1",children:t.jsx(Et,{activeDocumentType:"experiment",structure:null,structureDocument:x,experiment:C,experimentDocument:o,experimentLineage:j?t.jsx(Mt,{canManage:_,rows:b,selected:j,onDelete:W,onNavigate:e=>Me(e,!1)}):null,onActiveDocumentTypeChange:()=>{},onActiveExperimentTaskChange:$})})]}):t.jsxs(pt,{className:"flex h-full min-h-0 flex-col overflow-hidden rounded-none border-0 shadow-none",children:[t.jsxs("div",{className:"border-b bg-muted/20 p-4",children:[t.jsxs("div",{className:"flex items-start justify-between gap-4",children:[t.jsxs("div",{children:[t.jsx("h2",{className:"font-semibold",children:"Experiment"}),t.jsxs("p",{className:"mt-1 text-xs text-muted-foreground",children:[Re.length.toLocaleString()," leaf / ",b.length.toLocaleString()," visible"]})]}),t.jsxs("div",{className:"flex flex-wrap items-center justify-end gap-2",children:[R?t.jsxs(u,{size:"sm",onClick:Te,children:[t.jsx(Ce,{}),"Measurement로 돌아가기"]}):null,a.isAuthenticated?t.jsxs(u,{size:"sm",variant:"outline",onClick:Xe,children:[t.jsx(Se,{}),"새 Experiment 생성"]}):null]})]}),t.jsxs("div",{className:"relative mt-4",children:[t.jsx(St,{className:"pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"}),t.jsx(qe,{"aria-label":"Experiment 검색",className:"pl-9",placeholder:"이름 또는 설명 검색",value:T,onChange:e=>v(e.target.value)})]})]}),t.jsx("div",{className:"min-h-0 flex-1 overflow-auto",children:L.isLoading?t.jsxs("div",{className:"flex min-h-48 items-center justify-center gap-2 text-sm text-muted-foreground",children:[t.jsx(fe,{className:"animate-spin"}),"Experiment 목록을 불러오는 중입니다."]}):L.isError?t.jsx("div",{className:"flex min-h-48 items-center justify-center text-sm text-destructive",children:"Experiment 목록을 불러오지 못했습니다."}):t.jsx(mt,{columns:Ge,data:Re,emptyLabel:"조건에 맞는 leaf Experiment가 없습니다.",getRowKey:e=>String(e.id),selectedKey:i===null?void 0:String(i),onRowClick:e=>Me(e,!0),onRowDoubleClick:de})})]})}),t.jsx("div",{"aria-label":"Experiment 패널과 Viewer 크기 조절","aria-orientation":"vertical","aria-valuemax":75,"aria-valuemin":25,"aria-valuenow":Math.round(we),className:"group hidden cursor-col-resize touch-none items-stretch justify-center bg-muted outline-none hover:bg-neutral-200 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset lg:flex",role:"separator",tabIndex:0,onDoubleClick:()=>ie(Be),onKeyDown:e=>{if(e.key!=="ArrowLeft"&&e.key!=="ArrowRight")return;const r=ae.current?.getBoundingClientRect().width;r&&(e.preventDefault(),ie(s=>Ke(s+(e.key==="ArrowLeft"?-2:2),r)))},onPointerDown:e=>e.currentTarget.setPointerCapture(e.pointerId),onPointerMove:e=>{if(!e.currentTarget.hasPointerCapture(e.pointerId))return;const r=ae.current?.getBoundingClientRect();r&&ie(Ke((e.clientX-r.left)/r.width*100,r.width))},onPointerUp:e=>e.currentTarget.releasePointerCapture(e.pointerId),children:t.jsx("span",{className:"w-px bg-border group-hover:bg-neutral-400"})}),t.jsx(jt,{activeExperimentTaskName:$e,experiment:Ye,recordedData:I.recordedData,simulation:{canRun:I.canRun,cancel:I.cancel,process:I.process,program:o.simulationProgram,run:I.run,stale:I.stale},structure:Ze,onRenderEnd:tt,onRenderError:nt,onRenderStart:et})]}),t.jsx(he,{onOpenChange:e=>!e&&!G.isPending&&F(null),open:q!==null,children:t.jsx(ge,{children:t.jsxs("form",{className:"grid gap-5",onSubmit:e=>{e.preventDefault(),q&&M&&G.mutate({row:q,name:te,description:Ne})},children:[t.jsxs(ve,{children:[t.jsx(be,{children:M?"Experiment 정보 편집":"Experiment 정보"}),t.jsx(je,{children:M?"코드는 변경하지 않고 이름과 설명만 저장합니다.":"이 Experiment는 읽기 전용입니다."})]}),t.jsxs("label",{className:"grid gap-1.5 text-sm font-medium",children:["이름",t.jsx(qe,{autoFocus:M,disabled:!M,maxLength:200,value:te,onChange:e=>ke(e.target.value)})]}),t.jsxs("label",{className:"grid gap-1.5 text-sm font-medium",children:["설명",t.jsx("textarea",{className:"min-h-28 rounded-md border border-input bg-transparent px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60",disabled:!M,maxLength:2e3,value:Ne,onChange:e=>De(e.target.value)})]}),t.jsxs(Ee,{children:[t.jsx(u,{type:"button",variant:"outline",onClick:()=>F(null),children:"닫기"}),M?t.jsxs(u,{disabled:!te.trim()||G.isPending,type:"submit",children:[G.isPending?t.jsx(fe,{className:"animate-spin"}):null,"저장"]}):null]})]})})}),t.jsx(ht,{defaults:rt,description:w==="create"?"기본 Source code를 내 새 root Experiment로 저장합니다.":w==="root"?"현재 Source code를 선택한 Experiment의 parent 없이 내 새 root로 저장합니다.":void 0,kind:"Experiment",open:w!==null,pending:ue.isPending,submitLabel:w==="create"?"Experiment 생성":w==="root"?"새 root로 저장":"Experiment 저장",title:w==="create"?"새 Experiment 생성":w==="root"?"새 Experiment root 저장":"Experiment 저장",onOpenChange:e=>!e&&!ue.isPending&&z(null),onSubmit:async e=>{await ue.mutateAsync({forceRoot:w!=="save",values:e})}}),t.jsx(he,{onOpenChange:e=>{e||(A(null),Q(!1),U(!1),J(!1))},open:ne!==null||re||se,children:t.jsxs(ge,{children:[t.jsxs(ve,{children:[t.jsx(be,{children:"저장되지 않은 변경을 버릴까요?"}),t.jsx(je,{children:se?"Measurement로 돌아가면 현재 Editor의 코드 변경을 복구할 수 없습니다.":re?"새 Experiment를 시작하면 현재 Editor의 코드 변경을 복구할 수 없습니다.":"다른 Experiment로 이동하면 현재 Editor의 코드 변경을 복구할 수 없습니다."})]}),t.jsxs(Ee,{children:[t.jsx(u,{variant:"outline",onClick:()=>{A(null),Q(!1),U(!1),J(!1)},children:"취소"}),t.jsx(u,{variant:"destructive",onClick:()=>{se?me():re?oe():ne&&(P(ne),Fe&&E(!0)),A(null),Q(!1),U(!1),J(!1)},children:"변경 버리고 이동"})]})]})}),t.jsx(he,{onOpenChange:e=>!e&&!K.isPending&&W(null),open:B!==null,children:t.jsxs(ge,{children:[t.jsxs(ve,{children:[t.jsx(be,{children:"Experiment를 삭제할까요?"}),t.jsx(je,{children:"child는 삭제 노드의 parent로 자동 재연결됩니다. 연결된 Setup과 Designer/Predictor Model도 함께 삭제될 수 있습니다."})]}),t.jsxs("div",{className:"rounded-lg border bg-muted/20 p-3 text-sm",children:[t.jsx("span",{className:"font-medium",children:B?.name}),t.jsxs("span",{className:"ml-2 text-muted-foreground",children:["Experiment #",B?.id]})]}),t.jsxs(Ee,{children:[t.jsx(u,{disabled:K.isPending,variant:"outline",onClick:()=>W(null),children:"취소"}),t.jsxs(u,{disabled:K.isPending,variant:"destructive",onClick:()=>B&&K.mutate(B),children:[K.isPending?t.jsx(fe,{className:"animate-spin"}):t.jsx(Ve,{}),"삭제"]})]})]})})]})}const rn=Tt;export{rn as Component,Tt as ExperimentPage};
