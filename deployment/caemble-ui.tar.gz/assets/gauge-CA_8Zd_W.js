import{c as a}from"./tooltip-Bx6Vt5dU.js";const e=[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]],c=a("gauge",e);export{c as G};
