class e extends Error{constructor(r){super(r),this.name="CadModelError"}}export{e as C};
