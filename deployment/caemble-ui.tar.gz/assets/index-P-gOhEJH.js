import{q as e,Q as n}from"./runtime-D6bdy4D9.js";const i=Object.freeze(Object.fromEntries(Object.keys(e).map(t=>[t,new n(t)])));export{i as Q};
