import{j as t,a}from"./main-C9Gx4t9C.js";function m({className:e,...s}){return t.jsx("div",{className:a("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
