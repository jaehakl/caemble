import{j as t,a}from"./main-C7cZwC-n.js";function m({className:e,...s}){return t.jsx("div",{className:a("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
