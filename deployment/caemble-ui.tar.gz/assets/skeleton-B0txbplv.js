import{j as t,a}from"./main-BRT_nPWa.js";function m({className:e,...s}){return t.jsx("div",{className:a("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
