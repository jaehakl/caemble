const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-u096at48.js","assets/main-DG2PnYOw.js","assets/modulepreload-polyfill-B5Qt9EMX.js","assets/main-ClV7keXC.css","assets/index-CXkKwxiP.css"])))=>i.map(i=>d[i]);
import{_ as i}from"./main-DG2PnYOw.js";function d(n){return new Worker("/assets/editor.worker-ClX6fd1r.js",{type:"module",name:n?.name})}function s(n){return new Worker("/assets/ts.worker-BA62zYty.js",{type:"module",name:n?.name})}const y=`// Generated @caemble/core declaration.\r
export type Tensor = number | readonly Tensor[]\r
export type Vars = Readonly<Record<string, Tensor>>\r
export type Vec3 = readonly [number, number, number]\r
export type CartesianBasis = readonly [Vec3, Vec3, Vec3]\r
export type Rotation = Readonly<{ axis: Vec3; angle: number }>\r
// <generated:primitive-authoring-bindings>\r
export const Box: (props: BoxAttributes) => unknown\r
export const Cylinder: (props: CylinderAttributes) => unknown\r
export const CurvedEdgeCylinder: (props: CurvedEdgeCylinderAttributes) => unknown\r
export const Sphere: (props: SphereAttributes) => unknown\r
export const CurvedSurfaceSphere: (props: CurvedSurfaceSphereAttributes) => unknown\r
export const Fiber: (props: FiberAttributes) => unknown\r
// </generated:primitive-authoring-bindings>\r
export function radians(degrees: number): number\r
export function radians(degrees: Vec3): Vec3\r
export type CanonicalGeometryTransformAttributes = Readonly<{\r
  position?: Vec3\r
  rotation?: Vec3\r
  scale?: Vec3\r
}>\r
export type GeometryTransformAttributes = CanonicalGeometryTransformAttributes\r
export type GeometryIdentityAttributes = Readonly<{ id?: string }>\r
export type IntrinsicGeometryAttributes = GeometryIdentityAttributes & GeometryTransformAttributes\r
export type GeometryGroupMap = Readonly<Record<string, readonly string[]>>\r
export type GeometrySurfaceRef = \`\${string}/surface/\${number}\`\r
export type SurfaceGroupMap = Readonly<Record<string, readonly GeometrySurfaceRef[]>>\r
export type VarsSchemaEntry = Readonly<{\r
  shape: readonly number[]\r
  min: number\r
  max: number\r
}>\r
export type ExperimentTarget = \`\${'experiment' | 'task'}.\${'geometry' | 'surface'}.\${string}\`\r
export type DataDType =\r
  | 'bool'\r
  | 'string'\r
  | 'int8'\r
  | 'int16'\r
  | 'int32'\r
  | 'int64'\r
  | 'uint8'\r
  | 'uint16'\r
  | 'uint32'\r
  | 'uint64'\r
  | 'float16'\r
  | 'float32'\r
  | 'float64'\r
export type FloatDataDType = Extract<DataDType, \`float\${number}\`>\r
export type NonFloatDataDType = Exclude<DataDType, FloatDataDType>\r
export type IntegerDataDType = Exclude<NonFloatDataDType, 'bool' | 'string'>\r
export type UcumUnit = string\r
// <generated:quantity-kind-types>\r
export interface CatalogQuantityKindMap {}\r
export type QuantityKindName = keyof CatalogQuantityKindMap extends never ? string : keyof CatalogQuantityKindMap\r
export type QuantityKindDomain = string\r
export type QuantityKindNameForDomain<Domain extends QuantityKindDomain> = keyof CatalogQuantityKindMap extends never\r
  ? string & { readonly __domain?: Domain }\r
  : {\r
      [Name in keyof CatalogQuantityKindMap]: CatalogQuantityKindMap[Name]['domain'] extends Domain ? Name : never\r
    }[keyof CatalogQuantityKindMap]\r
export type TensorQuantityKindName = keyof CatalogQuantityKindMap extends never\r
  ? string\r
  : {\r
      [Name in keyof CatalogQuantityKindMap]: CatalogQuantityKindMap[Name]['tensorOrder'] extends 0 ? never : Name\r
    }[keyof CatalogQuantityKindMap]\r
export type ScalarQuantityKindName = keyof CatalogQuantityKindMap extends never\r
  ? string\r
  : {\r
      [Name in keyof CatalogQuantityKindMap]: CatalogQuantityKindMap[Name]['tensorOrder'] extends 0 ? Name : never\r
    }[keyof CatalogQuantityKindMap]\r
export type ApplicableUnit<Name extends QuantityKindName> = Name extends keyof CatalogQuantityKindMap\r
  ? CatalogQuantityKindMap[Name]['applicableUnits'][number]\r
  : UcumUnit\r
// </generated:quantity-kind-types>\r
type QuantityBasisMetadata<Name extends QuantityKindName> = keyof CatalogQuantityKindMap extends never\r
  ? Readonly<{ basis?: CartesianBasis }>\r
  : [Name] extends [ScalarQuantityKindName]\r
    ? Readonly<{ basis?: never }>\r
    : [Name] extends [TensorQuantityKindName]\r
      ? Readonly<{ basis?: CartesianBasis }>\r
      : Readonly<{ basis?: CartesianBasis }>\r
export type QuantityMetadata<Name extends QuantityKindName = QuantityKindName> = Readonly<{\r
  unit: ApplicableUnit<Name>\r
  quantityKind: Name\r
}> &\r
  QuantityBasisMetadata<Name>\r
type DataSchemaAxisBase = Readonly<{\r
  length?: number\r
  name?: string\r
  ticks?: readonly (number | string)[]\r
}>\r
export type DataSchemaAxis = DataSchemaAxisBase &\r
  Readonly<{ unit: UcumUnit; quantityKind: ScalarQuantityKindName } | { unit?: never; quantityKind?: never }>\r
export type DataAxis = DataSchemaAxis & Readonly<{ length: number }>\r
type DataTypeMetadata = Readonly<\r
  | ({\r
      dtype: FloatDataDType\r
    } & (QuantityMetadata<ScalarQuantityKindName> | QuantityMetadata<TensorQuantityKindName>))\r
  | {\r
      dtype: NonFloatDataDType\r
      unit?: never\r
      quantityKind?: never\r
      basis?: never\r
    }\r
>\r
export type DataSchema = Readonly<{\r
  axes?: readonly DataSchemaAxis[]\r
}> &\r
  DataTypeMetadata\r
export type DataValueDescriptor = Readonly<{\r
  axes?: readonly DataAxis[]\r
  value: boolean | string | number | readonly unknown[]\r
}> &\r
  DataTypeMetadata\r
export type MatrixValue = readonly (readonly number[])[]\r
export type ScalarValue = boolean | string | number\r
export type ExperimentParameter = ScalarValue | DataValueDescriptor\r
export type ExperimentParameters = Readonly<Record<string, ExperimentParameter>>\r
export type RecordedDataResultAxis = DataSchemaAxis\r
export type RecordedDataResult = DataSchema\r
export type RecordedDataAxis = Readonly<{\r
  ticks?: readonly (number | string)[]\r
  implicitOrdinal?: true\r
}>\r
export type DataTensor = Readonly<{\r
  shape: readonly number[]\r
  axes?: readonly RecordedDataAxis[]\r
  storage:\r
    | Readonly<{ kind: 'inline'; value: unknown }>\r
    | Readonly<{ kind: 'attachments'; ids: readonly string[]; byteLength: number }>\r
    | Readonly<{ kind: 'base64'; data: string; byteLength: number }>\r
}>\r
export type PersistedDataTensor = DataTensor & Readonly<{ tensorEncodingVersion: 1 }>\r
export type DataTensorInput = Readonly<{\r
  value: boolean | string | number | readonly unknown[]\r
  axes?: readonly RecordedDataAxis[]\r
}>\r
export type RecordedDataTensor = DataTensor | PersistedDataTensor\r
export type RecordedDataNode = RecordedDataTensor | RecordedDataGroup\r
export interface RecordedDataGroup extends Readonly<Record<string, RecordedDataNode>> {}\r
export interface RecordedData extends Readonly<Record<string, RecordedDataNode>> {}\r
export type RecordedDataSpec = RecordedDataResult\r
export type ResolvedDataSchema = RecordedDataSpec & Readonly<{ tensorOrder: number }>\r
export type RecordedDataSpecNode = RecordedDataSpec | RecordedDataSpecGroup\r
export interface RecordedDataSpecGroup extends Readonly<Record<string, RecordedDataSpecNode>> {}\r
export type ResolvedDataSchemaNode = ResolvedDataSchema | ResolvedDataSchemaGroup\r
export interface ResolvedDataSchemaGroup extends Readonly<Record<string, ResolvedDataSchemaNode>> {}\r
\r
export type BoxAttributes = Readonly<{\r
  size?: Vec3\r
}> &\r
  IntrinsicGeometryAttributes\r
export type BooleanAttributes = Readonly<{\r
  children?: unknown\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type CylinderAttributes = Readonly<{\r
  radius?: number\r
  radius_2?: number\r
  height?: number\r
  segments?: number\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type CurvedEdgeCylinderFourierMode = Readonly<{\r
  amplitude: number\r
  phase: number\r
}>\r
export type CurvedEdgeCylinderTaylorCurve = Readonly<{\r
  origin: number\r
  coefficients: readonly number[]\r
}>\r
export type CurvedEdgeCylinderAttributes = Readonly<{\r
  height?: number\r
  azimuthalCurve?: readonly CurvedEdgeCylinderFourierMode[]\r
  verticalCurve?: CurvedEdgeCylinderTaylorCurve\r
  azimuthalSegments?: number\r
  verticalSegments?: number\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type CurvedSurfaceSphereFourierMode = Readonly<{\r
  amplitude: number\r
  phase: number\r
}>\r
export type CurvedSurfaceSphereAttributes = Readonly<{\r
  azimuthalCurve?: readonly CurvedSurfaceSphereFourierMode[]\r
  polarCurve?: readonly CurvedSurfaceSphereFourierMode[]\r
  azimuthalSegments?: number\r
  polarSegments?: number\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type SphereAttributes = Readonly<{\r
  radius?: number\r
  segments?: number\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type FiberFourierMode = Readonly<{ amplitude: number; phase: number }>\r
export type FiberHelix = Readonly<{\r
  turns: number\r
  phase?: number\r
  radius: number | ((u: number, theta: number) => number)\r
}>\r
export type FiberAttributes = Readonly<{\r
  from?: Vec3\r
  to?: Vec3\r
  basePath?: (t: number) => Vec3\r
  radius?: number | ((s: number) => number)\r
  helix?: FiberHelix\r
  fourier?: readonly FiberFourierMode[]\r
  envelopePower?: number\r
  up?: Vec3\r
  pathSegments?: number\r
  radialSegments?: number\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type ArrayAttributes = Readonly<{\r
  shape: readonly [number, number, number]\r
  period: Vec3\r
  axes?: Readonly<{ x: Vec3; y: Vec3; z: Vec3 }>\r
  inject?: Readonly<Record<string, Tensor | Readonly<{ axis: Tensor; angle: Tensor }>>>\r
  children?: unknown\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type TranslateAttributes = Readonly<{\r
  offset: Vec3\r
  children?: unknown\r
}> &\r
  GeometryIdentityAttributes\r
\r
export type RotateAttributes = Readonly<{\r
  axis: Vec3\r
  angle: number\r
  children?: unknown\r
}> &\r
  GeometryIdentityAttributes\r
\r
export type ScaleAttributes = Readonly<{\r
  x: number\r
  y: number\r
  z: number\r
  children?: unknown\r
}> &\r
  GeometryIdentityAttributes\r
\r
export type ShellAttributes = Readonly<{\r
  offsets: Readonly<Record<string, number>>\r
  children?: unknown\r
}> &\r
  IntrinsicGeometryAttributes\r
\r
export type GeometryAttributes<P extends object = object> = Readonly<\r
  P & {\r
    id: string\r
    materials?: Readonly<Record<string, Material | undefined>>\r
    children?: unknown\r
  }\r
> &\r
  GeometryTransformAttributes\r
export type Geometry<P extends object = object> = (props: GeometryAttributes<P>) => unknown\r
export type GeometryInvocationAttributes<P extends object = object> = Readonly<\r
  Partial<P> & {\r
    id?: string\r
    materials?: Readonly<Record<string, Material | undefined>>\r
    children?: unknown\r
  }\r
> &\r
  GeometryTransformAttributes\r
\r
// <generated:material-catalog-types>\r
// Catalog keys are augmented in memory from the active Solver runtime slice.\r
export interface MaterialPropertyQuantityKindMap {}\r
export type MaterialPropertyKey = keyof MaterialPropertyQuantityKindMap extends never\r
  ? string\r
  : keyof MaterialPropertyQuantityKindMap\r
export type MaterialPropertyQuantityKind<Key extends MaterialPropertyKey> =\r
  Key extends keyof MaterialPropertyQuantityKindMap ? MaterialPropertyQuantityKindMap[Key] : QuantityKindName\r
export type MaterialPropertyDefinitionFor<Key extends MaterialPropertyKey> = Readonly<{\r
  key: Key\r
  quantity_kind: MaterialPropertyQuantityKind<Key>\r
}>\r
\r
export interface MaterialModelDefinitionMap {}\r
export type MaterialModelKey = keyof MaterialModelDefinitionMap extends never\r
  ? string\r
  : keyof MaterialModelDefinitionMap\r
export type MaterialModelDefinitionFor<Key extends MaterialModelKey> = Key extends keyof MaterialModelDefinitionMap\r
  ? MaterialModelDefinitionMap[Key]\r
  : Readonly<{\r
      key: Key\r
      kind: 'sampled_relation'\r
      input: Readonly<{ quantity_kind: QuantityKindName }>\r
      output: Readonly<{ quantity_kind: QuantityKindName }>\r
      minimum_samples: number\r
      shared_basis: boolean\r
    }>\r
export type MaterialCatalogKey = MaterialPropertyKey | MaterialModelKey\r
\r
type MaterialAuthoringBasis<Name extends QuantityKindName> = Name extends ScalarQuantityKindName\r
  ? Readonly<{ basis?: never }>\r
  : Readonly<{ basis?: CartesianBasis }>\r
type MaterialNormalizedBasis<Name extends QuantityKindName> = Name extends ScalarQuantityKindName\r
  ? Readonly<{ basis?: never }>\r
  : Readonly<{ basis: CartesianBasis }>\r
\r
export type MaterialDataValueDescriptor<Key extends MaterialPropertyKey = MaterialPropertyKey> =\r
  Key extends MaterialPropertyKey\r
    ? Readonly<{\r
        dtype: FloatDataDType\r
        value: number | readonly unknown[]\r
        unit: ApplicableUnit<MaterialPropertyQuantityKind<Key>>\r
        errorRate?: number\r
        axes?: never\r
        quantityKind?: never\r
      }> &\r
        MaterialAuthoringBasis<MaterialPropertyQuantityKind<Key>>\r
    : never\r
\r
export type NormalizedMaterialDataValueDescriptor<Key extends MaterialPropertyKey = MaterialPropertyKey> =\r
  Key extends MaterialPropertyKey\r
    ? Readonly<{\r
        dtype: FloatDataDType\r
        value: number | readonly unknown[]\r
        unit: UcumUnit\r
        quantityKind: MaterialPropertyQuantityKind<Key>\r
        errorRate: number\r
        axes?: never\r
      }> &\r
        MaterialNormalizedBasis<MaterialPropertyQuantityKind<Key>>\r
    : never\r
\r
type MaterialModelInputQuantityKind<Key extends MaterialModelKey> =\r
  MaterialModelDefinitionFor<Key>['input']['quantity_kind']\r
type MaterialModelOutputQuantityKind<Key extends MaterialModelKey> =\r
  MaterialModelDefinitionFor<Key>['output']['quantity_kind']\r
export type MaterialQuantitySeries<Name extends QuantityKindName> = Readonly<{\r
  unit: ApplicableUnit<Name>\r
  values: readonly unknown[]\r
}> &\r
  MaterialAuthoringBasis<Name>\r
export type MaterialSampledRelation<Key extends MaterialModelKey = MaterialModelKey> = Key extends MaterialModelKey\r
  ? Readonly<{\r
      kind: 'sampled_relation'\r
      input: MaterialQuantitySeries<MaterialModelInputQuantityKind<Key>>\r
      output: MaterialQuantitySeries<MaterialModelOutputQuantityKind<Key>>\r
    }>\r
  : never\r
\r
export type MaterialVariable = string | MaterialDataValueDescriptor | MaterialSampledRelation\r
export type MaterialVariables = keyof MaterialPropertyQuantityKindMap extends never\r
  ? Readonly<Record<string, unknown> & { color?: string; errorRate?: number }>\r
  : Readonly<\r
      { [Key in keyof MaterialPropertyQuantityKindMap]?: MaterialDataValueDescriptor<Key> } & {\r
        [Key in keyof MaterialModelDefinitionMap]?: MaterialSampledRelation<Key>\r
      } & { color?: string; errorRate?: number }\r
    >\r
export type NormalizedMaterialVariables = keyof MaterialPropertyQuantityKindMap extends never\r
  ? Readonly<Record<string, unknown> & { color?: string }>\r
  : Readonly<\r
      { [Key in keyof MaterialPropertyQuantityKindMap]?: NormalizedMaterialDataValueDescriptor<Key> } & {\r
        [Key in keyof MaterialModelDefinitionMap]?: MaterialSampledRelation<Key>\r
      } & { color?: string }\r
    >\r
export type ResolvedMaterialVariables = NormalizedMaterialVariables\r
// </generated:material-catalog-types>\r
\r
export class CadModelError extends Error {\r
  constructor(message: string)\r
}\r
\r
export function normalizeUcumUnit(value: unknown, path: string): UcumUnit\r
export function convertUcumValue(\r
  value: number,\r
  fromUnit: UcumUnit | undefined,\r
  toUnit: UcumUnit | undefined,\r
  path?: string,\r
): number\r
export function isFloatDType(dtype: DataDType): boolean\r
export function Mat(diagonal: number, offDiagonal?: number, size?: number): MatrixValue\r
\r
export class Material {\r
  constructor(name: string)\r
  constructor(name: string, variables: MaterialVariables)\r
  constructor(name: string, sourceVersion: string)\r
  constructor(name: string, sourceVersion: string, variables: MaterialVariables)\r
  readonly name: string\r
  readonly source?: string\r
  readonly version?: string\r
  readonly errorRate: number\r
  readonly variables: NormalizedMaterialVariables\r
}\r
\r
export type VarsSchemaDefinition = Readonly<\r
  Record<string, Readonly<{ shape?: readonly number[]; min: number; max: number }>>\r
>\r
\r
type FixedLengthTensor<\r
  Length extends number,\r
  Value,\r
  Result extends readonly Value[] = readonly [],\r
> = number extends Length\r
  ? readonly Value[]\r
  : Result['length'] extends Length\r
    ? Result\r
    : Result['length'] extends 32\r
      ? readonly Value[]\r
      : FixedLengthTensor<Length, Value, readonly [...Result, Value]>\r
\r
type TensorForShape<Shape extends readonly number[]> = number extends Shape['length']\r
  ? Tensor\r
  : Shape extends readonly []\r
    ? number\r
    : Shape extends readonly [infer Length extends number, ...infer Rest extends readonly number[]]\r
      ? FixedLengthTensor<Length, TensorForShape<Rest>>\r
      : never\r
\r
type TensorForSchemaEntry<Entry extends VarsSchemaDefinition[string]> =\r
  Entry extends Readonly<{\r
    shape: infer Shape extends readonly number[]\r
  }>\r
    ? TensorForShape<Shape>\r
    : number\r
\r
export type InferVars<Schema extends VarsSchemaDefinition> = Readonly<{\r
  [Key in keyof Schema]: TensorForSchemaEntry<Schema[Key]>\r
}>\r
\r
export type ModelContext<Schema extends VarsSchemaDefinition> = Readonly<{\r
  vars: InferVars<Schema>\r
}>\r
\r
export type TaskModelContext = Readonly<{\r
  vars: Readonly<Vars>\r
}>\r
\r
export type KernelIdentity = Readonly<{\r
  name: string\r
  version: string\r
}>\r
\r
export type ExperimentDefinitionOptions<\r
  Schema extends VarsSchemaDefinition,\r
  Recorded extends Readonly<Record<string, RecordedDataSpecNode>>,\r
> = Readonly<{\r
  geometry: (context: ModelContext<Schema>) => unknown\r
  lengthUnit: UcumUnit\r
  varsSchema: Schema\r
  geometryGroup?: GeometryGroupMap\r
  surfaceGroup?: SurfaceGroupMap\r
  recordedData: Recorded\r
}>\r
\r
export type TaskDefinitionOptions<Config> = Readonly<{\r
  kernel: KernelIdentity\r
  lengthUnit?: UcumUnit\r
  geometry?: (context: TaskModelContext) => unknown\r
  geometryGroup?: GeometryGroupMap\r
  surfaceGroup?: SurfaceGroupMap\r
  config: (context: TaskModelContext) => Config\r
}>\r
\r
export class ExperimentDefinition<\r
  Schema extends VarsSchemaDefinition = VarsSchemaDefinition,\r
  Recorded extends Readonly<Record<string, RecordedDataSpecNode>> = Readonly<Record<string, RecordedDataSpecNode>>,\r
> {\r
  constructor(options: ExperimentDefinitionOptions<Schema, Recorded>)\r
  readonly documentType: 'experiment'\r
  readonly varsSchema: Readonly<Record<string, VarsSchemaEntry>>\r
  readonly lengthUnit: UcumUnit\r
  readonly geometryGroup: GeometryGroupMap\r
  readonly surfaceGroup: SurfaceGroupMap\r
  readonly recordedData: Recorded\r
}\r
\r
export class TaskDefinition<Config = unknown> {\r
  constructor(options: TaskDefinitionOptions<Config>)\r
  readonly documentType: 'task'\r
  readonly kernel: KernelIdentity\r
  readonly lengthUnit?: UcumUnit\r
  readonly geometryGroup: GeometryGroupMap\r
  readonly surfaceGroup: SurfaceGroupMap\r
}\r
\r
export declare function experiment<\r
  const Schema extends VarsSchemaDefinition,\r
  const Recorded extends Readonly<Record<string, RecordedDataSpecNode>>,\r
>(options: ExperimentDefinitionOptions<Schema, Recorded>): ExperimentDefinition<Schema, Recorded>\r
\r
export declare function defineTask<const Config>(options: TaskDefinitionOptions<Config>): TaskDefinition<Config>\r
\r
export type SimulationProgramManifest = Readonly<{\r
  pythonSource: string\r
  tasks: Readonly<\r
    Record<\r
      string,\r
      Readonly<{\r
        kernel: KernelIdentity\r
        config: unknown\r
      }>\r
    >\r
  >\r
  recordedData: Readonly<Record<string, ResolvedDataSchemaNode>>\r
}>\r
\r
export type ExternalVars = Readonly<Record<string, Tensor>>\r
`,l=`// Generated by scripts/generate-cad-api.mjs from elements/manifest.json. Do not edit.\r
import type {\r
  ArrayAttributes,\r
  BooleanAttributes,\r
  RotateAttributes,\r
  ScaleAttributes,\r
  ShellAttributes,\r
  TranslateAttributes,\r
  Geometry,\r
  GeometryInvocationAttributes,\r
} from '@caemble/core'\r
\r
declare global {\r
  function h(type: unknown, attributes: unknown, ...children: unknown[]): unknown\r
  function Fragment(props: { children?: unknown }): unknown\r
\r
  namespace JSX {\r
    type LibraryManagedAttributes<Component, Props> = Props extends { readonly id: string }\r
      ? Component extends Geometry<infer CustomProps>\r
        ? GeometryInvocationAttributes<CustomProps>\r
        : Props\r
      : Props\r
\r
    interface IntrinsicElements {\r
      translate: TranslateAttributes\r
      rotate: RotateAttributes\r
      scale: ScaleAttributes\r
      shell: ShellAttributes\r
      array: ArrayAttributes\r
      union: BooleanAttributes\r
      subtract: BooleanAttributes\r
      intersect: BooleanAttributes\r
    }\r
  }\r
}\r
\r
export {}\r
`;let a=!1;function p(n){if(a)return;const e=n.typescript;e.typescriptDefaults.setCompilerOptions({target:e.ScriptTarget.ES2020,module:e.ModuleKind.CommonJS,moduleResolution:e.ModuleResolutionKind.NodeJs,allowNonTsExtensions:!0,allowImportingTsExtensions:!0,jsx:e.JsxEmit.React,jsxFactory:"h",jsxFragmentFactory:"Fragment",strict:!0,noEmit:!1,noEmitOnError:!1,sourceMap:!0,inlineSources:!0}),e.typescriptDefaults.setEagerModelSync(!0),e.typescriptDefaults.addExtraLib(y,"file:///node_modules/@caemble/core/index.d.ts"),e.typescriptDefaults.addExtraLib(l,"file:///node_modules/@caemble/core/cad-jsx.d.ts"),a=!0}let r=null;function o(){if(!r){const n={getWorker(e,t){return t==="typescript"||t==="javascript"?new s:new d}};globalThis.MonacoEnvironment=n,r=i(()=>import("./index-u096at48.js").then(e=>e.i),__vite__mapDeps([0,1,2,3,4])).then(e=>(p(e),e))}return r}const m=Object.freeze(Object.defineProperty({__proto__:null,loadMonaco:o},Symbol.toStringTag,{value:"Module"})),c=Object.freeze(Object.defineProperty({__proto__:null,loadMonaco:o},Symbol.toStringTag,{value:"Module"}));export{c as a,m};
