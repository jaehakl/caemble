import{k as s}from"./main-DFf0P4nW.js";/**
 * @license lucide-react v1.25.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],m=s("eye",u);function o(a){if(typeof a!="object"||a===null||!("measurementReturnTo"in a))return null;const t=String(a.measurementReturnTo),e=new URL(t,"https://caemble.local");return e.pathname==="/measurements"||e.pathname==="/viewer"?`${e.pathname}${e.search}`:null}function l(a,t,e){const r=new URL(a,"https://caemble.local"),n=Number(r.searchParams.get(t))||null;return e?r.searchParams.set(t,String(e)):r.searchParams.delete(t),n!==e&&(r.searchParams.delete(t==="structure"?"sample":"setup"),r.searchParams.delete("measurement")),`${r.pathname}${r.search}`}export{m as E,o as r,l as u};
